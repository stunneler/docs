(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_def27532._.js",
  "static/chunks/node_modules_lucide-react_dist_esm_icons_a63fb347._.js"
],
    source: "dynamic"
});
