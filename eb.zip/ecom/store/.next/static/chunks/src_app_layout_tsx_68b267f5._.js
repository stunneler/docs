(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__8ebb6d4b._.css",
  "static/chunks/node_modules_@tanstack_query-devtools_build_b0310b4b._.js",
  "static/chunks/src_62787b81._.js",
  "static/chunks/node_modules_next_1ee78e7d._.js",
  "static/chunks/node_modules_@tanstack_query-core_build_modern_7a97d42d._.js",
  "static/chunks/node_modules_@tanstack_query-devtools_build_c02dd60e._.js",
  "static/chunks/node_modules_motion-dom_dist_es_27804559._.js",
  "static/chunks/node_modules_framer-motion_dist_es_906fdbc6._.js",
  "static/chunks/node_modules_axios_lib_99999129._.js",
  "static/chunks/node_modules_58a3e76f._.js"
],
    source: "dynamic"
});
