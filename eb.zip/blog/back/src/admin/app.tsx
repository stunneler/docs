import type { StrapiApp } from '@strapi/strapi/admin';
import React from 'react';

// Add polyfills immediately when the module loads
(function() {
  // Polyfill for toSpliced method if not available
  if (!Array.prototype.toSpliced) {
    Array.prototype.toSpliced = function(start, deleteCount, ...items) {
      const result = [...this];
      result.splice(start, deleteCount, ...items);
      return result;
    };
  }

  // Polyfill for toSorted method if not available
  if (!Array.prototype.toSorted) {
    Array.prototype.toSorted = function(compareFn) {
      return [...this].sort(compareFn);
    };
  }

  // Also add to global scope
  if (typeof window !== 'undefined') {
    if (!window.Array.prototype.toSpliced) {
      window.Array.prototype.toSpliced = function(start, deleteCount, ...items) {
        const result = [...this];
        result.splice(start, deleteCount, ...items);
        return result;
      };
    }
    
    if (!window.Array.prototype.toSorted) {
      window.Array.prototype.toSorted = function(compareFn) {
        return [...this].sort(compareFn);
      };
    }
  }
})();

export default {
  config: {
    locales: [],
    head: {
      favicon: process.env.ADMIN_FAVICON || '/favicon.ico',
    },
    // You can also customize other aspects of the admin panel here
    theme: {
      // Custom theme options can be added here
    },
  },
  bootstrap(app: StrapiApp) {
    console.log('Strapi admin loaded with polyfills');
    
    // Dynamically update favicon if needed
    const favicon = document.querySelector('link[rel="icon"]') || document.querySelector('link[rel="shortcut icon"]');
    if (favicon) {
      favicon.setAttribute('href', process.env.ADMIN_FAVICON || '/favicon.ico');
    } else {
      // Create favicon link if it doesn't exist
      const link = document.createElement('link');
      link.rel = 'icon';
      link.href = process.env.ADMIN_FAVICON || '/favicon.ico';
      document.head.appendChild(link);
    }
  },
};
