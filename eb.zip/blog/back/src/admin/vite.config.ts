import { mergeConfig, type UserConfig } from 'vite';

export default (config: UserConfig) => {
  // Important: always return the modified config
  return mergeConfig(config, {
    server: {
      host: true,
      allowedHosts: ['swop.site', 'localhost', '127.0.0.1'],
    },
    resolve: {
      alias: {
        '@': '/src',
      },
    },
  });
};
