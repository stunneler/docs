module.exports = (plugin) => {
  // Override the admin controller to include favicon
  const originalInit = plugin.controllers.admin.init;
  plugin.controllers.admin.init = async function() {
    let uuid = strapi.config.get('uuid', false);
    const hasAdmin = await strapi.admin.services.user.exists();
    const { menuLogo, authLogo, favicon } = await strapi.admin.services['project-settings'].getProjectSettings();
    
    const telemetryDisabled = strapi.config.get('packageJsonStrapi.telemetryDisabled', null);
    if (telemetryDisabled !== null && telemetryDisabled === true) {
      uuid = false;
    }
    
    return {
      data: {
        uuid,
        hasAdmin,
        menuLogo: menuLogo ? menuLogo.url : null,
        authLogo: authLogo ? authLogo.url : null,
        favicon: favicon ? favicon.url : null
      }
    };
  };

  // Override project settings service to include favicon
  const originalGetProjectSettings = plugin.services['project-settings'].getProjectSettings;
  plugin.services['project-settings'].getProjectSettings = async function() {
    const store = strapi.store({
      type: 'core',
      name: 'admin'
    });
    
    const PROJECT_SETTINGS_FILE_INPUTS = [
      'menuLogo',
      'authLogo', 
      'favicon'
    ];
    
    const defaultProjectSettings = PROJECT_SETTINGS_FILE_INPUTS.reduce((prev, cur) => {
      prev[cur] = null;
      return prev;
    }, {});
    
    const projectSettings = {
      ...defaultProjectSettings,
      ...await store.get({
        key: 'project-settings'
      })
    };
    
    PROJECT_SETTINGS_FILE_INPUTS.forEach((inputName) => {
      if (!projectSettings[inputName]) {
        return;
      }
      projectSettings[inputName] = require('lodash').pick(projectSettings[inputName], [
        'name',
        'url', 
        'width',
        'height',
        'ext',
        'size'
      ]);
    });
    
    return projectSettings;
  };

  // Override parseFilesData to include favicon
  const originalParseFilesData = plugin.services['project-settings'].parseFilesData;
  plugin.services['project-settings'].parseFilesData = async function(files) {
    const PROJECT_SETTINGS_FILE_INPUTS = [
      'menuLogo',
      'authLogo',
      'favicon'
    ];
    
    const formatedFilesData = {};
    await Promise.all(PROJECT_SETTINGS_FILE_INPUTS.map(async (inputName) => {
      const file = files[inputName];
      if (!file) {
        return;
      }
      
      const getStream = () => require('fs').createReadStream(file.filepath);
      
      formatedFilesData[inputName] = await strapi.plugin('upload').service('upload').formatFileInfo({
        filename: file.originalFilename,
        type: file.mimetype,
        size: file.size
      });
      
      // Add image dimensions (favicon might not be an image)
      try {
        Object.assign(formatedFilesData[inputName], await strapi.plugin('upload').service('image-manipulation').getDimensions({
          getStream
        }));
      } catch (error) {
        // Skip dimensions for non-image files
      }
      
      Object.assign(formatedFilesData[inputName], {
        stream: getStream(),
        tmpPath: file.filepath,
        provider: strapi.config.get('plugin::upload').provider
      });
    }));
    
    return formatedFilesData;
  };

  return plugin;
};