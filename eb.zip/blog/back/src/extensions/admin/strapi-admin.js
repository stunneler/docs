module.exports = (config) => {
  // Extend the admin configuration to include favicon in project settings
  return {
    ...config,
    config: {
      ...config.config,
      // Add favicon to the project settings schema
      projectSettings: {
        ...config.config?.projectSettings,
        favicon: {
          type: 'media',
          allowedTypes: ['images', 'files'],
          required: false,
        }
      }
    }
  };
};