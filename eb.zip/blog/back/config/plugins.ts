export default () => ({
  email: {
    config: {
      provider: 'nodemailer',
      providerOptions: {
        host: 'smtp.gmail.com',
        port: 587,
        auth: {
          user: 'fireraid8@gmail.com',
          pass: 'jxbojfswcbupsptg',
        },
      },
      settings: {
        defaultFrom: 'fireraid8@gmail.com',
        defaultReplyTo: 'fireraid8@gmail.com',
      },
    },
  },
});
