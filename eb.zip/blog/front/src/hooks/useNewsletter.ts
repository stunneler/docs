"use client";

import { useState } from 'react';

const STRAPI_URL = "http://swop.site:1337";

export interface NewsletterSubscription {
  email: string;
  subscribedAt?: Date;
}

export const useNewsletter = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const subscribeToNewsletter = async (email: string) => {
    try {
      setLoading(true);
      setError(null);
      setSuccess(null);

      // Validate email format
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email)) {
        throw new Error('Please enter a valid email address');
      }

      // Subscribe to newsletter via our API route
      const response = await fetch('/api/newsletter', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email: email,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to subscribe to newsletter');
      }

      const result = await response.json();
      setSuccess(result.message || 'Successfully subscribed! Welcome to our newsletter.');
      return true;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to subscribe to newsletter';
      setError(errorMessage);
      console.error("Newsletter subscription error:", err);
      return false;
    } finally {
      setLoading(false);
    }
  };

  const unsubscribeFromNewsletter = async (email: string) => {
    try {
      setLoading(true);
      setError(null);
      setSuccess(null);

      // Validate email format
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email)) {
        throw new Error('Please enter a valid email address');
      }

      // Unsubscribe from newsletter via our API route
      const response = await fetch('/api/newsletter/unsubscribe', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email: email,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to unsubscribe from newsletter');
      }

      const result = await response.json();
      setSuccess(result.message || 'Successfully unsubscribed from newsletter.');
      return true;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to unsubscribe from newsletter';
      setError(errorMessage);
      console.error("Newsletter unsubscription error:", err);
      return false;
    } finally {
      setLoading(false);
    }
  };

  const sendTestEmail = async (email: string) => {
    try {
      setLoading(true);
      setError(null);
      setSuccess(null);

      const response = await fetch(`${STRAPI_URL}/api/email/test`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          to: email,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error?.message || 'Failed to send test email');
      }

      setSuccess('Test email sent successfully!');
      return true;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to send test email';
      setError(errorMessage);
      console.error("Test email error:", err);
      return false;
    } finally {
      setLoading(false);
    }
  };

  const clearMessages = () => {
    setError(null);
    setSuccess(null);
  };

  return {
    subscribeToNewsletter,
    unsubscribeFromNewsletter,
    sendTestEmail,
    clearMessages,
    loading,
    error,
    success,
  };
};