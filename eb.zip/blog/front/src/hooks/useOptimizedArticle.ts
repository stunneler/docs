"use client";

import { useQuery } from '@tanstack/react-query';

const STRAPI_URL = "http://swop.site:1337";

const fetchArticle = async (slug: string) => {
  try {
    // Use EXACT same logic as original working hook with proper deep population
    let blocksResponse = await fetch(`${STRAPI_URL}/api/articles?filters[slug][$eq]=${slug}&populate=blocks,blocks.file,blocks.files`);
    let metaResponse = await fetch(`${STRAPI_URL}/api/articles?filters[slug][$eq]=${slug}&populate=*`);

    if (!blocksResponse.ok || !metaResponse.ok) {
      throw new Error(`Failed to fetch article by slug: ${blocksResponse.status} / ${metaResponse.status}`);
    }
    
    let blocksData = await blocksResponse.json();
    let metaData = await metaResponse.json();
    
    // If no article found by slug, try by documentId (direct ID approach)
    if ((!blocksData.data || blocksData.data.length === 0) || (!metaData.data || metaData.data.length === 0)) {
      console.log('No article found by slug, trying by documentId:', slug);
      blocksResponse = await fetch(`${STRAPI_URL}/api/articles?filters[documentId][$eq]=${slug}&populate=blocks,blocks.file,blocks.files`);
      metaResponse = await fetch(`${STRAPI_URL}/api/articles?filters[documentId][$eq]=${slug}&populate=*`);
      
      if (!blocksResponse.ok || !metaResponse.ok) {
        throw new Error(`Failed to fetch article by ID: ${blocksResponse.status} / ${metaResponse.status}`);
      }

      blocksData = await blocksResponse.json();
      metaData = await metaResponse.json();
    }
    
    if (blocksData.data?.[0] && metaData.data?.[0]) {
      // Combine the data - use blocks from first call, metadata from second
      const combinedArticle = {
        ...metaData.data[0],
        blocks: blocksData.data[0].blocks
      };
      return combinedArticle;
    } else {
      throw new Error("Article not found");
    }
  } catch (error) {
    console.error('Article fetch error:', error);
    throw error;
  }
};

export const useOptimizedArticle = (slug: string) => {
  const {
    data: article,
    isLoading,
    error
  } = useQuery({
    queryKey: ['article', slug],
    queryFn: () => fetchArticle(slug),
    enabled: !!slug,
    staleTime: 10 * 60 * 1000, // 10 minutes for individual articles
    gcTime: 15 * 60 * 1000, // 15 minutes
  });

  return {
    article,
    loading: isLoading,
    error: error?.message || null,
    strapiUrl: STRAPI_URL
  };
};