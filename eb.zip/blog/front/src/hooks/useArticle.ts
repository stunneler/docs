"use client";

import { useState, useEffect } from 'react';
import { Article } from '@/types';

const STRAPI_URL = "http://swop.site:1337";

export const useArticle = (slug: string) => {
  const [article, setArticle] = useState<Article | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchArticle = async (slug: string) => {
    try {
      setLoading(true);
      setError(null);
      
      // First try to fetch by slug with blocks populated (using same approach as About page)
      let blocksResponse = await fetch(`${STRAPI_URL}/api/articles?filters[slug][$eq]=${slug}&populate%5Bblocks%5D%5Bpopulate%5D=*`);
      let metaResponse = await fetch(`${STRAPI_URL}/api/articles?filters[slug][$eq]=${slug}&populate=*`);

      if (!blocksResponse.ok || !metaResponse.ok) {
        throw new Error(`Failed to fetch article by slug: ${blocksResponse.status} / ${metaResponse.status}`);
      }
      
      let blocksData = await blocksResponse.json();
      let metaData = await metaResponse.json();
      
      // If no article found by slug, try by documentId (direct ID approach)
      if ((!blocksData.data || blocksData.data.length === 0) || (!metaData.data || metaData.data.length === 0)) {
        console.log('No article found by slug, trying by documentId:', slug);
        blocksResponse = await fetch(`${STRAPI_URL}/api/articles?filters[documentId][$eq]=${slug}&populate%5Bblocks%5D%5Bpopulate%5D=*`);
        metaResponse = await fetch(`${STRAPI_URL}/api/articles?filters[documentId][$eq]=${slug}&populate=*`);
        
        if (!blocksResponse.ok || !metaResponse.ok) {
          throw new Error(`Failed to fetch article by ID: ${blocksResponse.status} / ${metaResponse.status}`);
        }

        blocksData = await blocksResponse.json();
        metaData = await metaResponse.json();
      }
      
      if (blocksData.data?.[0] && metaData.data?.[0]) {
        // Combine the data - use blocks from first call, metadata from second
        const combinedArticle = {
          ...metaData.data[0],
          blocks: blocksData.data[0].blocks
        };
        setArticle(combinedArticle);
      } else {
        setError("Article not found");
      }
    } catch (err) {
      console.error("Error fetching article:", err);
      setError(err instanceof Error ? err.message : 'Failed to load article');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (slug) {
      fetchArticle(slug);
    }
  }, [slug]);

  return {
    article,
    loading,
    error,
    refetch: () => fetchArticle(slug),
    strapiUrl: STRAPI_URL,
  };
};