"use client";

import { useState, useEffect } from 'react';
import { AboutPage } from '@/types';

const STRAPI_URL = "http://swop.site:1337";

export const useAbout = () => {
  const [aboutData, setAboutData] = useState<AboutPage | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchAbout = async () => {
    try {
      setLoading(true);
      // Use proper URL encoding for nested population
      const response = await fetch(`${STRAPI_URL}/api/about?populate%5Bblocks%5D%5Bpopulate%5D=*`);
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      setAboutData(data.data);
      setError(null);
    } catch (err) {
      console.error("Error fetching about page:", err);
      setError("Failed to fetch about page content.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAbout();
  }, []);

  return {
    aboutData,
    loading,
    error,
    refetch: fetchAbout,
    strapiUrl: STRAPI_URL,
  };
};
