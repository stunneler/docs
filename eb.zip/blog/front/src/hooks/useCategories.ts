"use client";

import { useState, useEffect } from 'react';

const STRAPI_URL = "http://swop.site:1337";

export interface Category {
  id: string;
  documentId: string;
  name: string;
  slug: string;
  description?: string;
  articleCount?: number;
}

export const useCategories = () => {
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchCategories = async () => {
    try {
      setLoading(true);
      const response = await fetch(`${STRAPI_URL}/api/categories?populate=*`);
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      
      // Fetch article counts for each category
      const categoriesWithCounts = await Promise.all(
        data.data.map(async (category: any) => {
          try {
            const articlesResponse = await fetch(
              `${STRAPI_URL}/api/articles?filters[category][slug][$eq]=${category.slug}&pagination[pageSize]=1`
            );
            const articlesData = await articlesResponse.json();
            
            return {
              id: category.id,
              documentId: category.documentId,
              name: category.name,
              slug: category.slug,
              description: category.description,
              articleCount: articlesData.meta?.pagination?.total || 0
            };
          } catch (err) {
            console.error(`Error fetching article count for category ${category.slug}:`, err);
            return {
              id: category.id,
              documentId: category.documentId,
              name: category.name,
              slug: category.slug,
              description: category.description,
              articleCount: 0
            };
          }
        })
      );
      
      setCategories(categoriesWithCounts);
      setError(null);
    } catch (err) {
      console.error("Error fetching categories:", err);
      setError("Failed to fetch categories. Please check if Strapi is running.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCategories();
  }, []);

  return {
    categories,
    loading,
    error,
    refetch: fetchCategories,
    strapiUrl: STRAPI_URL,
  };
};