"use client";

import { useState, useEffect } from 'react';
import { Article } from '@/types';

const STRAPI_URL = "http://swop.site:1337";
const ARTICLES_PER_PAGE = 5;

export const useArticles = () => {
  const [articles, setArticles] = useState<Article[]>([]);
  const [filteredArticles, setFilteredArticles] = useState<Article[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [totalArticles, setTotalArticles] = useState(0);
  const [searchQuery, setSearchQuery] = useState("");

  const fetchArticles = async (page: number = 1, append: boolean = false) => {
    try {
      if (page === 1) {
        setLoading(true);
      } else {
        setLoadingMore(true);
      }
      
      const response = await fetch(
        `${STRAPI_URL}/api/articles?populate=*&pagination[page]=${page}&pagination[pageSize]=${ARTICLES_PER_PAGE}&sort=publishedAt:desc`
      );
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      const newArticles = data.data;
      const pagination = data.meta?.pagination;
      
      if (append) {
        setArticles(prev => [...prev, ...newArticles]);
        setFilteredArticles(prev => [...prev, ...newArticles]);
      } else {
        setArticles(newArticles);
        setFilteredArticles(newArticles);
      }
      
      setTotalArticles(pagination?.total || 0);
      setHasMore(pagination?.page < pagination?.pageCount);
      setCurrentPage(page);
      setError(null);
    } catch (err) {
      console.error("Error fetching articles:", err);
      setError("Failed to fetch articles. Please check if Strapi is running.");
    } finally {
      setLoading(false);
      setLoadingMore(false);
    }
  };

  const loadMoreArticles = async () => {
    if (!hasMore || loadingMore) return;
    await fetchArticles(currentPage + 1, true);
  };

  const searchArticles = (query: string) => {
    setSearchQuery(query);
    
    if (!query.trim()) {
      setFilteredArticles(articles);
      return;
    }

    const queryLower = query.toLowerCase();
    const filtered = articles.filter(article =>
      article.title.toLowerCase().includes(queryLower) ||
      (article.description && article.description.toLowerCase().includes(queryLower)) ||
      (article.category?.name && article.category.name.toLowerCase().includes(queryLower)) ||
      (article.author?.name && article.author.name.toLowerCase().includes(queryLower))
    );
    setFilteredArticles(filtered);
  };

  const resetAndRefetch = () => {
    setCurrentPage(1);
    setHasMore(true);
    setSearchQuery("");
    fetchArticles(1, false);
  };

  useEffect(() => {
    fetchArticles();
  }, []);

  return {
    articles: filteredArticles,
    loading,
    loadingMore,
    error,
    hasMore: hasMore && !searchQuery, // Hide load more when searching
    totalArticles,
    currentPage,
    searchArticles,
    loadMoreArticles,
    refetch: resetAndRefetch,
    strapiUrl: STRAPI_URL,
  };
};
