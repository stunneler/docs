"use client";

import { useState, useEffect, useCallback } from 'react';
import { Article } from '@/types';
import { Category } from '@/hooks/useCategories';

const STRAPI_URL = "http://swop.site:1337";

export interface SearchResult {
  articles: Article[];
  categories: Category[];
  totalResults: number;
  searchTime: number;
}

export interface SearchFilters {
  category?: string;
  author?: string;
  dateRange?: {
    from: Date;
    to: Date;
  };
  sortBy?: 'relevance' | 'date' | 'title';
  sortOrder?: 'asc' | 'desc';
}

export const useSearch = () => {
  const [results, setResults] = useState<SearchResult>({
    articles: [],
    categories: [],
    totalResults: 0,
    searchTime: 0
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [searchHistory, setSearchHistory] = useState<string[]>([]);

  // Load search history from localStorage
  useEffect(() => {
    const savedHistory = localStorage.getItem('searchHistory');
    if (savedHistory) {
      try {
        setSearchHistory(JSON.parse(savedHistory));
      } catch (err) {
        console.error('Error loading search history:', err);
      }
    }
  }, []);

  // Save search history to localStorage
  const saveSearchHistory = useCallback((query: string) => {
    if (!query.trim()) return;
    
    setSearchHistory(prevHistory => {
      const updatedHistory = [
        query,
        ...prevHistory.filter(item => item !== query)
      ].slice(0, 10); // Keep only last 10 searches
      
      localStorage.setItem('searchHistory', JSON.stringify(updatedHistory));
      return updatedHistory;
    });
  }, []);

  const search = useCallback(async (
    query: string, 
    filters: SearchFilters = {},
    saveToHistory: boolean = false
  ): Promise<SearchResult> => {
    if (!query.trim()) {
      const emptyResult = {
        articles: [],
        categories: [],
        totalResults: 0,
        searchTime: 0
      };
      setResults(emptyResult);
      return emptyResult;
    }

    try {
      setLoading(true);
      setError(null);
      const startTime = Date.now();

      // Save to search history only when explicitly requested
      if (saveToHistory) {
        saveSearchHistory(query);
      }

      // Build search filters for Strapi
      const searchParams = new URLSearchParams();
      
      // Search in article titles, descriptions, categories, and authors using OR logic
      let orIndex = 0;
      const articleFilters = [
        `filters[$or][${orIndex++}][title][$containsi]=${encodeURIComponent(query)}`,
        `filters[$or][${orIndex++}][description][$containsi]=${encodeURIComponent(query)}`,
        `filters[$or][${orIndex++}][category][name][$containsi]=${encodeURIComponent(query)}`,
        `filters[$or][${orIndex++}][author][name][$containsi]=${encodeURIComponent(query)}`
      ];

      // Add additional filters (these are AND conditions with the OR search)
      if (filters.category) {
        articleFilters.push(`filters[category][slug][$eq]=${encodeURIComponent(filters.category)}`);
      }

      if (filters.author) {
        articleFilters.push(`filters[author][name][$containsi]=${encodeURIComponent(filters.author)}`);
      }

      // Add date range filter if specified
      if (filters.dateRange) {
        articleFilters.push(`filters[publishedAt][$gte]=${filters.dateRange.from.toISOString()}`);
        articleFilters.push(`filters[publishedAt][$lte]=${filters.dateRange.to.toISOString()}`);
      }

      // Add sorting
      let sortParam = 'sort=publishedAt:desc'; // Default sort
      if (filters.sortBy) {
        switch (filters.sortBy) {
          case 'date':
            sortParam = `sort=publishedAt:${filters.sortOrder || 'desc'}`;
            break;
          case 'title':
            sortParam = `sort=title:${filters.sortOrder || 'asc'}`;
            break;
          case 'relevance':
          default:
            sortParam = 'sort=publishedAt:desc';
            break;
        }
      }

      // Search articles
      const articlesUrl = `${STRAPI_URL}/api/articles?${articleFilters.join('&')}&${sortParam}&populate=*`;
      const articlesResponse = await fetch(articlesUrl);
      
      if (!articlesResponse.ok) {
        throw new Error(`Articles search failed: ${articlesResponse.status}`);
      }
      
      const articlesData = await articlesResponse.json();

      // Search categories
      const categoriesUrl = `${STRAPI_URL}/api/categories?filters[name][$containsi]=${encodeURIComponent(query)}&populate=*`;
      const categoriesResponse = await fetch(categoriesUrl);
      
      let categoriesData = { data: [] };
      if (categoriesResponse.ok) {
        categoriesData = await categoriesResponse.json();
      }

      // Calculate search time
      const searchTime = Date.now() - startTime;

      // Combine and rank results
      const articles = articlesData.data || [];
      const categories = categoriesData.data || [];

      // Simple relevance scoring for articles
      const scoredArticles = articles.map((article: Article) => {
        let score = 0;
        const queryLower = query.toLowerCase();
        const titleLower = (article.title || '').toLowerCase();
        const descLower = (article.description || '').toLowerCase();

        // Title matches get higher score
        if (titleLower.includes(queryLower)) {
          score += titleLower === queryLower ? 100 : 50;
        }

        // Description matches
        if (descLower.includes(queryLower)) {
          score += 25;
        }

        // Category matches
        if (article.category?.name.toLowerCase().includes(queryLower)) {
          score += 15;
        }

        // Author matches
        if (article.author?.name.toLowerCase().includes(queryLower)) {
          score += 10;
        }

        return { ...article, searchScore: score };
      });

      // Sort by relevance if that's the selected sort
      if (filters.sortBy === 'relevance' || !filters.sortBy) {
        scoredArticles.sort((a, b) => (b.searchScore || 0) - (a.searchScore || 0));
      }

      const searchResult = {
        articles: scoredArticles,
        categories,
        totalResults: articles.length + categories.length,
        searchTime
      };

      setResults(searchResult);
      return searchResult;

    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Search failed';
      setError(errorMessage);
      console.error("Search error:", err);
      
      const emptyResult = {
        articles: [],
        categories: [],
        totalResults: 0,
        searchTime: 0
      };
      setResults(emptyResult);
      return emptyResult;
    } finally {
      setLoading(false);
    }
  }, [saveSearchHistory]);

  const clearSearchHistory = useCallback(() => {
    setSearchHistory([]);
    localStorage.removeItem('searchHistory');
  }, []);

  const removeFromHistory = useCallback((query: string) => {
    setSearchHistory(prevHistory => {
      const updatedHistory = prevHistory.filter(item => item !== query);
      localStorage.setItem('searchHistory', JSON.stringify(updatedHistory));
      return updatedHistory;
    });
  }, []);

  const clearResults = useCallback(() => {
    setResults({
      articles: [],
      categories: [],
      totalResults: 0,
      searchTime: 0
    });
  }, []);

  return {
    search,
    results,
    loading,
    error,
    searchHistory,
    clearSearchHistory,
    removeFromHistory,
    clearResults
  };
};