"use client";

import { useQuery } from '@tanstack/react-query';
import { useState, useMemo } from 'react';

const STRAPI_URL = "http://swop.site:1337";

interface Article {
  documentId: string;
  title: string;
  description: string;
  slug: string;
  cover?: {
    url: string;
    alternativeText?: string;
    formats?: {
      medium?: { url: string };
      small?: { url: string };
      thumbnail?: { url: string };
    };
  };
  author?: {
    name: string;
    avatar?: { url: string };
  };
  category?: {
    name: string;
    slug: string;
  };
  publishedAt: string;
  blocks?: unknown[];
}

const fetchArticles = async (): Promise<{ data: Article[] }> => {
  const response = await fetch(`${STRAPI_URL}/api/articles?populate=*`);
  if (!response.ok) {
    throw new Error('Failed to fetch articles');
  }
  return response.json();
};

export const useOptimizedArticles = () => {
  const [searchQuery, setSearchQuery] = useState('');

  const {
    data,
    isLoading,
    error,
    refetch
  } = useQuery({
    queryKey: ['articles'],
    queryFn: fetchArticles,
    staleTime: 5 * 60 * 1000, // 5 minutes
    gcTime: 10 * 60 * 1000, // 10 minutes
  });

  // Memoized filtered articles for instant search
  const filteredArticles = useMemo(() => {
    if (!data?.data) return [];
    
    if (!searchQuery.trim()) return data.data;
    
    const query = searchQuery.toLowerCase();
    return data.data.filter(article => 
      article.title.toLowerCase().includes(query) ||
      article.description?.toLowerCase().includes(query) ||
      article.category?.name.toLowerCase().includes(query) ||
      article.author?.name.toLowerCase().includes(query)
    );
  }, [data?.data, searchQuery]);

  const searchArticles = (query: string) => {
    setSearchQuery(query);
  };

  return {
    articles: filteredArticles,
    loading: isLoading,
    error: error?.message || null,
    searchArticles,
    refetch,
    strapiUrl: STRAPI_URL,
    totalCount: data?.data?.length || 0,
    filteredCount: filteredArticles.length
  };
};