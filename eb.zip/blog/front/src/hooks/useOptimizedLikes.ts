"use client";

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useState } from 'react';

interface LikeData {
  likeCount: number;
  liked: boolean;
}

const fetchLikeStatus = async (articleSlug: string): Promise<LikeData> => {
  const response = await fetch(`/api/articles/${articleSlug}/like`);
  if (!response.ok) {
    throw new Error('Failed to fetch like status');
  }
  return response.json();
};

const toggleLike = async (articleSlug: string): Promise<LikeData> => {
  const response = await fetch(`/api/articles/${articleSlug}/like`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
  });
  
  if (!response.ok) {
    throw new Error('Failed to toggle like');
  }
  
  return response.json();
};

export const useOptimizedLikes = (articleSlug: string) => {
  const [animating, setAnimating] = useState(false);
  const queryClient = useQueryClient();

  const {
    data,
    isLoading
  } = useQuery({
    queryKey: ['likes', articleSlug],
    queryFn: () => fetchLikeStatus(articleSlug),
    enabled: !!articleSlug,
    staleTime: 30 * 1000, // 30 seconds
    gcTime: 2 * 60 * 1000, // 2 minutes
  });

  const mutation = useMutation({
    mutationFn: () => toggleLike(articleSlug),
    onMutate: async () => {
      // Optimistic update
      await queryClient.cancelQueries({ queryKey: ['likes', articleSlug] });
      
      const previousData = queryClient.getQueryData<LikeData>(['likes', articleSlug]);
      
      if (previousData) {
        const optimisticData: LikeData = {
          liked: !previousData.liked,
          likeCount: previousData.liked 
            ? previousData.likeCount - 1 
            : previousData.likeCount + 1
        };
        
        queryClient.setQueryData(['likes', articleSlug], optimisticData);
      }
      
      setAnimating(true);
      setTimeout(() => setAnimating(false), 300);
      
      return { previousData };
    },
    onError: (err, variables, context) => {
      // Rollback on error
      if (context?.previousData) {
        queryClient.setQueryData(['likes', articleSlug], context.previousData);
      }
      setAnimating(false);
    },
    onSuccess: (data) => {
      // Update with server response
      queryClient.setQueryData(['likes', articleSlug], data);
    },
  });

  const handleLike = () => {
    if (!mutation.isPending) {
      mutation.mutate();
    }
  };

  return {
    liked: data?.liked || false,
    likeCount: data?.likeCount || 0,
    loading: isLoading,
    animating,
    handleLike,
    isToggling: mutation.isPending
  };
};