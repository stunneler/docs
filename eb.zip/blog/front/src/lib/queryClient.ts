import { QueryClient } from '@tanstack/react-query';

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      // Cache for 5 minutes
      staleTime: 5 * 60 * 1000,
      // Keep in cache for 10 minutes
      gcTime: 10 * 60 * 1000,
      // Retry failed requests
      retry: 2,
      // Refetch on window focus
      refetchOnWindowFocus: false,
      // Refetch on reconnect
      refetchOnReconnect: true,
    },
  },
});

// Prefetch functions for blazing fast navigation
export const prefetchArticles = () => {
  return queryClient.prefetchQuery({
    queryKey: ['articles'],
    queryFn: async () => {
      const response = await fetch('http://swop.site:1337/api/articles?populate=*');
      if (!response.ok) throw new Error('Failed to fetch articles');
      return response.json();
    },
  });
};

export const prefetchCategories = () => {
  return queryClient.prefetchQuery({
    queryKey: ['categories'],
    queryFn: async () => {
      const response = await fetch('http://swop.site:1337/api/categories?populate=*');
      if (!response.ok) throw new Error('Failed to fetch categories');
      return response.json();
    },
  });
};

export const prefetchArticle = (slug: string) => {
  return queryClient.prefetchQuery({
    queryKey: ['article', slug],
    queryFn: async () => {
      const response = await fetch(`http://swop.site:1337/api/articles?filters[slug][$eq]=${slug}&populate%5Bblocks%5D%5Bpopulate%5D=*&populate[cover]=*&populate[category]=*&populate[author][populate]=*`);
      if (!response.ok) throw new Error('Failed to fetch article');
      const data = await response.json();
      return data.data?.[0] || null;
    },
  });
};