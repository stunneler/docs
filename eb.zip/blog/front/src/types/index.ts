export interface Article {
  id: string;
  documentId: string;
  title: string;
  description?: string;
  slug?: string;
  cover?: {
    url: string;
    alternativeText?: string;
  };
  publishedAt?: Date;
  createdAt?: Date;
  updatedAt?: Date;
  author?: {
    name: string;
    avatar?: {
      url: string;
    };
  };
  category?: {
    name: string;
    slug: string;
  };
  blocks?: ContentBlock[];
}

export interface QuoteBlock {
  __component: "shared.quote";
  id: number;
  title: string;
  body: string;
}

export interface RichTextBlock {
  __component: "shared.rich-text";
  id: number;
  body: string;
}

export interface MediaBlock {
  __component: "shared.media";
  id: number;
  file?: {
    url: string;
    alternativeText?: string;
    name?: string;
    formats?: {
      large?: { url: string };
      medium?: { url: string };
      small?: { url: string };
      thumbnail?: { url: string };
    };
  };
}

export interface SliderBlock {
  __component: "shared.slider";
  id: number;
  files?: Array<{
    url: string;
    alternativeText?: string;
    name?: string;
    formats?: {
      large?: { url: string };
      medium?: { url: string };
      small?: { url: string };
      thumbnail?: { url: string };
    };
  }>;
}

export type ContentBlock = QuoteBlock | RichTextBlock | MediaBlock | SliderBlock;

export interface AboutPage {
  id: number;
  documentId: string;
  title: string;
  blocks: ContentBlock[];
  createdAt: string;
  updatedAt: string;
  publishedAt: string;
}

export interface Theme {
  isDark: boolean;
  toggle: () => void;
}
