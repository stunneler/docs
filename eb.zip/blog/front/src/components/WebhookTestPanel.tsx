"use client";

import { useState } from 'react';

interface WebhookTestPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

export const WebhookTestPanel = ({ isOpen, onClose }: WebhookTestPanelProps) => {
  const [selectedEvent, setSelectedEvent] = useState('article-create');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);

  const eventTypes = [
    { value: 'article-create', label: 'Article Created', model: 'article' },
    { value: 'article-update', label: 'Article Updated', model: 'article' },
    { value: 'newsletter-create', label: 'Newsletter Subscription', model: 'newsletter-subscription' }
  ];

  const handleTriggerWebhook = async () => {
    setLoading(true);
    setResult(null);

    try {
      const response = await fetch('/api/webhooks/test', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          eventType: selectedEvent,
          model: eventTypes.find(e => e.value === selectedEvent)?.model
        }),
      });

      const data = await response.json();
      
      if (response.ok) {
        setResult(`✅ Success: ${data.message}`);
      } else {
        setResult(`❌ Error: ${data.error}`);
      }
    } catch (error) {
      setResult(`❌ Network Error: ${error instanceof Error ? error.message : 'Unknown error'}`);
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/50 backdrop-blur-sm"
        onClick={onClose}
      />
      
      {/* Panel */}
      <div className="relative bg-white dark:bg-gray-800 rounded-2xl p-6 mx-4 max-w-md w-full shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-2">
            <svg className="w-6 h-6 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
            <h3 className="text-lg font-semibold text-primary">Test Webhooks</h3>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Event Selection */}
        <div className="mb-6">
          <label className="block text-sm font-medium text-primary mb-3">
            Select Event Type
          </label>
          <div className="space-y-2">
            {eventTypes.map((event) => (
              <label key={event.value} className="flex items-center space-x-3 cursor-pointer">
                <input
                  type="radio"
                  name="eventType"
                  value={event.value}
                  checked={selectedEvent === event.value}
                  onChange={(e) => setSelectedEvent(e.target.value)}
                  className="w-4 h-4 text-blue-600 border-gray-300 focus:ring-blue-500"
                />
                <div className="flex-1">
                  <div className="text-sm font-medium text-primary">{event.label}</div>
                  <div className="text-xs text-secondary">{event.model}</div>
                </div>
              </label>
            ))}
          </div>
        </div>

        {/* Result Display */}
        {result && (
          <div className="mb-6 p-4 rounded-lg bg-gray-50 dark:bg-gray-700">
            <div className="text-sm text-primary whitespace-pre-wrap">{result}</div>
          </div>
        )}

        {/* Actions */}
        <div className="flex space-x-3">
          <button
            onClick={onClose}
            className="flex-1 px-4 py-2 text-secondary border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handleTriggerWebhook}
            disabled={loading}
            className={`flex-1 px-4 py-2 text-white font-medium rounded-lg transition-colors ${
              loading
                ? 'bg-gray-400 cursor-not-allowed'
                : 'bg-purple-600 hover:bg-purple-700'
            }`}
          >
            {loading ? (
              <div className="flex items-center justify-center space-x-2">
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                <span>Triggering...</span>
              </div>
            ) : (
              'Trigger Webhook'
            )}
          </button>
        </div>

        {/* Info */}
        <div className="mt-4 p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
          <div className="flex items-start space-x-2">
            <svg className="w-4 h-4 text-blue-600 dark:text-blue-400 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <div className="text-xs text-blue-700 dark:text-blue-300">
              <p className="font-medium mb-1">Testing Webhooks</p>
              <p>This will trigger a test webhook event that simulates real Strapi events. Check the webhook monitor to see the results.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};