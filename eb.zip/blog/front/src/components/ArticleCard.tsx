"use client";

import Image from 'next/image';
import Link from 'next/link';
import { Article } from '@/types';

interface ArticleCardProps {
  article: Article;
  strapiUrl: string;
}

export const ArticleCard = ({ article, strapiUrl }: ArticleCardProps) => {
  const formatDate = (date: Date | string) => {
    const options: Intl.DateTimeFormatOptions = {
      year: "numeric",
      month: "long",
      day: "numeric",
    };
    return new Date(date).toLocaleDateString("en-US", options);
  };

  const truncateContent = (content: string | undefined, maxLength: number = 150) => {
    if (!content) return 'Click to read more...';
    if (content.length <= maxLength) return content;
    return content.substring(0, maxLength) + '...';
  };

  // Use slug if available, otherwise use documentId
  const articleUrl = article.slug || article.documentId;
  
  return (
    <Link href={`/articles/${articleUrl}`}>
      <article className="group card-light rounded-2xl overflow-hidden hover-lift transition-all duration-300 mb-8 cursor-pointer">
        {/* Cover Image */}
        {article.cover?.url && (
          <div className="w-full aspect-[21/9] relative overflow-hidden">
            <Image
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              src={strapiUrl + article.cover.url}
              alt={article.cover.alternativeText || article.title}
              width={800}
              height={600}
              style={{ width: '100%', height: '100%' }}
              priority={false}
            />
          </div>
        )}
        
        {/* Content Section */}
        <div className="p-5">
          <h2 className="text-base lg:text-lg font-bold mb-3 text-primary group-hover:gradient-text transition-all duration-300 line-clamp-2">
            {article.title || 'Untitled Article'}
          </h2>
          
          <p className="text-secondary mb-4 text-sm leading-relaxed line-clamp-2">
            {truncateContent(article.description, 120)}
          </p>
          
          <div className="flex items-center justify-between">
            <div className="flex flex-col space-y-1">
              <div className="text-xs text-secondary">
                <time dateTime={article.publishedAt?.toString()}>
                  {article.publishedAt ? formatDate(article.publishedAt) : 'No date'}
                </time>
              </div>
              {article.category && (
                <div className="text-xs px-2 py-1 bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300 rounded-full w-fit">
                  {article.category.name}
                </div>
              )}
            </div>
            
            <div className="btn-gradient px-4 py-2 text-white text-sm font-semibold rounded-lg shadow-lg group-hover:shadow-xl transition-all">
              Read More
            </div>
          </div>
        </div>
      </article>
    </Link>
  );
};
