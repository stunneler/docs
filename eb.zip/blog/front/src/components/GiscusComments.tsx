"use client";

import { useEffect, useRef } from 'react';

interface GiscusCommentsProps {
  className?: string;
}

export const GiscusComments = ({ className = "" }: GiscusCommentsProps) => {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!ref.current) return;

    // Clear any existing giscus
    ref.current.innerHTML = '';

    const script = document.createElement('script');
    script.src = 'https://giscus.app/client.js';
    script.setAttribute('data-repo', 'stunneler/blog');
    script.setAttribute('data-repo-id', 'R_kgDOPQN8MQ');
    script.setAttribute('data-category', 'General');
    script.setAttribute('data-category-id', 'DIC_kwDOPQN8Mc4CtPY3');
    script.setAttribute('data-mapping', 'pathname');
    script.setAttribute('data-strict', '0');
    script.setAttribute('data-reactions-enabled', '1');
    script.setAttribute('data-emit-metadata', '0');
    script.setAttribute('data-input-position', 'bottom');
    script.setAttribute('data-theme', 'preferred_color_scheme');
    script.setAttribute('data-lang', 'en');
    script.setAttribute('data-loading', 'lazy');
    script.setAttribute('crossorigin', 'anonymous');
    script.async = true;

    ref.current.appendChild(script);

    return () => {
      // Cleanup function to remove script when component unmounts
      if (ref.current) {
        ref.current.innerHTML = '';
      }
    };
  }, []);

  return (
    <div className={`glassmorphism rounded-2xl p-6 mt-8 ${className}`}>
      <h3 className="text-xl font-bold text-primary mb-4 flex items-center">
        <svg className="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
        </svg>
        Comments
      </h3>
      
      <p className="text-secondary mb-6">
        Join the discussion! Share your thoughts and engage with other readers.
      </p>

      <div ref={ref} className="giscus-container" />
    </div>
  );
};