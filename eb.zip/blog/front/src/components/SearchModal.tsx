"use client";

import { useState, useEffect, useRef, useCallback } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { useSearch, SearchFilters } from '@/hooks/useSearch';
import { useCategories } from '@/hooks/useCategories';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialQuery?: string;
}

export const SearchModal = ({ isOpen, onClose, initialQuery = '' }: SearchModalProps) => {
  const [query, setQuery] = useState(initialQuery);
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState<SearchFilters>({
    sortBy: 'relevance',
    sortOrder: 'desc'
  });
  
  const { search, results, loading, error, searchHistory, removeFromHistory, clearResults } = useSearch();
  const { categories } = useCategories();
  const inputRef = useRef<HTMLInputElement>(null);
  const STRAPI_URL = "http://swop.site:1337";

  useEffect(() => {
    if (isOpen && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isOpen]);

  const handleSearch = useCallback(async (searchQuery: string = query) => {
    if (searchQuery.trim()) {
      await search(searchQuery, filters, true); // Save to history for intentional searches
    }
  }, [search, filters, query]);

  useEffect(() => {
    if (initialQuery) {
      setQuery(initialQuery);
      // Call search directly to avoid dependency issues
      search(initialQuery, filters, true); // Save to history for initial queries
    }
  }, [initialQuery, search, filters]);

  // Debounced search effect - triggers search while typing
  useEffect(() => {
    if (!query.trim()) {
      // Clear results when query is empty
      clearResults();
      return;
    }

    const timeoutId = setTimeout(() => {
      search(query, filters, false); // Don't save to history for debounced searches
    }, 300); // 300ms debounce

    return () => clearTimeout(timeoutId);
  }, [query, filters, search, clearResults]);

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };

  const handleClose = () => {
    onClose();
    setQuery('');
    setShowFilters(false);
  };

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const highlightText = (text: string, searchQuery: string) => {
    if (!searchQuery.trim()) return text;
    
    const regex = new RegExp(`(${searchQuery})`, 'gi');
    const parts = text.split(regex);
    
    return parts.map((part, index) => 
      regex.test(part) ? (
        <mark key={index} className="bg-yellow-200 dark:bg-yellow-800 px-1 rounded">
          {part}
        </mark>
      ) : part
    );
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[60] flex items-start justify-center pt-4 sm:pt-16">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/50 backdrop-blur-sm"
        onClick={handleClose}
      />
      
      {/* Modal - Centered on all devices */}
      <div className="relative card-light rounded-2xl mx-2 sm:mx-4 max-w-sm sm:max-w-md w-full max-h-[80vh] shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-6 border-b border-gray-200 dark:border-gray-700 bg-transparent">
          {/* Desktop: Horizontal layout */}
          <div className="hidden sm:flex items-center space-x-4">
            <div className="flex-1 relative">
              <input
                ref={inputRef}
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Search articles, categories..."
                className="w-full px-4 py-3 pl-12 input-field rounded-lg focus:outline-none text-lg"
              />
              <svg 
                className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400"
                fill="none" 
                stroke="currentColor" 
                viewBox="0 0 24 24"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </div>
            
            <button
              onClick={() => setShowFilters(!showFilters)}
              className={`px-4 py-3 rounded-lg transition-colors touch-manipulation ${
                showFilters 
                  ? 'bg-blue-600 text-white' 
                  : ''
              }`}
              style={{
                backgroundColor: showFilters 
                  ? '' 
                  : (document.documentElement.classList.contains('dark') ? '#374151' : '#f3f4f6')
              }}
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.414A1 1 0 013 6.707V4z" />
              </svg>
            </button>
            
            <button
              onClick={handleClose}
              className="p-3 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors touch-manipulation"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>

          {/* Mobile: Simple layout */}
          <div className="sm:hidden">
            {/* Search input with filter and close buttons */}
            <div className="flex items-center space-x-2">
              <div className="flex-1 relative">
                <input
                  ref={inputRef}
                  type="text"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Search articles, categories..."
                  className="w-full px-3 py-2 pl-10 input-field rounded-lg focus:outline-none text-base"
                />
                <svg 
                  className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400"
                  fill="none" 
                  stroke="currentColor" 
                  viewBox="0 0 24 24"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </div>
              
              <button
                onClick={() => setShowFilters(!showFilters)}
                className={`p-2 rounded-lg transition-colors touch-manipulation ${
                  showFilters 
                    ? 'bg-blue-600 text-white' 
                    : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300'
                }`}
                title={showFilters ? 'Hide Filters' : 'Show Filters'}
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.414A1 1 0 013 6.707V4z" />
                </svg>
              </button>
              
              <button
                onClick={handleClose}
                className="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors touch-manipulation"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
          </div>

          {/* Filters */}
          {showFilters && (
            <div className="mt-4 p-4 glassmorphism-light rounded-lg">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* Category Filter */}
                <div>
                  <label className="block text-sm font-medium text-primary mb-2">Category</label>
                  <select
                    value={filters.category || ''}
                    onChange={(e) => setFilters({ ...filters, category: e.target.value || undefined })}
                    className="w-full px-3 py-2 input-field rounded-lg text-sm"
                  >
                    <option value="">All Categories</option>
                    {categories.map((category) => (
                      <option key={category.documentId} value={category.slug}>
                        {category.name}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Sort By */}
                <div>
                  <label className="block text-sm font-medium text-primary mb-2">Sort By</label>
                  <select
                    value={filters.sortBy || 'relevance'}
                    onChange={(e) => setFilters({ ...filters, sortBy: e.target.value as any })}
                    className="w-full px-3 py-2 input-field rounded-lg text-sm"
                  >
                    <option value="relevance">Relevance</option>
                    <option value="date">Date</option>
                    <option value="title">Title</option>
                  </select>
                </div>

                {/* Sort Order */}
                <div>
                  <label className="block text-sm font-medium text-primary mb-2">Order</label>
                  <select
                    value={filters.sortOrder || 'desc'}
                    onChange={(e) => setFilters({ ...filters, sortOrder: e.target.value as any })}
                    className="w-full px-3 py-2 input-field rounded-lg text-sm"
                  >
                    <option value="desc">Descending</option>
                    <option value="asc">Ascending</option>
                  </select>
                </div>
              </div>
              
              <div className="mt-4 flex justify-end">
                <button
                  onClick={() => handleSearch()}
                  className="px-4 py-2 btn-gradient text-white rounded-lg font-medium"
                >
                  Apply Filters
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto max-h-96 bg-transparent">
          {/* Search History */}
          {!query && searchHistory.length > 0 && (
            <div className="p-6">
              <h3 className="text-lg font-semibold text-primary mb-4">Recent Searches</h3>
              <div className="space-y-2">
                {searchHistory.map((historyQuery, index) => (
                  <button
                    key={index}
                    onClick={() => {
                      setQuery(historyQuery);
                      handleSearch(historyQuery);
                    }}
                    className="flex items-center justify-between w-full p-3 text-left rounded-lg transition-colors group"
                    style={{
                      backgroundColor: 'transparent'
                    }}
                    onMouseEnter={(e) => {
                      const isDark = document.documentElement.classList.contains('dark');
                      e.currentTarget.style.backgroundColor = isDark ? '#374151' : '#f3f4f6';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.backgroundColor = 'transparent';
                    }}
                  >
                    <div className="flex items-center space-x-3">
                      <svg className="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                      <span className="text-secondary">{historyQuery}</span>
                    </div>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        removeFromHistory(historyQuery);
                      }}
                      className="opacity-0 group-hover:opacity-100 p-1 text-gray-400 hover:text-red-500 transition-all"
                    >
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                      </svg>
                    </button>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Loading State */}
          {loading && (
            <div className="flex justify-center items-center py-12">
              <div className="relative">
                <div className="w-8 h-8 border-4 border-blue-200 dark:border-blue-800 rounded-full animate-spin"></div>
                <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin absolute top-0 left-0"></div>
              </div>
            </div>
          )}

          {/* Error State */}
          {error && (
            <div className="p-6 text-center">
              <div className="text-red-600 dark:text-red-400 mb-2">
                <svg className="w-12 h-12 mx-auto mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <p className="font-medium">Search Error</p>
                <p className="text-sm mt-1">{error}</p>
              </div>
            </div>
          )}

          {/* Results */}
          {!loading && !error && query && (
            <div className="p-6">
              {/* Results Summary */}
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-primary">
                  Search Results for "{query}"
                </h3>
                <p className="text-sm text-secondary mt-1">
                  {results.totalResults} results found in {results.searchTime}ms
                </p>
              </div>

              {/* No Results */}
              {results.totalResults === 0 && (
                <div className="text-center py-12">
                  <svg className="w-16 h-16 text-gray-400 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.172 16.172a4 4 0 015.656 0M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
                  <h3 className="text-lg font-medium text-primary mb-2">No results found</h3>
                  <p className="text-secondary">Try adjusting your search terms or filters</p>
                </div>
              )}

              {/* Categories Results */}
              {results.categories.length > 0 && (
                <div className="mb-8">
                  <h4 className="text-md font-semibold text-primary mb-4">Categories</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {results.categories.map((category) => (
                      <Link
                        key={category.documentId}
                        href={`/categories/${category.slug}`}
                        onClick={handleClose}
                        className="p-4 card-light rounded-lg hover:bg-white/80 dark:hover:bg-gray-600 transition-colors"
                      >
                        <h5 className="font-medium text-primary">
                          {highlightText(category.name, query)}
                        </h5>
                        {category.description && (
                          <p className="text-sm text-secondary mt-1">
                            {highlightText(category.description, query)}
                          </p>
                        )}
                      </Link>
                    ))}
                  </div>
                </div>
              )}

              {/* Articles Results */}
              {results.articles.length > 0 && (
                <div>
                  <h4 className="text-md font-semibold text-primary mb-4">Articles</h4>
                  <div className="space-y-4">
                    {results.articles.map((article) => (
                      <Link
                        key={article.documentId}
                        href={`/articles/${article.slug || article.documentId}`}
                        onClick={handleClose}
                        className="block p-4 card-light rounded-lg hover:bg-white/80 dark:hover:bg-gray-600 transition-colors"
                      >
                        <div className="flex space-x-4">
                          {article.cover?.url && (
                            <div className="flex-shrink-0">
                              <Image
                                src={STRAPI_URL + article.cover.url}
                                alt={article.cover.alternativeText || article.title}
                                width={80}
                                height={60}
                                className="rounded-lg object-cover"
                              />
                            </div>
                          )}
                          <div className="flex-1">
                            <h5 className="font-medium text-primary mb-2">
                              {highlightText(article.title, query)}
                            </h5>
                            {article.description && (
                              <p className="text-sm text-secondary mb-2 line-clamp-2">
                                {highlightText(article.description, query)}
                              </p>
                            )}
                            <div className="flex items-center space-x-4 text-xs text-secondary">
                              {article.author && (
                                <span>{highlightText(article.author.name, query)}</span>
                              )}
                              {article.category && (
                                <span className="px-2 py-1 bg-blue-100 dark:bg-blue-900 rounded">
                                  {highlightText(article.category.name, query)}
                                </span>
                              )}
                              {article.publishedAt && (
                                <span>{formatDate(article.publishedAt)}</span>
                              )}
                            </div>
                          </div>
                        </div>
                      </Link>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};