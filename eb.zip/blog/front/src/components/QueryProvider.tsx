"use client";

import { QueryClientProvider } from '@tanstack/react-query';
import { queryClient } from '@/lib/queryClient';
import dynamic from 'next/dynamic';

// Dynamically import devtools only in development (disabled for production)
// const ReactQueryDevtools = dynamic(
//   () => import('@tanstack/react-query-devtools').then((mod) => ({
//     default: mod.ReactQueryDevtools,
//   })),
//   { ssr: false }
// );

interface QueryProviderProps {
  children: React.ReactNode;
}

export function QueryProvider({ children }: QueryProviderProps) {
  return (
    <QueryClientProvider client={queryClient}>
      {children}
      {/* React Query Devtools disabled */}
    </QueryClientProvider>
  );
}