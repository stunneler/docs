"use client";

import Image from 'next/image';
import { PrefetchLink } from './PrefetchLink';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';

interface Article {
  documentId: string;
  title: string;
  description: string;
  slug: string;
  cover?: {
    url: string;
    alternativeText?: string;
    formats?: {
      medium?: { url: string };
      small?: { url: string };
      thumbnail?: { url: string };
    };
  };
  author?: {
    name: string;
    avatar?: { url: string };
  };
  category?: {
    name: string;
    slug: string;
  };
  publishedAt: string;
}

interface OptimizedArticleCardProps {
  article: Article;
  strapiUrl: string;
  index: number;
}

export const OptimizedArticleCard = ({ article, strapiUrl, index }: OptimizedArticleCardProps) => {
  const { ref, inView } = useInView({
    threshold: 0.1,
    triggerOnce: true,
  });

  const imageUrl = article.cover?.formats?.medium?.url || 
                   article.cover?.formats?.small?.url || 
                   article.cover?.url;

  const cardVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: {
        duration: 0.4,
        delay: index * 0.1,
        ease: "easeOut"
      }
    }
  };

  return (
    <motion.article
      ref={ref}
      variants={cardVariants}
      initial="hidden"
      animate={inView ? "visible" : "hidden"}
      whileHover={{ 
        scale: 1.02,
        transition: { duration: 0.2 }
      }}
      className="glassmorphism rounded-2xl overflow-hidden group cursor-pointer"
    >
      <PrefetchLink 
        href={`/articles/${article.slug}`}
        prefetchType="article"
        slug={article.slug}
        className="block"
      >
        {/* Cover Image */}
        {imageUrl && (
          <div className="relative w-full aspect-[21/9] overflow-hidden">
            <Image
              src={strapiUrl + imageUrl}
              alt={article.cover?.alternativeText || article.title}
              fill
              className="object-cover transition-transform duration-300 group-hover:scale-105"
              sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
              loading="lazy"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          </div>
        )}

        {/* Content */}
        <div className="p-6">
          {/* Category Badge */}
          {article.category && (
            <motion.span 
              className="inline-block px-3 py-1 text-xs font-medium bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300 rounded-full mb-3"
              whileHover={{ scale: 1.05 }}
            >
              {article.category.name}
            </motion.span>
          )}

          {/* Title */}
          <h2 className="text-xl lg:text-2xl font-bold text-primary mb-3 line-clamp-2 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
            {article.title}
          </h2>

          {/* Description */}
          {article.description && (
            <p className="text-secondary mb-4 line-clamp-3 leading-relaxed">
              {article.description}
            </p>
          )}

          {/* Meta Information */}
          <div className="flex items-center justify-between text-sm text-secondary">
            <div className="flex items-center space-x-3">
              {article.author && (
                <div className="flex items-center space-x-2">
                  {article.author.avatar?.url && (
                    <Image
                      src={strapiUrl + article.author.avatar.url}
                      alt={article.author.name}
                      width={24}
                      height={24}
                      className="rounded-full"
                    />
                  )}
                  <span className="font-medium">{article.author.name}</span>
                </div>
              )}
            </div>
            
            {article.publishedAt && (
              <time className="text-xs">
                {new Date(article.publishedAt).toLocaleDateString('en-US', {
                  month: 'short',
                  day: 'numeric',
                  year: 'numeric'
                })}
              </time>
            )}
          </div>

          {/* Read More Indicator */}
          <div className="flex items-center mt-4 text-blue-600 dark:text-blue-400 font-medium text-sm group-hover:translate-x-1 transition-transform">
            <span>Read more</span>
            <svg className="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </div>
        </div>
      </PrefetchLink>
    </motion.article>
  );
};