"use client";

import Image from 'next/image';

interface AboutBlock {
  __component: string;
  id: number;
  title?: string;
  body?: string;
  media?: {
    url: string;
    alternativeText?: string;
    caption?: string;
  };
}

interface AboutContentProps {
  blocks: AboutBlock[];
  strapiUrl: string;
}

export const AboutContent = ({ blocks, strapiUrl }: AboutContentProps) => {
  const renderBlock = (block: AboutBlock) => {
    switch (block.__component) {
      case 'shared.rich-text':
        return (
          <div key={block.id} className="prose prose-lg dark:prose-invert max-w-none mb-8">
            <div 
              className="text-primary leading-relaxed"
              dangerouslySetInnerHTML={{ __html: formatMarkdown(block.body || '') }}
            />
          </div>
        );
      
      case 'shared.quote':
        return (
          <blockquote key={block.id} className="border-l-4 border-blue-500 pl-6 py-4 my-8 bg-gray-50 dark:bg-gray-800 rounded-r-lg">
            <p className="text-xl italic text-secondary mb-3">"{block.body}"</p>
            {block.title && (
              <cite className="text-sm font-semibold text-primary">— {block.title}</cite>
            )}
          </blockquote>
        );
      
      case 'shared.media':
        return (
          <div key={block.id} className="my-8">
            {block.media?.url && (
              <div className="relative w-full h-96 rounded-2xl overflow-hidden shadow-lg">
                <Image
                  src={strapiUrl + block.media.url}
                  alt={block.media.alternativeText || 'About image'}
                  fill
                  className="object-cover"
                />
                {block.media.caption && (
                  <div className="absolute bottom-0 left-0 right-0 bg-black/50 text-white p-4">
                    <p className="text-sm">{block.media.caption}</p>
                  </div>
                )}
              </div>
            )}
          </div>
        );
      
      case 'shared.slider':
        return (
          <div key={block.id} className="my-8">
            <div className="bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20 rounded-2xl p-8 text-center">
              <div className="w-16 h-16 bg-blue-100 dark:bg-blue-800 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-blue-600 dark:text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
              </div>
              <h3 className="text-lg font-semibold text-primary mb-2">Image Slider</h3>
              <p className="text-secondary">Interactive image slider component would be rendered here</p>
            </div>
          </div>
        );
      
      case 'shared.toggle':
        return (
          <div key={block.id} className="my-8">
            <details className="glassmorphism rounded-2xl overflow-hidden">
              <summary className="p-6 cursor-pointer hover:bg-white/50 dark:hover:bg-gray-800/50 transition-colors">
                <h3 className="text-lg font-semibold text-primary inline">
                  {block.title || 'Toggle Section'}
                </h3>
              </summary>
              <div className="px-6 pb-6">
                <div 
                  className="prose prose-lg dark:prose-invert max-w-none"
                  dangerouslySetInnerHTML={{ __html: formatMarkdown(block.body || '') }}
                />
              </div>
            </details>
          </div>
        );
      
      default:
        return (
          <div key={block.id} className="my-4 p-4 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg border border-yellow-200 dark:border-yellow-800">
            <p className="text-sm text-yellow-800 dark:text-yellow-200">
              Unknown block type: {block.__component}
            </p>
            {block.title && (
              <p className="text-sm font-medium text-yellow-900 dark:text-yellow-100 mt-1">
                Title: {block.title}
              </p>
            )}
          </div>
        );
    }
  };

  const formatMarkdown = (content: string) => {
    // Enhanced markdown to HTML conversion
    return content
      // Headers
      .replace(/^### (.*$)/gm, '<h3 class="text-xl font-bold text-primary mb-3 mt-6">$1</h3>')
      .replace(/^## (.*$)/gm, '<h2 class="text-2xl font-bold text-primary mb-4 mt-8">$1</h2>')
      .replace(/^# (.*$)/gm, '<h1 class="text-3xl font-bold text-primary mb-6 mt-8">$1</h1>')
      
      // Text formatting
      .replace(/\*\*(.*?)\*\*/g, '<strong class="font-semibold">$1</strong>')
      .replace(/\*(.*?)\*/g, '<em class="italic">$1</em>')
      .replace(/`(.*?)`/g, '<code class="bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded text-sm font-mono">$1</code>')
      
      // Links
      .replace(/\[(.*?)\]\((.*?)\)/g, '<a href="$2" class="text-blue-600 dark:text-blue-400 hover:underline" target="_blank" rel="noopener noreferrer">$1</a>')
      
      // Lists
      .replace(/^[\*\-\+] (.+)$/gm, '<li class="ml-4 mb-1">$1</li>')
      .replace(/^(\d+)\. (.+)$/gm, '<li class="ml-4 mb-1">$2</li>')
      
      // Blockquotes
      .replace(/^> (.+)$/gm, '<blockquote class="border-l-4 border-gray-300 dark:border-gray-600 pl-4 italic text-secondary">$1</blockquote>')
      
      // Line breaks and paragraphs
      .replace(/\n\n/g, '</p><p class="text-primary leading-relaxed mb-6">')
      .replace(/^(?!<[h|u|l|b])(.+)$/gm, '<p class="text-primary leading-relaxed mb-6">$1</p>')
      
      // Clean up empty paragraphs
      .replace(/<p class="text-primary leading-relaxed mb-6"><\/p>/g, '')
      
      // Wrap lists
      .replace(/(<li.*<\/li>)/s, '<ul class="list-disc list-inside mb-6 space-y-1">$1</ul>');
  };

  return (
    <div className="about-content">
      {blocks.map(renderBlock)}
    </div>
  );
};