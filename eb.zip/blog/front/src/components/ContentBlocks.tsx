"use client";

import Image from 'next/image';
import { useState, useEffect } from 'react';
import { ContentBlock } from '@/types';

interface ContentBlocksProps {
  blocks: ContentBlock[];
  strapiUrl: string;
}

const QuoteComponent = ({ block }: { block: any }) => (
  <div className="glassmorphism rounded-2xl p-8 my-8 border-l-4 border-blue-500">
    <blockquote className="text-xl lg:text-2xl italic text-primary mb-4 leading-relaxed">
      "{block.body}"
    </blockquote>
    <cite className="text-secondary font-semibold">— {block.title}</cite>
  </div>
);

const RichTextComponent = ({ block }: { block: any }) => {
  // Enhanced markdown-to-HTML converter
  const formatMarkdown = (text: string) => {
    return text
      .replace(/## (.*)/g, '<h2 class="text-2xl font-bold text-primary mb-4 mt-6">$1</h2>')
      .replace(/\*\*(.*?)\*\*/g, '<strong class="font-semibold">$1</strong>')
      .replace(/\*(.*?)\*/g, '<em class="italic">$1</em>')
      .replace(/- (.*)/g, '<li class="ml-4">$1</li>')
      .replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" class="text-blue-600 dark:text-blue-400 hover:underline" target="_blank" rel="noopener noreferrer">$1</a>')
      .replace(/\n\n/g, '</p><p class="text-secondary leading-relaxed mb-4">')
      .replace(/\n/g, '<br />');
  };

  return (
    <div className="glassmorphism rounded-2xl p-8 my-8">
      <div 
        className="prose prose-lg max-w-none"
        dangerouslySetInnerHTML={{ 
          __html: `<div class="text-secondary leading-relaxed">${formatMarkdown(block.body)}</div>`
        }}
      />
    </div>
  );
};

const MediaComponent = ({ block, strapiUrl }: { block: any; strapiUrl: string }) => {
  
  // Try multiple possible data structures (About page style vs Article style)
  let mediaData = null;
  let imageUrl = '';
  let altText = '';
  
  // Check for About page style: block.media.url
  if (block.media?.url) {
    mediaData = block.media;
    imageUrl = block.media.url;
    altText = block.media.alternativeText || 'Media content';
  }
  // Check for nested file structure: block.file.data.attributes
  else if (block.file?.data?.attributes?.url) {
    mediaData = block.file.data.attributes;
    imageUrl = block.file.data.attributes.formats?.medium?.url || block.file.data.attributes.url;
    altText = block.file.data.attributes.alternativeText || block.file.data.attributes.name || 'Media content';
  }
  // Check for direct file structure: block.file.url
  else if (block.file?.url) {
    mediaData = block.file;
    imageUrl = block.file.formats?.medium?.url || block.file.url;
    altText = block.file.alternativeText || block.file.name || 'Media content';
  }
  
  if (!mediaData || !imageUrl) {
    return (
      <div className="glassmorphism rounded-2xl p-8 my-8 text-center">
        <div className="w-16 h-16 bg-gray-200 dark:bg-gray-700 rounded-full flex items-center justify-center mx-auto mb-4">
          <svg className="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
          </svg>
        </div>
        <p className="text-secondary">Media content not available</p>
      </div>
    );
  }

  return (
    <div className="glassmorphism rounded-2xl p-8 my-8">
      <div className="relative w-full h-96 rounded-lg overflow-hidden">
        <Image
          src={strapiUrl + imageUrl}
          alt={altText}
          fill
          className="object-cover"
          priority={false}
        />
      </div>
      {altText && altText !== 'Media content' && (
        <p className="text-center text-secondary mt-4 italic">
          {altText}
        </p>
      )}
    </div>
  );
};

const SliderComponent = ({ block, strapiUrl }: { block: any; strapiUrl: string }) => {
  const [currentSlide, setCurrentSlide] = useState(0);
  
  
  // Try multiple possible data structures for files
  let filesArray = [];
  
  // Check for direct files array
  if (block.files && Array.isArray(block.files)) {
    filesArray = block.files;
  }
  // Check for nested files structure: block.files.data
  else if (block.files?.data && Array.isArray(block.files.data)) {
    filesArray = block.files.data.map((file: any) => file.attributes || file);
  }
  // Check for About page style: block.images
  else if (block.images && Array.isArray(block.images)) {
    filesArray = block.images;
  }
  
  if (!filesArray || filesArray.length === 0) {
    return (
      <div className="glassmorphism rounded-2xl p-8 my-8 text-center">
        <div className="w-16 h-16 bg-gray-200 dark:bg-gray-700 rounded-full flex items-center justify-center mx-auto mb-4">
          <svg className="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2 2v12a2 2 0 002 2z" />
          </svg>
        </div>
        <p className="text-secondary">Slider content not available</p>
      </div>
    );
  }

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % filesArray.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + filesArray.length) % filesArray.length);
  };

  const currentFile = filesArray[currentSlide];
  const imageUrl = currentFile.formats?.medium?.url || currentFile.url;

  return (
    <div className="glassmorphism rounded-2xl p-8 my-8">
      <div className="relative w-full h-96 rounded-lg overflow-hidden">
        <Image
          src={strapiUrl + imageUrl}
          alt={currentFile.alternativeText || currentFile.name || `Slide ${currentSlide + 1}`}
          fill
          className="object-cover"
          priority={false}
        />
        
        {/* Navigation buttons */}
        {filesArray.length > 1 && (
          <>
            <button
              onClick={prevSlide}
              className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-black/50 text-white p-2 rounded-full hover:bg-black/70 transition-colors"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
              </svg>
            </button>
            <button
              onClick={nextSlide}
              className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-black/50 text-white p-2 rounded-full hover:bg-black/70 transition-colors"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </button>
          </>
        )}
        
        {/* Slide indicators */}
        {filesArray.length > 1 && (
          <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
            {filesArray.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentSlide(index)}
                className={`w-3 h-3 rounded-full transition-colors ${
                  index === currentSlide ? 'bg-white' : 'bg-white/50'
                }`}
              />
            ))}
          </div>
        )}
      </div>
      
      {/* Image info */}
      <div className="flex justify-between items-center mt-4">
        {currentFile.alternativeText && (
          <p className="text-secondary italic">{currentFile.alternativeText}</p>
        )}
        {filesArray.length > 1 && (
          <p className="text-secondary text-sm">
            {currentSlide + 1} / {filesArray.length}
          </p>
        )}
      </div>
    </div>
  );
};

export const ContentBlocks = ({ blocks, strapiUrl }: ContentBlocksProps) => {
  if (!blocks || blocks.length === 0) {
    return (
      <div className="glassmorphism rounded-2xl p-8 my-8 text-center">
        <p className="text-secondary">No content blocks available</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {blocks.map((block, index) => {
        switch (block.__component) {
          case 'shared.quote':
            return <QuoteComponent key={`quote-${block.id}-${index}`} block={block} />;
          case 'shared.rich-text':
            return <RichTextComponent key={`richtext-${block.id}-${index}`} block={block} />;
          case 'shared.media':
            return <MediaComponent key={`media-${block.id}-${index}`} block={block} strapiUrl={strapiUrl} />;
          case 'shared.slider':
            return <SliderComponent key={`slider-${block.id}-${index}`} block={block} strapiUrl={strapiUrl} />;
          default:
            return (
              <div key={`unknown-${index}`} className="glassmorphism rounded-2xl p-8 my-8">
                <p className="text-secondary">Unknown content type: {block.__component}</p>
              </div>
            );
        }
      })}
    </div>
  );
};
