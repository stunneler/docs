"use client";

import { useState, useEffect } from 'react';

interface LikeButtonProps {
  articleSlug: string;
  className?: string;
}

export const LikeButton = ({ articleSlug, className = "" }: LikeButtonProps) => {
  const [liked, setLiked] = useState(false);
  const [likeCount, setLikeCount] = useState(0);
  const [loading, setLoading] = useState(false);
  const [animating, setAnimating] = useState(false);

  // Fetch initial like status
  useEffect(() => {
    const fetchLikeStatus = async () => {
      try {
        const response = await fetch(`/api/articles/${articleSlug}/like`);
        if (response.ok) {
          const data = await response.json();
          setLiked(data.liked);
          setLikeCount(data.likeCount);
        }
      } catch (error) {
        console.error('Error fetching like status:', error);
      }
    };

    if (articleSlug) {
      fetchLikeStatus();
    }
  }, [articleSlug]);

  const handleLike = async () => {
    if (loading) return;
    
    setLoading(true);
    setAnimating(true);
    
    try {
      const response = await fetch(`/api/articles/${articleSlug}/like`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (response.ok) {
        const data = await response.json();
        setLiked(data.liked);
        setLikeCount(data.likeCount);
        
        // Reset animation after a short delay
        setTimeout(() => setAnimating(false), 300);
      } else {
        console.error('Failed to toggle like');
        setAnimating(false);
      }
    } catch (error) {
      console.error('Error toggling like:', error);
      setAnimating(false);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={`glassmorphism rounded-2xl p-6 mt-8 ${className}`}>
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold text-primary mb-1">
            Enjoyed this article?
          </h3>
          <p className="text-secondary text-sm">
            Show your appreciation with a like!
          </p>
        </div>
        
        <div className="flex items-center space-x-4">
          {/* Like Count Display */}
          <div className="text-center">
            <div className="text-2xl font-bold text-primary">
              {likeCount}
            </div>
            <div className="text-xs text-secondary">
              {likeCount === 1 ? 'like' : 'likes'}
            </div>
          </div>
          
          {/* Like Button */}
          <button
            onClick={handleLike}
            disabled={loading}
            className={`
              relative flex items-center justify-center w-16 h-16 rounded-full
              transition-all duration-300 transform
              ${liked 
                ? 'bg-red-500 text-white shadow-lg scale-105' 
                : 'bg-gray-100 dark:bg-gray-700 text-gray-400 hover:bg-red-50 dark:hover:bg-red-900/20 hover:text-red-500'
              }
              ${animating ? 'animate-pulse scale-110' : ''}
              ${loading ? 'cursor-not-allowed opacity-70' : 'cursor-pointer hover:scale-110'}
              focus:outline-none focus:ring-4 focus:ring-red-200 dark:focus:ring-red-800
            `}
            title={liked ? 'Unlike this article' : 'Like this article'}
          >
            {/* Heart Icon */}
            <svg 
              className={`w-8 h-8 transition-all duration-200 ${animating ? 'scale-125' : ''}`}
              fill={liked ? 'currentColor' : 'none'} 
              stroke="currentColor" 
              viewBox="0 0 24 24"
            >
              <path 
                strokeLinecap="round" 
                strokeLinejoin="round" 
                strokeWidth={liked ? 0 : 2} 
                d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" 
              />
            </svg>
            
            {/* Loading Spinner */}
            {loading && (
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              </div>
            )}
          </button>
        </div>
      </div>
      
      {/* Like Animation Particles */}
      {animating && liked && (
        <div className="absolute inset-0 pointer-events-none">
          {[...Array(6)].map((_, i) => (
            <div
              key={i}
              className="absolute w-2 h-2 bg-red-500 rounded-full animate-ping"
              style={{
                top: `${Math.random() * 100}%`,
                left: `${Math.random() * 100}%`,
                animationDelay: `${i * 100}ms`,
                animationDuration: '600ms'
              }}
            />
          ))}
        </div>
      )}
    </div>
  );
};