"use client";

import { ContentBlock } from '@/types';

interface ArticleContentProps {
  blocks: ContentBlock[];
}

export const ArticleContent = ({ blocks }: ArticleContentProps) => {
  const renderBlock = (block: ContentBlock) => {
    switch (block.__component) {
      case 'shared.rich-text':
        return (
          <div key={block.id} className="prose prose-lg dark:prose-invert max-w-none mb-8">
            <div 
              className="text-primary leading-relaxed"
              dangerouslySetInnerHTML={{ __html: formatMarkdown(block.body || '') }}
            />
          </div>
        );
      
      case 'shared.quote':
        return (
          <blockquote key={block.id} className="border-l-4 border-blue-500 pl-6 py-4 my-8 bg-gray-50 dark:bg-gray-800 rounded-r-lg">
            <p className="text-lg italic text-secondary mb-2">"{block.body}"</p>
            {block.title && (
              <cite className="text-sm font-semibold text-primary">— {block.title}</cite>
            )}
          </blockquote>
        );
      
      case 'shared.media':
        return (
          <div key={block.id} className="my-8 text-center">
            <div className="bg-gray-100 dark:bg-gray-800 rounded-lg p-8">
              <p className="text-secondary">Media component placeholder</p>
            </div>
          </div>
        );
      
      case 'shared.slider':
        return (
          <div key={block.id} className="my-8 text-center">
            <div className="bg-gray-100 dark:bg-gray-800 rounded-lg p-8">
              <p className="text-secondary">Slider component placeholder</p>
            </div>
          </div>
        );
      
      default:
        return (
          <div key={block.id} className="my-4 p-4 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg">
            <p className="text-sm text-yellow-800 dark:text-yellow-200">
              Unknown block type: {block.__component}
            </p>
          </div>
        );
    }
  };

  const formatMarkdown = (content: string) => {
    // Basic markdown to HTML conversion
    return content
      .replace(/^## (.*$)/gm, '<h2 class="text-2xl font-bold text-primary mb-4 mt-8">$1</h2>')
      .replace(/^### (.*$)/gm, '<h3 class="text-xl font-bold text-primary mb-3 mt-6">$1</h3>')
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.*?)\*/g, '<em>$1</em>')
      .replace(/\[(.*?)\]\((.*?)\)/g, '<a href="$2" class="text-blue-600 dark:text-blue-400 hover:underline">$1</a>')
      .replace(/^- (.*$)/gm, '<li class="ml-4">$1</li>')
      .replace(/(<li.*<\/li>)/s, '<ul class="list-disc list-inside mb-4 space-y-1">$1</ul>')
      .replace(/\n\n/g, '</p><p class="text-primary leading-relaxed mb-6">')
      .replace(/^(?!<[h|u|l])(.+)$/gm, '<p class="text-primary leading-relaxed mb-6">$1</p>');
  };

  return (
    <div className="article-content">
      {blocks && Array.isArray(blocks) && blocks.length > 0 ? (
        blocks.map(renderBlock)
      ) : (
        <div className="text-center py-8">
          <p className="text-secondary">No content available for this article.</p>
        </div>
      )}
    </div>
  );
};