"use client";

import { useState, useEffect } from 'react';

interface WebhookEvent {
  id: string;
  event: string;
  model: string;
  timestamp: string;
  status: 'success' | 'error' | 'pending';
  message?: string;
}

export const WebhookStatus = () => {
  const [events, setEvents] = useState<WebhookEvent[]>([]);
  const [isOpen, setIsOpen] = useState(false);

  // Load webhook events from localStorage and simulate real-time updates
  useEffect(() => {
    // Load existing events from localStorage
    const savedEvents = localStorage.getItem('webhookEvents');
    if (savedEvents) {
      try {
        setEvents(JSON.parse(savedEvents));
      } catch (error) {
        console.error('Error loading webhook events:', error);
      }
    } else {
      // Initialize with mock events if no saved events
      const mockEvents: WebhookEvent[] = [
        {
          id: '1',
          event: 'entry.create',
          model: 'article',
          timestamp: new Date().toISOString(),
          status: 'success',
          message: 'New article published successfully'
        },
        {
          id: '2',
          event: 'entry.create',
          model: 'newsletter-subscription',
          timestamp: new Date(Date.now() - 180000).toISOString(),
          status: 'success',
          message: 'Newsletter subscription processed'
        },
        {
          id: '3',
          event: 'entry.update',
          model: 'article',
          timestamp: new Date(Date.now() - 780000).toISOString(),
          status: 'error',
          message: 'Failed to update search index'
        }
      ];
      
      setEvents(mockEvents);
      localStorage.setItem('webhookEvents', JSON.stringify(mockEvents));
    }

    // Simulate real-time webhook events every 30 seconds
    const interval = setInterval(() => {
      const eventTypes = ['entry.create', 'entry.update', 'entry.delete'];
      const models = ['article', 'newsletter-subscription', 'category'];
      const statuses: ('success' | 'error' | 'pending')[] = ['success', 'success', 'success', 'error'];
      const messages = [
        'New article published successfully',
        'Newsletter subscription processed',
        'Article updated successfully',
        'Category created',
        'Failed to update search index',
        'Email delivery failed',
        'Cache invalidation completed'
      ];

      const newEvent: WebhookEvent = {
        id: Date.now().toString(),
        event: eventTypes[Math.floor(Math.random() * eventTypes.length)],
        model: models[Math.floor(Math.random() * models.length)],
        timestamp: new Date().toISOString(),
        status: statuses[Math.floor(Math.random() * statuses.length)],
        message: messages[Math.floor(Math.random() * messages.length)]
      };

      setEvents(prevEvents => {
        const updatedEvents = [newEvent, ...prevEvents].slice(0, 20); // Keep only last 20 events
        localStorage.setItem('webhookEvents', JSON.stringify(updatedEvents));
        return updatedEvents;
      });
    }, 30000); // Every 30 seconds

    return () => clearInterval(interval);
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'success':
        return 'text-green-600 dark:text-green-400';
      case 'error':
        return 'text-red-600 dark:text-red-400';
      case 'pending':
        return 'text-yellow-600 dark:text-yellow-400';
      default:
        return 'text-gray-600 dark:text-gray-400';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'success':
        return (
          <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
          </svg>
        );
      case 'error':
        return (
          <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
          </svg>
        );
      case 'pending':
        return (
          <svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="m4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
        );
      default:
        return null;
    }
  };

  const formatTimestamp = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    
    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffMins < 1440) return `${Math.floor(diffMins / 60)}h ago`;
    return date.toLocaleDateString();
  };

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-20 right-4 lg:right-8 p-3 bg-purple-600 hover:bg-purple-700 text-white rounded-full shadow-lg transition-all duration-300 hover:scale-110 z-40"
        title="Webhook Status"
      >
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
        </svg>
      </button>
    );
  }

  return (
    <div className="fixed bottom-20 right-4 lg:right-8 z-40">
      {/* Webhook Status Panel */}
      <div className="glassmorphism rounded-2xl p-4 w-80 max-h-96 overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            <svg className="w-5 h-5 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
            <h3 className="text-lg font-semibold text-primary">Webhook Events</h3>
          </div>
          <button
            onClick={() => setIsOpen(false)}
            className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Events List */}
        <div className="space-y-3 max-h-64 overflow-y-auto">
          {events.length === 0 ? (
            <div className="text-center py-8">
              <svg className="w-12 h-12 text-gray-400 mx-auto mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
              <p className="text-secondary">No webhook events yet</p>
            </div>
          ) : (
            events.map((event) => (
              <div key={event.id} className="bg-white/50 dark:bg-gray-800/50 rounded-lg p-3 border border-gray-200/50 dark:border-gray-700/50">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-1">
                      <span className={`flex items-center ${getStatusColor(event.status)}`}>
                        {getStatusIcon(event.status)}
                      </span>
                      <span className="text-sm font-medium text-primary">
                        {event.event}
                      </span>
                      <span className="text-xs px-2 py-1 bg-gray-100 dark:bg-gray-700 rounded text-secondary">
                        {event.model}
                      </span>
                    </div>
                    {event.message && (
                      <p className="text-xs text-secondary mb-1">{event.message}</p>
                    )}
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      {formatTimestamp(event.timestamp)}
                    </p>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="mt-4 pt-3 border-t border-gray-200/50 dark:border-gray-700/50">
          <div className="flex items-center justify-between text-xs text-secondary mb-3">
            <span>Real-time webhook monitoring</span>
            <div className="flex items-center space-x-1">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              <span>Live</span>
            </div>
          </div>
          
          {/* Action Buttons */}
          <div className="flex space-x-2">
            <button
              onClick={() => {
                setEvents([]);
                localStorage.removeItem('webhookEvents');
              }}
              className="flex-1 px-3 py-2 text-xs bg-gray-100 dark:bg-gray-700 text-secondary hover:bg-gray-200 dark:hover:bg-gray-600 rounded-lg transition-colors"
            >
              Clear Events
            </button>
            <button
              onClick={async () => {
                try {
                  await fetch('/api/webhooks/test', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ eventType: 'article-create', model: 'article' })
                  });
                } catch (error) {
                  console.error('Error triggering test webhook:', error);
                }
              }}
              className="flex-1 px-3 py-2 text-xs bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300 hover:bg-blue-200 dark:hover:bg-blue-800 rounded-lg transition-colors"
            >
              Test Event
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};