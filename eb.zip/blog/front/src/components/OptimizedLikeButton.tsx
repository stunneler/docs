"use client";

import { useOptimizedLikes } from '@/hooks/useOptimizedLikes';
import { motion, AnimatePresence } from 'framer-motion';

interface OptimizedLikeButtonProps {
  articleSlug: string;
  className?: string;
}

export const OptimizedLikeButton = ({ articleSlug, className = "" }: OptimizedLikeButtonProps) => {
  const { liked, likeCount, loading, animating, handleLike, isToggling } = useOptimizedLikes(articleSlug);

  return (
    <div className={`glassmorphism rounded-2xl p-6 mt-8 ${className}`}>
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold text-primary mb-1">
            Enjoyed this article?
          </h3>
          <p className="text-secondary text-sm">
            Show your appreciation with a like!
          </p>
        </div>
        
        <div className="flex items-center space-x-4">
          {/* Like Count Display with Animation */}
          <div className="text-center">
            <AnimatePresence mode="wait">
              <motion.div
                key={likeCount}
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 1.2, opacity: 0 }}
                transition={{ duration: 0.2 }}
                className="text-2xl font-bold text-primary"
              >
                {likeCount}
              </motion.div>
            </AnimatePresence>
            <div className="text-xs text-secondary">
              {likeCount === 1 ? 'like' : 'likes'}
            </div>
          </div>
          
          {/* Optimized Like Button */}
          <motion.button
            onClick={handleLike}
            disabled={loading || isToggling}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
            className={`
              relative flex items-center justify-center w-16 h-16 rounded-full
              transition-all duration-300
              ${liked 
                ? 'bg-red-500 text-white shadow-lg' 
                : 'bg-gray-100 dark:bg-gray-700 text-gray-400 hover:bg-red-50 dark:hover:bg-red-900/20 hover:text-red-500'
              }
              ${loading || isToggling ? 'cursor-not-allowed opacity-70' : 'cursor-pointer'}
              focus:outline-none focus:ring-4 focus:ring-red-200 dark:focus:ring-red-800
            `}
            title={liked ? 'Unlike this article' : 'Like this article'}
          >
            {/* Heart Icon with Animation */}
            <motion.svg 
              className="w-8 h-8"
              fill={liked ? 'currentColor' : 'none'} 
              stroke="currentColor" 
              viewBox="0 0 24 24"
              animate={{
                scale: animating ? [1, 1.3, 1] : 1,
              }}
              transition={{ duration: 0.3 }}
            >
              <path 
                strokeLinecap="round" 
                strokeLinejoin="round" 
                strokeWidth={liked ? 0 : 2} 
                d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" 
              />
            </motion.svg>
            
            {/* Loading Spinner */}
            <AnimatePresence>
              {(loading || isToggling) && (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="absolute inset-0 flex items-center justify-center"
                >
                  <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.button>
        </div>
      </div>
      
      {/* Like Animation Particles */}
      <AnimatePresence>
        {animating && liked && (
          <div className="absolute inset-0 pointer-events-none overflow-hidden">
            {[...Array(8)].map((_, i) => (
              <motion.div
                key={i}
                initial={{ 
                  scale: 0,
                  x: "50%",
                  y: "50%",
                  opacity: 1
                }}
                animate={{ 
                  scale: [0, 1, 0],
                  x: `${50 + (Math.random() - 0.5) * 200}%`,
                  y: `${50 + (Math.random() - 0.5) * 200}%`,
                  opacity: [1, 1, 0]
                }}
                transition={{ 
                  duration: 0.8,
                  delay: i * 0.1,
                  ease: "easeOut"
                }}
                className="absolute w-3 h-3 bg-red-500 rounded-full"
              />
            ))}
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};