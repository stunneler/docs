"use client";

import Link from 'next/link';
import { useInView } from 'react-intersection-observer';
import { prefetchArticle, prefetchCategories } from '@/lib/queryClient';
import { useEffect } from 'react';

interface PrefetchLinkProps {
  href: string;
  children: React.ReactNode;
  className?: string;
  prefetchType?: 'article' | 'category' | 'articles';
  slug?: string;
}

export const PrefetchLink = ({ 
  href, 
  children, 
  className, 
  prefetchType,
  slug 
}: PrefetchLinkProps) => {
  const { ref, inView } = useInView({
    threshold: 0.1,
    triggerOnce: true,
  });

  useEffect(() => {
    if (inView) {
      // Prefetch based on type
      if (prefetchType === 'article' && slug) {
        prefetchArticle(slug);
      } else if (prefetchType === 'category') {
        prefetchCategories();
      }
    }
  }, [inView, prefetchType, slug]);

  return (
    <Link 
      href={href} 
      className={className}
      ref={ref}
      onMouseEnter={() => {
        // Prefetch on hover for even faster navigation
        if (prefetchType === 'article' && slug) {
          prefetchArticle(slug);
        } else if (prefetchType === 'category') {
          prefetchCategories();
        }
      }}
    >
      {children}
    </Link>
  );
};