"use client";

import { useOptimizedLikes } from '@/hooks/useOptimizedLikes';

interface SimpleLikeButtonProps {
  articleSlug: string;
  className?: string;
}

export const SimpleLikeButton = ({ articleSlug, className = "" }: SimpleLikeButtonProps) => {
  const { liked, likeCount, loading, handleLike, isToggling } = useOptimizedLikes(articleSlug);

  return (
    <div className={`glassmorphism rounded-2xl p-4 sm:p-6 mt-8 ${className}`}>
      {/* Mobile Layout: Stacked */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
        <div className="text-center sm:text-left">
          <h3 className="text-lg sm:text-xl font-semibold text-primary mb-1">
            Enjoyed this article?
          </h3>
          <p className="text-secondary text-sm">
            Show your appreciation with a like!
          </p>
        </div>
        
        {/* Mobile-friendly like section */}
        <div className="flex items-center justify-center sm:justify-end space-x-4">
          {/* Like Count Display */}
          <div className="text-center">
            <div className="text-xl sm:text-2xl font-bold text-primary">
              {likeCount}
            </div>
            <div className="text-xs text-secondary">
              {likeCount === 1 ? 'like' : 'likes'}
            </div>
          </div>
          
          {/* Mobile-optimized Like Button */}
          <button
            onClick={handleLike}
            disabled={loading || isToggling}
            className={`
              relative flex items-center justify-center w-14 h-14 sm:w-16 sm:h-16 rounded-full
              transition-all duration-300 touch-manipulation
              ${liked 
                ? 'bg-red-500 text-white shadow-lg' 
                : 'bg-gray-100 dark:bg-gray-700 text-gray-400 hover:bg-red-50 dark:hover:bg-red-900/20 hover:text-red-500'
              }
              ${loading || isToggling ? 'cursor-not-allowed opacity-70' : 'cursor-pointer'}
              focus:outline-none focus:ring-4 focus:ring-red-200 dark:focus:ring-red-800
              active:scale-95
            `}
            title={liked ? 'Unlike this article' : 'Like this article'}
          >
            {/* Heart Icon - smaller on mobile */}
            <svg 
              className="w-6 h-6 sm:w-8 sm:h-8"
              fill={liked ? 'currentColor' : 'none'} 
              stroke="currentColor" 
              viewBox="0 0 24 24"
            >
              <path 
                strokeLinecap="round" 
                strokeLinejoin="round" 
                strokeWidth={liked ? 0 : 2} 
                d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" 
              />
            </svg>
            
            {/* Loading Spinner */}
            {(loading || isToggling) && (
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-5 h-5 sm:w-6 sm:h-6 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              </div>
            )}
          </button>
        </div>
      </div>
      
      {/* Mobile: Additional tap area hint */}
      <div className="block sm:hidden text-center mt-3">
        <p className="text-xs text-secondary opacity-75">
          Tap the heart to {liked ? 'unlike' : 'like'} this article
        </p>
      </div>
    </div>
  );
};