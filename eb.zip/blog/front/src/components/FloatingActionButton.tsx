"use client";

import { useState, useEffect } from 'react';
import { NewsletterModal } from './NewsletterModal';

export const FloatingActionButton = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const [isNewsletterOpen, setIsNewsletterOpen] = useState(false);

  useEffect(() => {
    const toggleVisibility = () => {
      if (window.pageYOffset > 300) {
        setIsVisible(true);
      } else {
        setIsVisible(false);
        setIsExpanded(false);
      }
    };

    window.addEventListener('scroll', toggleVisibility);
    return () => window.removeEventListener('scroll', toggleVisibility);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth',
    });
  };

  const shareCurrentPage = () => {
    if (navigator.share) {
      navigator.share({
        title: document.title,
        url: window.location.href,
      });
    } else {
      navigator.clipboard.writeText(window.location.href);
      // You could show a toast notification here
    }
  };

  const actions = [
    {
      icon: (
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 4.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
        </svg>
      ),
      label: 'Newsletter',
      action: () => setIsNewsletterOpen(true),
    },
    {
      icon: (
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.367 2.684 3 3 0 00-5.367-2.684z" />
        </svg>
      ),
      label: 'Share',
      action: shareCurrentPage,
    },
    {
      icon: (
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 15l7-7 7 7" />
        </svg>
      ),
      label: 'Back to Top',
      action: scrollToTop,
    },
  ];

  if (!isVisible) return null;

  return (
    <>
      <NewsletterModal 
        isOpen={isNewsletterOpen} 
        onClose={() => setIsNewsletterOpen(false)} 
      />
      
      <div className="fixed bottom-6 right-6 z-50">
      {/* Action Buttons */}
      {isExpanded && (
        <div className="mb-4 space-y-3">
          {actions.slice(0, -1).map((action, index) => (
            <button
              key={index}
              onClick={action.action}
              className="flex items-center justify-center w-12 h-12 rounded-full shadow-lg hover:shadow-xl border border-gray-300 dark:border-gray-600 text-gray-800 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400 transition-all duration-300 transform hover:scale-110 group"
              style={{
                backgroundColor: document.documentElement.classList.contains('dark') ? '#374151' : '#f3f4f6'
              }}
              title={action.label}
            >
              {action.icon}
              <span className="absolute right-14 bg-gray-800 dark:bg-gray-200 text-white dark:text-gray-800 text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap shadow-lg">
                {action.label}
              </span>
            </button>
          ))}
        </div>
      )}

      {/* Main FAB */}
      <button
        onClick={() => {
          if (isExpanded) {
            scrollToTop();
          } else {
            setIsExpanded(!isExpanded);
          }
        }}
        className="flex items-center justify-center w-14 h-14 text-gray-800 dark:text-gray-300 rounded-full shadow-lg hover:shadow-xl border border-gray-300 dark:border-gray-600 transition-all duration-300 transform hover:scale-110 focus:outline-none focus:ring-2 focus:ring-blue-500/50 hover:text-blue-600 dark:hover:text-blue-400"
        style={{
          backgroundColor: document.documentElement.classList.contains('dark') ? '#374151' : '#f3f4f6'
        }}
      >
        <svg
          className={`w-6 h-6 transition-transform duration-300 ${isExpanded ? 'rotate-45' : ''}`}
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          {isExpanded ? (
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
          ) : (
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 15l7-7 7 7" />
          )}
        </svg>
      </button>
    </div>
    </>
  );
};
