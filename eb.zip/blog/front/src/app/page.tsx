"use client";

import { Header } from '@/components/Header';
import { ArticleCard } from '@/components/ArticleCard';
import { LeftSidebar, RightSidebar } from '@/components/Sidebar';
import { Footer } from '@/components/Footer';
import { FloatingActionButton } from '@/components/FloatingActionButton';
import { useArticles } from '@/hooks/useArticles';

export default function Home() {
  const { 
    articles, 
    loading, 
    loadingMore, 
    error, 
    hasMore, 
    totalArticles, 
    searchArticles, 
    loadMoreArticles, 
    strapiUrl 
  } = useArticles();

  return (
    <div className="min-h-screen bg-light dark:bg-dark transition-all duration-300 overflow-x-hidden">
      {/* Header */}
      <Header onSearch={searchArticles} />
      
      {/* Content with top padding to account for fixed header */}
      <div className="pt-16">

      {/* Main Layout - Equal sidebars with proper grid */}
      <div className="w-full px-2 lg:px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 w-full max-w-full">
          {/* Left Sidebar - Increased to 3 columns to match right */}
          <div className="lg:col-span-3 min-w-0">
            <LeftSidebar articleCount={articles.length} />
          </div>

          {/* Main Content - Reduced to 6 columns */}
          <main className="lg:col-span-6 min-w-0">
            {/* Loading State */}
            {loading && (
              <div className="flex justify-center items-center py-20">
                <div className="relative">
                  <div className="w-20 h-20 border-4 border-blue-200 dark:border-blue-800 rounded-full animate-spin"></div>
                  <div className="w-20 h-20 border-4 border-blue-600 border-t-transparent rounded-full animate-spin absolute top-0 left-0"></div>
                </div>
              </div>
            )}

            {/* Error State */}
            {error && (
              <div className="glassmorphism rounded-2xl p-8 text-center border-2 border-red-200/30 dark:border-red-800/30">
                <div className="w-16 h-16 bg-red-100 dark:bg-red-900/50 rounded-full flex items-center justify-center mx-auto mb-4">
                  <svg className="w-8 h-8 text-red-600 dark:text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <h3 className="text-xl font-bold text-red-800 dark:text-red-200 mb-2">
                  Oops! Something went wrong
                </h3>
                <p className="text-red-600 dark:text-red-300">{error}</p>
              </div>
            )}

            {/* Articles Section */}
            {!loading && !error && (
              <>
                <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-8 gap-4">
                  <h2 className="text-2xl lg:text-3xl font-bold text-primary">
                    Latest Articles
                    <span className="ml-3 text-base lg:text-lg font-normal text-secondary">
                      ({articles.length} of {totalArticles} {totalArticles === 1 ? 'article' : 'articles'})
                    </span>
                  </h2>
                  
                  <div className="flex items-center space-x-2 flex-shrink-0">
                    <button className="px-4 lg:px-6 py-2 btn-secondary rounded-lg transition-all font-medium text-sm lg:text-base">
                      Latest
                    </button>
                  </div>
                </div>

                {articles.length === 0 ? (
                  <div className="glassmorphism rounded-2xl p-8 lg:p-12 text-center">
                    <div className="w-16 lg:w-20 h-16 lg:h-20 bg-gray-100 dark:bg-gray-700 rounded-full flex items-center justify-center mx-auto mb-6">
                      <svg className="w-8 lg:w-10 h-8 lg:h-10 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                      </svg>
                    </div>
                    <h3 className="text-lg lg:text-xl font-bold text-primary mb-3">
                      No articles found
                    </h3>
                    <p className="text-secondary">
                      No articles match your search criteria. Try adjusting your search terms or check back later for new content.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-6 lg:space-y-8">
                    {articles.map((article) => (
                      <ArticleCard
                        key={article.documentId}
                        article={article}
                        strapiUrl={strapiUrl}
                      />
                    ))}
                  </div>
                )}

                {/* Load More Button */}
                {articles.length > 0 && hasMore && (
                  <div className="text-center mt-8 lg:mt-12">
                    <button 
                      onClick={loadMoreArticles}
                      disabled={loadingMore}
                      className="btn-gradient px-6 lg:px-8 py-3 lg:py-4 text-white font-semibold rounded-lg shadow-lg text-base lg:text-lg disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300 hover:shadow-xl"
                    >
                      {loadingMore ? (
                        <div className="flex items-center space-x-2">
                          <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                          <span>Loading...</span>
                        </div>
                      ) : (
                        'Load More Articles'
                      )}
                    </button>
                  </div>
                )}

                {/* End of Articles Message */}
                {articles.length > 0 && !hasMore && !loading && (
                  <div className="text-center mt-8 lg:mt-12">
                    <div className="glassmorphism rounded-2xl p-6 inline-block">
                      <div className="flex items-center space-x-2 text-secondary">
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                        <span className="font-medium">You've reached the end! All articles loaded.</span>
                      </div>
                    </div>
                  </div>
                )}
              </>
            )}
          </main>

          {/* Right Sidebar - Remains 3 columns */}
          <div className="lg:col-span-3 min-w-0">
            <RightSidebar />
          </div>
        </div>
      </div>

      {/* Footer */}
      <Footer />

      {/* Floating Action Button */}
      <FloatingActionButton />
      </div>
    </div>
  );
}
