"use client";

import { Header } from '@/components/Header';
import { LeftSidebar, RightSidebar } from '@/components/Sidebar';
import { Footer } from '@/components/Footer';
import { FloatingActionButton } from '@/components/FloatingActionButton';
import { ContentBlocks } from '@/components/ContentBlocks';
import { useAbout } from '@/hooks/useAbout';

export default function AboutPage() {
  const { aboutData, loading, error, strapiUrl } = useAbout();

  return (
    <div className="min-h-screen bg-light dark:bg-dark transition-all duration-300 overflow-x-hidden">
      {/* Header */}
      <Header onSearch={() => {}} />
      
      {/* Content with top padding to account for fixed header */}
      <div className="pt-16">

      {/* Main Layout */}
      <div className="w-full px-2 lg:px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 w-full max-w-full">
          {/* Left Sidebar */}
          <div className="lg:col-span-3 min-w-0">
            <LeftSidebar />
          </div>

          {/* Main Content */}
          <main className="lg:col-span-6 min-w-0">
            {/* Loading State */}
            {loading && (
              <div className="flex justify-center items-center py-20">
                <div className="relative">
                  <div className="w-20 h-20 border-4 border-blue-200 dark:border-blue-800 rounded-full animate-spin"></div>
                  <div className="w-20 h-20 border-4 border-blue-600 border-t-transparent rounded-full animate-spin absolute top-0 left-0"></div>
                </div>
              </div>
            )}

            {/* Error State */}
            {error && (
              <div className="glassmorphism rounded-2xl p-8 text-center border-2 border-red-200/30 dark:border-red-800/30">
                <div className="w-16 h-16 bg-red-100 dark:bg-red-900/50 rounded-full flex items-center justify-center mx-auto mb-4">
                  <svg className="w-8 h-8 text-red-600 dark:text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <h3 className="text-xl font-bold text-red-800 dark:text-red-200 mb-2">
                  Oops! Something went wrong
                </h3>
                <p className="text-red-600 dark:text-red-300">{error}</p>
              </div>
            )}

            {/* About Content */}
            {!loading && !error && aboutData && (
              <>
                <div className="mb-12">
                  <h1 className="text-4xl lg:text-6xl font-bold text-primary mb-6 leading-tight">
                    {aboutData.title}
                  </h1>
                </div>

                {/* Content Blocks */}
                <ContentBlocks blocks={aboutData.blocks} strapiUrl={strapiUrl} />
              </>
            )}

            {/* No Content State */}
            {!loading && !error && !aboutData && (
              <div className="glassmorphism rounded-2xl p-12 text-center">
                <div className="w-20 h-20 bg-gray-100 dark:bg-gray-700 rounded-full flex items-center justify-center mx-auto mb-6">
                  <svg className="w-10 h-10 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
                </div>
                <h3 className="text-lg lg:text-xl font-bold text-primary mb-3">
                  No content available
                </h3>
                <p className="text-secondary">
                  The about page content is not available at the moment.
                </p>
              </div>
            )}
          </main>

          {/* Right Sidebar */}
          <div className="lg:col-span-3 min-w-0">
            <RightSidebar />
          </div>
        </div>
      </div>

      {/* Footer */}
      <Footer />

      {/* Floating Action Button */}
      <FloatingActionButton />
      </div>
    </div>
  );
}
