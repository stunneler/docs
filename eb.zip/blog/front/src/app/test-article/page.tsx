"use client";

import { useState, useEffect } from 'react';
import { ContentBlocks } from '@/components/ContentBlocks';

const STRAPI_URL = "http://swop.site:1337";

export default function TestArticlePage() {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Test the exact same API call that works in curl
        const response = await fetch(`${STRAPI_URL}/api/articles/wu6xbi01rtjbkp7i63o0c244?populate=*`);
        const result = await response.json();
        
        console.log('Raw API response:', result);
        console.log('Article data:', result.data);
        console.log('Blocks:', result.data?.blocks);
        
        setData(result.data);
      } catch (error) {
        console.error('Error:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  if (loading) {
    return <div className="p-8">Loading...</div>;
  }

  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Test Article Page</h1>
      
      <div className="mb-8">
        <h2 className="text-xl font-bold mb-2">Raw Data:</h2>
        <pre className="bg-gray-100 p-4 rounded text-sm overflow-auto">
          {JSON.stringify(data, null, 2)}
        </pre>
      </div>

      <div className="mb-8">
        <h2 className="text-xl font-bold mb-2">Article Title:</h2>
        <p>{data?.title || 'No title'}</p>
      </div>

      <div className="mb-8">
        <h2 className="text-xl font-bold mb-2">Blocks Info:</h2>
        <p>Blocks exist: {data?.blocks ? 'Yes' : 'No'}</p>
        <p>Blocks length: {data?.blocks?.length || 0}</p>
        <p>Blocks type: {typeof data?.blocks}</p>
        <p>Is array: {Array.isArray(data?.blocks) ? 'Yes' : 'No'}</p>
      </div>

      <div className="mb-8">
        <h2 className="text-xl font-bold mb-2">ContentBlocks Component:</h2>
        <div className="border p-4 rounded">
          <ContentBlocks blocks={data?.blocks || []} strapiUrl={STRAPI_URL} />
        </div>
      </div>
    </div>
  );
}