"use client";

import { useParams } from 'next/navigation';
import { Header } from '@/components/Header';
import { LeftSidebar, RightSidebar } from '@/components/Sidebar';
import { Footer } from '@/components/Footer';
import { FloatingActionButton } from '@/components/FloatingActionButton';
import { ContentBlocks } from '@/components/ContentBlocks';
import { useArticle } from '@/hooks/useArticle';
import { SimpleLikeButton } from '@/components/SimpleLikeButton';
import { ShareSection } from '@/components/ShareSection';
import { GiscusComments } from '@/components/GiscusComments';
import Image from 'next/image';

export default function ArticlePage() {
  const params = useParams();
  const slug = params.slug as string;
  const { article, loading, error, strapiUrl } = useArticle(slug);

  const searchArticles = (query: string) => {
    // Redirect to home with search
    window.location.href = `/?search=${encodeURIComponent(query)}`;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-light dark:bg-dark transition-all duration-300">
        <Header onSearch={searchArticles} />
        <div className="pt-16">
          <div className="w-full px-2 lg:px-4 py-8">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 w-full max-w-full">
              <div className="lg:col-span-3 min-w-0">
                <LeftSidebar articleCount={0} />
              </div>
              <main className="lg:col-span-6 min-w-0">
                <div className="flex justify-center items-center py-20">
                  <div className="relative">
                    <div className="w-20 h-20 border-4 border-blue-200 dark:border-blue-800 rounded-full animate-spin"></div>
                    <div className="w-20 h-20 border-4 border-blue-600 border-t-transparent rounded-full animate-spin absolute top-0 left-0"></div>
                  </div>
                </div>
              </main>
              <div className="lg:col-span-3 min-w-0">
                <RightSidebar />
              </div>
            </div>
          </div>
        </div>
        <Footer />
        <FloatingActionButton />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-light dark:bg-dark transition-all duration-300">
        <Header onSearch={searchArticles} />
        <div className="pt-16">
          <div className="w-full px-2 lg:px-4 py-8">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 w-full max-w-full">
              <div className="lg:col-span-3 min-w-0">
                <LeftSidebar articleCount={0} />
              </div>
              <main className="lg:col-span-6 min-w-0">
                <div className="glassmorphism rounded-2xl p-8 text-center border-2 border-red-200/30 dark:border-red-800/30">
                  <div className="w-16 h-16 bg-red-100 dark:bg-red-900/50 rounded-full flex items-center justify-center mx-auto mb-4">
                    <svg className="w-8 h-8 text-red-600 dark:text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </div>
                  <h3 className="text-xl font-bold text-red-800 dark:text-red-200 mb-2">
                    Article Not Found
                  </h3>
                  <p className="text-red-600 dark:text-red-300">{error}</p>
                </div>
              </main>
              <div className="lg:col-span-3 min-w-0">
                <RightSidebar />
              </div>
            </div>
          </div>
        </div>
        <Footer />
        <FloatingActionButton />
      </div>
    );
  }

  if (!article) {
    return null;
  }

  return (
    <div className="min-h-screen bg-light dark:bg-dark transition-all duration-300">
      <Header onSearch={searchArticles} />
      
      <div className="pt-16">
        <div className="w-full px-2 lg:px-4 py-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 w-full max-w-full">
            {/* Left Sidebar */}
            <div className="lg:col-span-3 min-w-0">
              <LeftSidebar articleCount={1} />
            </div>

            {/* Main Content */}
            <main className="lg:col-span-6 min-w-0">
              {/* Article Header */}
              <div className="glassmorphism rounded-2xl p-8 mb-8">
                {/* Cover Image */}
                {article.cover?.url && (
                  <div className="relative w-full h-64 lg:h-80 rounded-lg overflow-hidden mb-6">
                    <Image
                      src={strapiUrl + article.cover.url}
                      alt={article.cover.alternativeText || article.title}
                      fill
                      className="object-cover"
                      priority
                    />
                  </div>
                )}

                {/* Title */}
                <h1 className="text-3xl lg:text-4xl font-bold text-primary mb-4 leading-tight">
                  {article.title}
                </h1>

                {/* Description */}
                {article.description && (
                  <p className="text-lg text-secondary mb-6 leading-relaxed">
                    {article.description}
                  </p>
                )}

                {/* Meta Information */}
                <div className="flex flex-wrap items-center gap-4 text-sm text-secondary">
                  {article.author && (
                    <div className="flex items-center space-x-2">
                      {article.author.avatar?.url && (
                        <Image
                          src={strapiUrl + article.author.avatar.url}
                          alt={article.author.name}
                          width={32}
                          height={32}
                          className="rounded-full"
                        />
                      )}
                      <span>{article.author.name}</span>
                    </div>
                  )}
                  {article.publishedAt && (
                    <span>
                      {new Date(article.publishedAt).toLocaleDateString('en-US', {
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric'
                      })}
                    </span>
                  )}
                  {article.category && (
                    <span className="px-3 py-1 bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300 rounded-full">
                      {article.category.name}
                    </span>
                  )}
                </div>
              </div>
              
              {/* Article Content - Use ContentBlocks component */}
              <ContentBlocks blocks={article.blocks || []} strapiUrl={strapiUrl} />
              
              {/* Like Button */}
              <SimpleLikeButton articleSlug={slug} />

              {/* Share Section */}
              <ShareSection 
                title={article.title}
                url={`http://swop.site:3000/articles/${slug}`}
                description={article.description}
              />

              {/* Comments Section */}
              <GiscusComments />
            </main>

            {/* Right Sidebar */}
            <div className="lg:col-span-3 min-w-0">
              <RightSidebar />
            </div>
          </div>
        </div>
      </div>

      <Footer />
      <FloatingActionButton />
    </div>
  );
}