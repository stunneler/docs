import { NextRequest, NextResponse } from 'next/server';

const STRAPI_URL = "http://swop.site:1337";

export async function POST(request: NextRequest) {
  try {
    const { to, subject, text, html } = await request.json();

    if (!to || !subject || (!text && !html)) {
      return NextResponse.json(
        { error: 'Missing required fields: to, subject, and either text or html' },
        { status: 400 }
      );
    }

    // Use Strapi's email plugin service
    const emailResponse = await fetch(`${STRAPI_URL}/api/email`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        to,
        subject,
        text,
        html,
      }),
    });

    if (!emailResponse.ok) {
      throw new Error('Failed to send email via Strapi');
    }

    return NextResponse.json({
      message: 'Email sent successfully'
    });

  } catch (error) {
    console.error('Email sending error:', error);
    return NextResponse.json(
      { error: 'Failed to send email' },
      { status: 500 }
    );
  }
}