import { NextRequest, NextResponse } from 'next/server';
import { promises as fs } from 'fs';
import path from 'path';

const LIKES_FILE = path.join(process.cwd(), 'data', 'likes.json');

interface LikesData {
  [articleSlug: string]: string[];
}

async function loadLikes(): Promise<LikesData> {
  try {
    const data = await fs.readFile(LIKES_FILE, 'utf-8');
    return JSON.parse(data);
  } catch {
    return {};
  }
}

export async function GET(request: NextRequest) {
  try {
    const likesData = await loadLikes();
    
    // Calculate aggregated statistics
    const stats = {
      totalLikes: 0,
      totalArticles: Object.keys(likesData).length,
      articleStats: [] as Array<{
        slug: string;
        likeCount: number;
      }>,
      topArticles: [] as Array<{
        slug: string;
        likeCount: number;
      }>
    };
    
    // Process each article
    for (const [slug, likes] of Object.entries(likesData)) {
      const likeCount = likes.length;
      stats.totalLikes += likeCount;
      
      stats.articleStats.push({
        slug,
        likeCount
      });
    }
    
    // Sort articles by like count (top articles)
    stats.topArticles = stats.articleStats
      .sort((a, b) => b.likeCount - a.likeCount)
      .slice(0, 10); // Top 10 articles
    
    return NextResponse.json(stats);
    
  } catch (error) {
    console.error('Error getting like stats:', error);
    return NextResponse.json(
      { error: 'Failed to get like statistics' },
      { status: 500 }
    );
  }
}