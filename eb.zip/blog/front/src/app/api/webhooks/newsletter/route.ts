import { NextRequest, NextResponse } from 'next/server';

// Webhook endpoint to handle Strapi events related to newsletter subscriptions
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    
    // Log the webhook event for debugging
    console.log('Newsletter webhook received:', {
      event: body.event,
      model: body.model,
      created_at: body.created_at,
      entry: body.entry
    });

    // Handle different webhook events
    switch (body.event) {
      case 'entry.create':
        if (body.model === 'newsletter-subscription') {
          await handleNewSubscription(body.entry);
        }
        break;
        
      case 'entry.update':
        if (body.model === 'newsletter-subscription') {
          await handleSubscriptionUpdate(body.entry);
        }
        break;
        
      case 'entry.delete':
        if (body.model === 'newsletter-subscription') {
          await handleSubscriptionDeletion(body.entry);
        }
        break;
        
      case 'entry.create':
        if (body.model === 'article') {
          await handleNewArticle(body.entry);
        }
        break;
        
      default:
        console.log('Unhandled webhook event:', body.event);
    }

    return NextResponse.json({ 
      message: 'Webhook processed successfully',
      event: body.event,
      model: body.model 
    });

  } catch (error) {
    console.error('Webhook processing error:', error);
    return NextResponse.json(
      { error: 'Failed to process webhook' },
      { status: 500 }
    );
  }
}

// Handle new newsletter subscription
async function handleNewSubscription(entry: any) {
  console.log('New newsletter subscription:', entry.email);
  
  try {
    // Send welcome email
    await sendWelcomeEmail(entry.email);
    
    // Update internal analytics/metrics
    await updateSubscriptionMetrics('new_subscription');
    
    // Notify team (could send to Slack, Discord, etc.)
    await notifyTeam(`New newsletter subscription: ${entry.email}`);
    
  } catch (error) {
    console.error('Error handling new subscription:', error);
  }
}

// Handle subscription updates
async function handleSubscriptionUpdate(entry: any) {
  console.log('Newsletter subscription updated:', entry.email);
  
  try {
    // Handle subscription status changes
    if (entry.isActive === false) {
      await handleUnsubscription(entry);
    }
    
  } catch (error) {
    console.error('Error handling subscription update:', error);
  }
}

// Handle subscription deletion
async function handleSubscriptionDeletion(entry: any) {
  console.log('Newsletter subscription deleted:', entry.email);
  
  try {
    // Clean up related data
    await cleanupSubscriptionData(entry.id);
    
    // Update metrics
    await updateSubscriptionMetrics('unsubscription');
    
  } catch (error) {
    console.error('Error handling subscription deletion:', error);
  }
}

// Handle new article publication
async function handleNewArticle(entry: any) {
  console.log('New article published:', entry.title);
  
  try {
    // Trigger newsletter campaign for new article
    await triggerArticleNewsletter(entry);
    
    // Update social media
    await postToSocialMedia(entry);
    
    // Notify team
    await notifyTeam(`New article published: ${entry.title}`);
    
  } catch (error) {
    console.error('Error handling new article:', error);
  }
}

// Send welcome email to new subscriber
async function sendWelcomeEmail(email: string) {
  try {
    console.log(`Sending welcome email to: ${email}`);
    
    // Use Strapi's email plugin service
    const emailResponse = await fetch(`${process.env.STRAPI_URL || 'http://swop.site:1337'}/api/email`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        to: email,
        subject: 'Welcome to ModernBlog Newsletter! 🎉',
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
            <div style="text-align: center; margin-bottom: 30px;">
              <h1 style="color: #2563eb; margin-bottom: 10px;">Welcome to ModernBlog!</h1>
              <p style="color: #6b7280; font-size: 18px;">Thank you for subscribing to our newsletter</p>
            </div>
            
            <div style="background-color: #f8fafc; padding: 25px; border-radius: 12px; margin-bottom: 25px;">
              <h2 style="color: #1f2937; margin-bottom: 15px;">What to expect:</h2>
              <ul style="color: #4b5563; line-height: 1.6;">
                <li>📚 Weekly digest of our latest articles</li>
                <li>💡 Exclusive insights and tips</li>
                <li>🚀 Early access to new features</li>
                <li>🎯 Curated content just for you</li>
              </ul>
            </div>
            
            <div style="text-align: center; margin-bottom: 25px;">
              <p style="color: #4b5563; font-size: 16px;">We're excited to have you on board!</p>
            </div>
            
            <div style="background-color: #2563eb; color: white; padding: 20px; border-radius: 8px; text-align: center;">
              <p style="margin: 0; font-weight: bold;">The ModernBlog Team</p>
              <p style="margin: 5px 0 0 0; opacity: 0.9;">Building the future of content</p>
            </div>
            
            <div style="text-align: center; margin-top: 25px; padding-top: 20px; border-top: 1px solid #e5e7eb;">
              <p style="color: #9ca3af; font-size: 12px;">
                You received this email because you subscribed to our newsletter.<br>
                If you no longer wish to receive these emails, you can unsubscribe at any time.
              </p>
            </div>
          </div>
        `,
        text: `Welcome to ModernBlog Newsletter!

Thank you for subscribing to our newsletter. You're now part of our community!

What to expect:
- Weekly digest of our latest articles
- Exclusive insights and tips  
- Early access to new features
- Curated content just for you

We're excited to have you on board!

Best regards,
The ModernBlog Team
Building the future of content`
      }),
    });
    
    if (emailResponse.ok) {
      console.log('Welcome email sent successfully via webhook to:', email);
      return true;
    } else {
      const errorData = await emailResponse.json();
      console.error('Failed to send welcome email via webhook:', errorData);
      return false;
    }
    
  } catch (error) {
    console.error('Error sending welcome email via webhook:', error);
    return false;
  }
}

// Update subscription metrics
async function updateSubscriptionMetrics(action: string) {
  try {
    console.log(`Updating metrics for action: ${action}`);
    // Here you would update your analytics/metrics system
    // This could be Google Analytics, Mixpanel, or your own metrics system
    
  } catch (error) {
    console.error('Error updating metrics:', error);
  }
}

// Notify team about events
async function notifyTeam(message: string) {
  try {
    console.log(`Team notification: ${message}`);
    // Here you would send notifications to Slack, Discord, Teams, etc.
    // Example: await slackClient.postMessage({ channel: '#notifications', text: message });
    
  } catch (error) {
    console.error('Error sending team notification:', error);
  }
}

// Handle unsubscription
async function handleUnsubscription(entry: any) {
  try {
    console.log(`Processing unsubscription for: ${entry.email}`);
    // Send goodbye email, update metrics, etc.
    
  } catch (error) {
    console.error('Error handling unsubscription:', error);
  }
}

// Clean up subscription data
async function cleanupSubscriptionData(subscriptionId: string) {
  try {
    console.log(`Cleaning up data for subscription: ${subscriptionId}`);
    // Remove from mailing lists, clean up related data, etc.
    
  } catch (error) {
    console.error('Error cleaning up subscription data:', error);
  }
}

// Trigger newsletter for new article
async function triggerArticleNewsletter(article: any) {
  try {
    console.log(`Triggering newsletter for article: ${article.title}`);
    // Create and send newsletter campaign for the new article
    
  } catch (error) {
    console.error('Error triggering article newsletter:', error);
  }
}

// Post to social media
async function postToSocialMedia(article: any) {
  try {
    console.log(`Posting to social media: ${article.title}`);
    // Post to Twitter, LinkedIn, Facebook, etc.
    
  } catch (error) {
    console.error('Error posting to social media:', error);
  }
}