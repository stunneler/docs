import { NextRequest, NextResponse } from 'next/server';

// Test endpoint to simulate webhook events for development
export async function POST(request: NextRequest) {
  try {
    const { eventType, model } = await request.json();
    
    // Simulate different webhook events
    const mockEvents = {
      'article-create': {
        event: 'entry.create',
        model: 'article',
        entry: {
          id: Date.now(),
          documentId: `test-${Date.now()}`,
          title: 'Test Article: Advanced React Patterns',
          description: 'Learn about advanced React patterns and best practices',
          slug: 'test-article-advanced-react-patterns',
          publishedAt: new Date().toISOString(),
          author: {
            name: 'John Doe',
            email: 'john@example.com'
          },
          category: {
            name: 'Technology',
            slug: 'technology'
          }
        }
      },
      'article-update': {
        event: 'entry.update',
        model: 'article',
        entry: {
          id: Date.now(),
          documentId: `test-${Date.now()}`,
          title: 'Updated: Modern CSS Techniques',
          description: 'Updated guide to modern CSS techniques and best practices',
          slug: 'modern-css-techniques',
          publishedAt: new Date().toISOString()
        }
      },
      'newsletter-create': {
        event: 'entry.create',
        model: 'newsletter-subscription',
        entry: {
          id: Date.now(),
          documentId: `sub-${Date.now()}`,
          email: 'test@example.com',
          subscribedAt: new Date().toISOString(),
          isActive: true
        }
      }
    };

    const selectedEvent = mockEvents[eventType as keyof typeof mockEvents];
    
    if (!selectedEvent) {
      return NextResponse.json(
        { error: 'Invalid event type' },
        { status: 400 }
      );
    }

    // Add timestamp and created_at
    const webhookPayload = {
      ...selectedEvent,
      created_at: new Date().toISOString()
    };

    // Forward to appropriate webhook handler
    let targetUrl = '';
    if (selectedEvent.model === 'article') {
      targetUrl = '/api/webhooks/articles';
    } else if (selectedEvent.model === 'newsletter-subscription') {
      targetUrl = '/api/webhooks/newsletter';
    }

    if (targetUrl) {
      try {
        const baseUrl = request.nextUrl.origin;
        await fetch(`${baseUrl}${targetUrl}`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(webhookPayload),
        });
      } catch (error) {
        console.error('Error forwarding webhook:', error);
      }
    }

    return NextResponse.json({
      message: 'Test webhook event triggered successfully',
      event: selectedEvent.event,
      model: selectedEvent.model,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('Test webhook error:', error);
    return NextResponse.json(
      { error: 'Failed to trigger test webhook' },
      { status: 500 }
    );
  }
}

export async function GET() {
  return NextResponse.json({
    message: 'Webhook test endpoint',
    availableEvents: [
      'article-create',
      'article-update', 
      'newsletter-create'
    ],
    usage: 'POST with { "eventType": "article-create", "model": "article" }'
  });
}