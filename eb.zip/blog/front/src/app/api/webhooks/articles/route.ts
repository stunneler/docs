import { NextRequest, NextResponse } from 'next/server';

// Webhook endpoint to handle Strapi events related to articles
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    
    console.log('Article webhook received:', {
      event: body.event,
      model: body.model,
      created_at: body.created_at,
      entry: body.entry
    });

    // Handle different article events
    switch (body.event) {
      case 'entry.create':
        if (body.model === 'article') {
          await handleArticleCreated(body.entry);
        }
        break;
        
      case 'entry.update':
        if (body.model === 'article') {
          await handleArticleUpdated(body.entry);
        }
        break;
        
      case 'entry.publish':
        if (body.model === 'article') {
          await handleArticlePublished(body.entry);
        }
        break;
        
      case 'entry.unpublish':
        if (body.model === 'article') {
          await handleArticleUnpublished(body.entry);
        }
        break;
        
      default:
        console.log('Unhandled article webhook event:', body.event);
    }

    return NextResponse.json({ 
      message: 'Article webhook processed successfully',
      event: body.event,
      article: body.entry?.title || 'Unknown'
    });

  } catch (error) {
    console.error('Article webhook processing error:', error);
    return NextResponse.json(
      { error: 'Failed to process article webhook' },
      { status: 500 }
    );
  }
}

// Handle article creation
async function handleArticleCreated(article: any) {
  console.log('New article created:', article.title);
  
  try {
    // Notify content team
    await notifyContentTeam(`New article created: "${article.title}" by ${article.author?.name || 'Unknown'}`);
    
    // Update content metrics
    await updateContentMetrics('article_created', article);
    
    // If article is published, trigger additional actions
    if (article.publishedAt) {
      await handleArticlePublished(article);
    }
    
  } catch (error) {
    console.error('Error handling article creation:', error);
  }
}

// Handle article updates
async function handleArticleUpdated(article: any) {
  console.log('Article updated:', article.title);
  
  try {
    // Check if article was just published
    if (article.publishedAt && !article.previouslyPublished) {
      await handleArticlePublished(article);
    }
    
    // Update search index
    await updateSearchIndex(article);
    
    // Clear cache
    await clearArticleCache(article.slug || article.documentId);
    
  } catch (error) {
    console.error('Error handling article update:', error);
  }
}

// Handle article publication
async function handleArticlePublished(article: any) {
  console.log('Article published:', article.title);
  
  try {
    // Trigger static site regeneration (for Next.js ISR)
    await triggerSiteRegeneration(article);
    
    // Send to newsletter subscribers
    await scheduleNewsletterCampaign(article);
    
    // Post to social media
    await scheduleocialMediaPosts(article);
    
    // Update SEO sitemap
    await updateSitemap();
    
    // Notify marketing team
    await notifyMarketingTeam(`New article published: "${article.title}"`);
    
    // Update analytics
    await updateContentMetrics('article_published', article);
    
  } catch (error) {
    console.error('Error handling article publication:', error);
  }
}

// Handle article unpublication
async function handleArticleUnpublished(article: any) {
  console.log('Article unpublished:', article.title);
  
  try {
    // Remove from search index
    await removeFromSearchIndex(article.documentId);
    
    // Clear cache
    await clearArticleCache(article.slug || article.documentId);
    
    // Update sitemap
    await updateSitemap();
    
    // Notify team
    await notifyContentTeam(`Article unpublished: "${article.title}"`);
    
  } catch (error) {
    console.error('Error handling article unpublication:', error);
  }
}

// Notify content team
async function notifyContentTeam(message: string) {
  try {
    console.log(`Content team notification: ${message}`);
    // Send to content team Slack channel, email, etc.
    
  } catch (error) {
    console.error('Error notifying content team:', error);
  }
}

// Notify marketing team
async function notifyMarketingTeam(message: string) {
  try {
    console.log(`Marketing team notification: ${message}`);
    // Send to marketing team channels
    
  } catch (error) {
    console.error('Error notifying marketing team:', error);
  }
}

// Update content metrics
async function updateContentMetrics(action: string, article: any) {
  try {
    console.log(`Updating content metrics for: ${action}`);
    // Update analytics with article data
    const metrics = {
      action,
      articleId: article.documentId,
      title: article.title,
      category: article.category?.name,
      author: article.author?.name,
      timestamp: new Date().toISOString()
    };
    
    // Send to analytics service
    // await analyticsService.track(metrics);
    
  } catch (error) {
    console.error('Error updating content metrics:', error);
  }
}

// Trigger static site regeneration
async function triggerSiteRegeneration(article: any) {
  try {
    console.log(`Triggering site regeneration for: ${article.title}`);
    
    // For Next.js ISR, you might call revalidate endpoints
    const revalidateUrls = [
      '/', // Home page
      '/articles', // Articles page
      `/articles/${article.slug || article.documentId}`, // Article page
      `/categories/${article.category?.slug}` // Category page
    ];
    
    for (const url of revalidateUrls) {
      try {
        // await fetch(`${process.env.SITE_URL}/api/revalidate?path=${url}`);
        console.log(`Would revalidate: ${url}`);
      } catch (revalidateError) {
        console.error(`Error revalidating ${url}:`, revalidateError);
      }
    }
    
  } catch (error) {
    console.error('Error triggering site regeneration:', error);
  }
}

// Schedule newsletter campaign
async function scheduleNewsletterCampaign(article: any) {
  try {
    console.log(`Scheduling newsletter campaign for: ${article.title}`);
    // Create and schedule newsletter campaign
    
  } catch (error) {
    console.error('Error scheduling newsletter campaign:', error);
  }
}

// Schedule social media posts
async function scheduleocialMediaPosts(article: any) {
  try {
    console.log(`Scheduling social media posts for: ${article.title}`);
    // Schedule posts to Twitter, LinkedIn, Facebook, etc.
    
  } catch (error) {
    console.error('Error scheduling social media posts:', error);
  }
}

// Update search index
async function updateSearchIndex(article: any) {
  try {
    console.log(`Updating search index for: ${article.title}`);
    // Update Elasticsearch, Algolia, or other search service
    
  } catch (error) {
    console.error('Error updating search index:', error);
  }
}

// Remove from search index
async function removeFromSearchIndex(articleId: string) {
  try {
    console.log(`Removing from search index: ${articleId}`);
    // Remove from search service
    
  } catch (error) {
    console.error('Error removing from search index:', error);
  }
}

// Clear article cache
async function clearArticleCache(articleSlug: string) {
  try {
    console.log(`Clearing cache for article: ${articleSlug}`);
    // Clear CDN cache, Redis cache, etc.
    
  } catch (error) {
    console.error('Error clearing article cache:', error);
  }
}

// Update sitemap
async function updateSitemap() {
  try {
    console.log('Updating sitemap');
    // Regenerate and update sitemap.xml
    
  } catch (error) {
    console.error('Error updating sitemap:', error);
  }
}