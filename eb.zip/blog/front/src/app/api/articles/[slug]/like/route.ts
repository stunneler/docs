import { NextRequest, NextResponse } from 'next/server';

// const STRAPI_URL = "http://swop.site:1337"; // Unused in current implementation

// Persistent storage using file system (in production, use Redis or database)
import { promises as fs } from 'fs';
import path from 'path';

const LIKES_FILE = path.join(process.cwd(), 'data', 'likes.json');

interface LikesData {
  [articleSlug: string]: string[];
}

async function ensureDataDirectory() {
  const dataDir = path.join(process.cwd(), 'data');
  try {
    await fs.access(dataDir);
  } catch {
    await fs.mkdir(dataDir, { recursive: true });
  }
}

async function loadLikes(): Promise<LikesData> {
  try {
    await ensureDataDirectory();
    const data = await fs.readFile(LIKES_FILE, 'utf-8');
    return JSON.parse(data);
  } catch {
    return {};
  }
}

async function saveLikes(likes: LikesData): Promise<void> {
  await ensureDataDirectory();
  await fs.writeFile(LIKES_FILE, JSON.stringify(likes, null, 2));
}

function getUserIdentifier(request: NextRequest): string {
  // Create a unique identifier based on IP and User-Agent
  const forwarded = request.headers.get('x-forwarded-for');
  const ip = forwarded ? forwarded.split(',')[0] : request.headers.get('x-real-ip') || 'unknown';
  const userAgent = request.headers.get('user-agent') || 'unknown';
  
  // Create a hash-like identifier (simple approach)
  return `${ip}-${userAgent.slice(0, 50)}`.replace(/[^a-zA-Z0-9-]/g, '');
}

export async function POST(
  request: NextRequest,
  { params }: { params: { slug: string } }
) {
  try {
    const slug = params.slug;
    const userIdentifier = getUserIdentifier(request);
    
    if (!slug) {
      return NextResponse.json(
        { error: 'Article slug is required' },
        { status: 400 }
      );
    }

    // Load current likes data
    const likesData = await loadLikes();
    
    // Get or create likes array for this article
    if (!likesData[slug]) {
      likesData[slug] = [];
    }
    
    const articleLikes = likesData[slug];
    const hasLiked = articleLikes.includes(userIdentifier);
    
    if (hasLiked) {
      // Unlike - remove user from array
      likesData[slug] = articleLikes.filter(id => id !== userIdentifier);
    } else {
      // Like - add user to array
      articleLikes.push(userIdentifier);
    }
    
    // Save updated likes data
    await saveLikes(likesData);
    
    const likeCount = likesData[slug].length;
    const liked = !hasLiked;
    
    console.log(`Article ${slug}: ${liked ? 'liked' : 'unliked'} by ${userIdentifier}. Total: ${likeCount}`);
    
    return NextResponse.json({
      success: true,
      liked,
      likeCount,
      message: liked ? 'Article liked!' : 'Article unliked!'
    });

  } catch (error) {
    console.error('Like toggle error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function GET(
  request: NextRequest,
  { params }: { params: { slug: string } }
) {
  try {
    const slug = params.slug;
    const userIdentifier = getUserIdentifier(request);
    
    if (!slug) {
      return NextResponse.json(
        { error: 'Article slug is required' },
        { status: 400 }
      );
    }

    const likesData = await loadLikes();
    const articleLikes = likesData[slug] || [];
    const likeCount = articleLikes.length;
    const liked = articleLikes.includes(userIdentifier);
    
    return NextResponse.json({
      likeCount,
      liked
    });

  } catch (error) {
    console.error('Get likes error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}