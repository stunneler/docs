import { NextRequest, NextResponse } from 'next/server';
import { promises as fs } from 'fs';
import path from 'path';

const STRAPI_URL = "http://swop.site:1337";
const SUBSCRIBERS_FILE = path.join(process.cwd(), 'data', 'subscribers.json');

interface SubscriberData {
  [email: string]: {
    subscribedAt: string;
    isActive: boolean;
  };
}

async function ensureDataDirectory() {
  const dataDir = path.join(process.cwd(), 'data');
  try {
    await fs.access(dataDir);
  } catch {
    await fs.mkdir(dataDir, { recursive: true });
  }
}

async function loadSubscribers(): Promise<SubscriberData> {
  try {
    await ensureDataDirectory();
    const data = await fs.readFile(SUBSCRIBERS_FILE, 'utf-8');
    return JSON.parse(data);
  } catch {
    return {};
  }
}

async function saveSubscribers(subscribers: SubscriberData): Promise<void> {
  await ensureDataDirectory();
  await fs.writeFile(SUBSCRIBERS_FILE, JSON.stringify(subscribers, null, 2));
}

export async function POST(request: NextRequest) {
  try {
    const { email } = await request.json();

    if (!email) {
      return NextResponse.json(
        { error: 'Email is required' },
        { status: 400 }
      );
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return NextResponse.json(
        { error: 'Please enter a valid email address' },
        { status: 400 }
      );
    }

    // Load existing subscribers from local file
    const subscribers = await loadSubscribers();
    
    // Check if email exists in our list
    if (!subscribers[email]) {
      return NextResponse.json(
        { error: 'Email not found in our subscription list' },
        { status: 404 }
      );
    }

    if (!subscribers[email].isActive) {
      return NextResponse.json(
        { error: 'Email is already unsubscribed' },
        { status: 409 }
      );
    }

    // Remove the email from subscribers (simple deletion)
    delete subscribers[email];

    // Save updated subscribers
    await saveSubscribers(subscribers);

    console.log('Newsletter unsubscription successful for:', email);

    // Send confirmation email (optional)
    try {
      await fetch(`${STRAPI_URL}/api/email`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          to: email,
          subject: 'Unsubscribed from Blog Newsletter',
          text: `You have been successfully unsubscribed from our newsletter. We're sorry to see you go!`,
          html: `
            <div style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; max-width: 600px; margin: 0 auto; padding: 40px 20px;">
              <div style="background: #ffffff; border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); overflow: hidden; padding: 40px;">
                <div style="text-align: center; margin-bottom: 30px;">
                  <h2 style="color: #374151; font-size: 24px; margin: 0 0 10px 0;">Unsubscribed Successfully</h2>
                  <p style="color: #6b7280; font-size: 16px; margin: 0;">We're sorry to see you go!</p>
                </div>
                
                <div style="background: #f8fafc; padding: 25px; border-radius: 12px; margin-bottom: 30px;">
                  <p style="color: #374151; font-size: 16px; line-height: 1.6; margin: 0;">
                    You have been successfully unsubscribed from our newsletter. If you change your mind, you can always subscribe again at any time.
                  </p>
                </div>
                
                <div style="text-align: center; margin-bottom: 30px;">
                  <a href="http://swop.site:3000" style="
                    display: inline-block;
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    color: #ffffff;
                    padding: 12px 24px;
                    text-decoration: none;
                    border-radius: 25px;
                    font-weight: 600;
                    font-size: 14px;
                  ">
                    Visit Blog
                  </a>
                </div>
                
                <div style="text-align: center; border-top: 1px solid #e5e7eb; padding-top: 20px;">
                  <p style="color: #374151; font-size: 16px; margin: 0 0 10px 0; font-weight: 600;">Best regards,</p>
                  <p style="color: #6b7280; font-size: 16px; margin: 0;">The Blog Team</p>
                </div>
              </div>
            </div>
          `,
        }),
      });
    } catch (emailError) {
      console.warn('Unsubscribe confirmation email failed to send:', emailError);
      // Don't fail the unsubscription if email fails
    }

    return NextResponse.json({
      message: 'Successfully unsubscribed from newsletter! We\'re sorry to see you go.',
      email: email
    });

  } catch (error) {
    console.error('Newsletter unsubscription error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function GET() {
  return NextResponse.json(
    { message: 'Newsletter unsubscribe API endpoint' },
    { status: 200 }
  );
}