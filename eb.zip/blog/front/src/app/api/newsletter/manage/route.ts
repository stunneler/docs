import { NextRequest, NextResponse } from 'next/server';

const STRAPI_URL = "http://swop.site:1337";

// Get all newsletter subscriptions (admin only)
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '25');
    const status = searchParams.get('status'); // 'active', 'inactive', or 'all'

    // Build filters
    let filters = '';
    if (status === 'active') {
      filters = 'filters[isActive][$eq]=true';
    } else if (status === 'inactive') {
      filters = 'filters[isActive][$eq]=false';
    }

    // Fetch subscriptions from Strapi
    const response = await fetch(
      `${STRAPI_URL}/api/newsletter-subscriptions?${filters}&pagination[page]=${page}&pagination[pageSize]=${limit}&sort=subscribedAt:desc`
    );

    if (!response.ok) {
      throw new Error('Failed to fetch subscriptions');
    }

    const data = await response.json();

    // Calculate statistics
    const stats = await getSubscriptionStats();

    return NextResponse.json({
      subscriptions: data.data,
      pagination: data.meta?.pagination,
      stats
    });

  } catch (error) {
    console.error('Error fetching newsletter subscriptions:', error);
    return NextResponse.json(
      { error: 'Failed to fetch subscriptions' },
      { status: 500 }
    );
  }
}

// Bulk operations (admin only)
export async function POST(request: NextRequest) {
  try {
    const { action, emails, campaignData } = await request.json();

    switch (action) {
      case 'bulk_unsubscribe':
        return await bulkUnsubscribe(emails);
      
      case 'send_campaign':
        return await sendCampaign(campaignData);
      
      case 'export_subscribers':
        return await exportSubscribers();
      
      default:
        return NextResponse.json(
          { error: 'Invalid action' },
          { status: 400 }
        );
    }

  } catch (error) {
    console.error('Error in newsletter management:', error);
    return NextResponse.json(
      { error: 'Failed to process request' },
      { status: 500 }
    );
  }
}

// Get subscription statistics
async function getSubscriptionStats() {
  try {
    // Get total active subscriptions
    const activeResponse = await fetch(`${STRAPI_URL}/api/newsletter-subscriptions?filters[isActive][$eq]=true&pagination[pageSize]=1`);
    const activeData = await activeResponse.json();
    const totalActive = activeData.meta?.pagination?.total || 0;

    // Get total inactive subscriptions
    const inactiveResponse = await fetch(`${STRAPI_URL}/api/newsletter-subscriptions?filters[isActive][$eq]=false&pagination[pageSize]=1`);
    const inactiveData = await inactiveResponse.json();
    const totalInactive = inactiveData.meta?.pagination?.total || 0;

    // Get recent subscriptions (last 30 days)
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    
    const recentResponse = await fetch(`${STRAPI_URL}/api/newsletter-subscriptions?filters[subscribedAt][$gte]=${thirtyDaysAgo.toISOString()}&filters[isActive][$eq]=true&pagination[pageSize]=1`);
    const recentData = await recentResponse.json();
    const recentSubscriptions = recentData.meta?.pagination?.total || 0;

    return {
      totalActive,
      totalInactive,
      totalSubscriptions: totalActive + totalInactive,
      recentSubscriptions,
      growthRate: totalActive > 0 ? ((recentSubscriptions / totalActive) * 100).toFixed(1) : '0'
    };

  } catch (error) {
    console.error('Error calculating stats:', error);
    return {
      totalActive: 0,
      totalInactive: 0,
      totalSubscriptions: 0,
      recentSubscriptions: 0,
      growthRate: '0'
    };
  }
}

// Bulk unsubscribe emails
async function bulkUnsubscribe(emails: string[]) {
  try {
    const results = [];

    for (const email of emails) {
      try {
        // Find subscription
        const findResponse = await fetch(`${STRAPI_URL}/api/newsletter-subscriptions?filters[email][$eq]=${encodeURIComponent(email)}`);
        const findData = await findResponse.json();

        if (findData.data && findData.data.length > 0) {
          const subscription = findData.data[0];
          
          // Update to inactive
          const updateResponse = await fetch(`${STRAPI_URL}/api/newsletter-subscriptions/${subscription.documentId}`, {
            method: 'PUT',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              data: {
                isActive: false,
                unsubscribedAt: new Date().toISOString()
              }
            }),
          });

          if (updateResponse.ok) {
            results.push({ email, status: 'success' });
          } else {
            results.push({ email, status: 'error', message: 'Failed to update' });
          }
        } else {
          results.push({ email, status: 'not_found' });
        }
      } catch (error) {
        results.push({ email, status: 'error', message: error.message });
      }
    }

    return NextResponse.json({
      message: 'Bulk unsubscribe completed',
      results
    });

  } catch (error) {
    throw error;
  }
}

// Send newsletter campaign
async function sendCampaign(campaignData: any) {
  try {
    const { subject, content, targetAudience } = campaignData;

    // Get active subscribers
    let filters = 'filters[isActive][$eq]=true';
    if (targetAudience === 'recent') {
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
      filters += `&filters[subscribedAt][$gte]=${thirtyDaysAgo.toISOString()}`;
    }

    const response = await fetch(`${STRAPI_URL}/api/newsletter-subscriptions?${filters}&pagination[pageSize]=100`);
    const data = await response.json();

    const subscribers = data.data || [];
    console.log(`Sending campaign to ${subscribers.length} subscribers`);

    // In a real implementation, you would integrate with an email service
    // For now, we'll just log the campaign
    const campaignId = `campaign_${Date.now()}`;
    
    console.log('Campaign Details:', {
      id: campaignId,
      subject,
      content: content.substring(0, 100) + '...',
      recipientCount: subscribers.length,
      scheduledAt: new Date().toISOString()
    });

    return NextResponse.json({
      message: 'Campaign scheduled successfully',
      campaignId,
      recipientCount: subscribers.length
    });

  } catch (error) {
    throw error;
  }
}

// Export subscribers
async function exportSubscribers() {
  try {
    // Get all active subscribers
    const response = await fetch(`${STRAPI_URL}/api/newsletter-subscriptions?filters[isActive][$eq]=true&pagination[pageSize]=1000`);
    const data = await response.json();

    const subscribers = data.data || [];
    
    // Format for CSV export
    const csvData = subscribers.map(sub => ({
      email: sub.email,
      subscribedAt: sub.subscribedAt,
      isActive: sub.isActive
    }));

    return NextResponse.json({
      message: 'Export ready',
      data: csvData,
      count: csvData.length
    });

  } catch (error) {
    throw error;
  }
}