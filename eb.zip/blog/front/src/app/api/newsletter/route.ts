import { NextRequest, NextResponse } from 'next/server';
import { promises as fs } from 'fs';
import path from 'path';

const STRAPI_URL = "http://swop.site:1337";
const SUBSCRIBERS_FILE = path.join(process.cwd(), 'data', 'subscribers.json');

interface SubscriberData {
  [email: string]: {
    subscribedAt: string;
    isActive: boolean;
  };
}

async function ensureDataDirectory() {
  const dataDir = path.join(process.cwd(), 'data');
  try {
    await fs.access(dataDir);
  } catch {
    await fs.mkdir(dataDir, { recursive: true });
  }
}

async function loadSubscribers(): Promise<SubscriberData> {
  try {
    await ensureDataDirectory();
    const data = await fs.readFile(SUBSCRIBERS_FILE, 'utf-8');
    return JSON.parse(data);
  } catch {
    return {};
  }
}

async function saveSubscribers(subscribers: SubscriberData): Promise<void> {
  await ensureDataDirectory();
  await fs.writeFile(SUBSCRIBERS_FILE, JSON.stringify(subscribers, null, 2));
}

async function sendWelcomeEmail(email: string): Promise<boolean> {
  try {
    console.log('📧 Attempting to send welcome email to:', email);
    console.log('🌐 Using Strapi URL:', STRAPI_URL);
    
    // Revamped email with gradients and proper styling
    const emailData = {
      to: email,
      subject: 'Welcome to Blog Newsletter! 🎉',
      text: 'Welcome to Blog! Thank you for subscribing to our newsletter!',
      html: `
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to Blog Newsletter! 🎉</title>
    <style>
        @media only screen and (max-width: 600px) {
            .container { width: 100% !important; padding: 20px !important; }
            .header-title { font-size: 24px !important; }
            .cta-button { padding: 12px 24px !important; font-size: 14px !important; }
        }
    </style>
</head>
<body style="margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f8fafc; min-height: 100vh;">
    
    <!-- Email Container -->
    <div class="container" style="max-width: 600px; margin: 0 auto; padding: 40px 20px;">
        
        <!-- Main Email Card -->
        <div style="background: #ffffff; border-radius: 20px; box-shadow: 0 20px 40px rgba(0,0,0,0.1); overflow: hidden;">
            
            <!-- Header with Gradient -->
            <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 40px 30px; text-align: center; position: relative;">
                <!-- Decorative Elements -->
                <div style="position: absolute; top: -50px; right: -50px; width: 100px; height: 100px; background: rgba(255,255,255,0.1); border-radius: 50%; opacity: 0.5;"></div>
                <div style="position: absolute; bottom: -30px; left: -30px; width: 60px; height: 60px; background: rgba(255,255,255,0.1); border-radius: 50%; opacity: 0.7;"></div>
                
                <h1 class="header-title" style="color: #ffffff; font-size: 32px; font-weight: 700; margin: 0 0 10px 0; text-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                    Welcome to Blog! 🎉
                </h1>
                <p style="color: rgba(255,255,255,0.9); font-size: 18px; margin: 0; font-weight: 300;">
                    Your gateway to amazing content
                </p>
            </div>
            
            <!-- Content Section -->
            <div style="padding: 40px 30px;">
                
                <!-- Greeting -->
                <div style="margin-bottom: 30px;">
                    <p style="color: #374151; font-size: 18px; margin: 0 0 20px 0; font-weight: 500;">Hi there! 👋</p>
                    <p style="color: #6b7280; font-size: 16px; line-height: 1.6; margin: 0;">
                        Thank you for subscribing to our newsletter! You've just joined a community of curious minds who love staying updated with the latest insights, articles, and exclusive content.
                    </p>
                </div>
                
                <!-- Features Box -->
                <div style="background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%); padding: 30px; border-radius: 16px; margin-bottom: 30px; border-left: 4px solid #667eea; position: relative; overflow: hidden;">
                    <!-- Decorative gradient overlay -->
                    <div style="position: absolute; top: 0; right: 0; width: 100px; height: 100px; background: linear-gradient(135deg, rgba(102, 126, 234, 0.1), rgba(118, 75, 162, 0.1)); border-radius: 0 0 0 100px;"></div>
                    
                    <h2 style="color: #1f2937; font-size: 22px; margin: 0 0 20px 0; font-weight: 600; position: relative;">
                        What you'll get:
                    </h2>
                    <ul style="color: #4b5563; font-size: 16px; line-height: 1.8; margin: 0; padding-left: 0; list-style: none; position: relative;">
                        <li style="margin-bottom: 12px; padding-left: 30px; position: relative;">
                            <span style="position: absolute; left: 0; top: 2px; color: #667eea; font-weight: bold;">📚</span>
                            Weekly digest of latest articles and insights
                        </li>
                        <li style="margin-bottom: 12px; padding-left: 30px; position: relative;">
                            <span style="position: absolute; left: 0; top: 2px; color: #667eea; font-weight: bold;">💡</span>
                            Exclusive content and behind-the-scenes updates
                        </li>
                        <li style="margin-bottom: 12px; padding-left: 30px; position: relative;">
                            <span style="position: absolute; left: 0; top: 2px; color: #667eea; font-weight: bold;">🚀</span>
                            Early access to new features and announcements
                        </li>
                        <li style="margin-bottom: 0; padding-left: 30px; position: relative;">
                            <span style="position: absolute; left: 0; top: 2px; color: #667eea; font-weight: bold;">🎯</span>
                            Curated recommendations just for you
                        </li>
                    </ul>
                </div>
                
                <!-- Excitement Message -->
                <div style="text-align: center; margin-bottom: 35px;">
                    <p style="color: #374151; font-size: 18px; line-height: 1.6; margin: 0; font-weight: 500;">
                        We're excited to have you on board and can't wait to share amazing content with you!
                    </p>
                </div>
                
                <!-- CTA Button -->
                <div style="text-align: center; margin-bottom: 35px;">
                    <a href="http://swop.site:3000" class="cta-button" style="
                        display: inline-block;
                        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                        color: #ffffff;
                        padding: 16px 32px;
                        text-decoration: none;
                        border-radius: 50px;
                        font-weight: 600;
                        font-size: 16px;
                        box-shadow: 0 8px 20px rgba(102, 126, 234, 0.3);
                        transition: all 0.3s ease;
                        text-transform: uppercase;
                        letter-spacing: 0.5px;
                    ">
                        🌟 Explore Blog
                    </a>
                </div>
                
                <!-- Closing Message -->
                <div style="text-align: center; margin-bottom: 35px;">
                    <p style="color: #6b7280; font-size: 16px; margin: 0; font-style: italic;">
                        Stay tuned for amazing content! 🚀
                    </p>
                </div>
                
            </div>
            
            <!-- Footer with Light Mode Optimization -->
            <div style="background: #f8fafc; color: #374151; padding: 30px; text-align: center; position: relative; border-top: 1px solid #e5e7eb;">
                <!-- Decorative Elements -->
                <div style="position: absolute; top: -20px; right: 20px; width: 40px; height: 40px; background: rgba(102, 126, 234, 0.1); border-radius: 50%; opacity: 0.6;"></div>
                
                <p style="margin: 0 0 8px 0; font-weight: 600; font-size: 18px; color: #1f2937;">Best regards,</p>
                <p style="margin: 0 0 20px 0; font-size: 18px; color: #4b5563;">The Blog Team</p>
                
                <!-- Social Links Placeholder -->
                <div style="margin-bottom: 20px;">
                    <span style="color: #6b7280; font-size: 14px;">Follow us for more updates</span>
                </div>
                
                <!-- Unsubscribe -->
                <div style="border-top: 1px solid #e5e7eb; padding-top: 20px;">
                    <p style="color: #9ca3af; font-size: 12px; line-height: 1.5; margin: 0;">
                        You're receiving this because you subscribed to our newsletter.<br>
                        You can unsubscribe at any time by replying to this email with "UNSUBSCRIBE" in the subject line.
                    </p>
                </div>
            </div>
            
        </div>
        
        <!-- Email Footer -->
        <div style="text-align: center; padding: 20px 0;">
            <p style="color: #6b7280; font-size: 12px; margin: 0;">
                © 2025 Blog. All rights reserved.
            </p>
        </div>
        
    </div>
    
</body>
</html>`
    };
    
    console.log('📤 Email data prepared with revamped template');
    console.log('🌐 Calling:', `${STRAPI_URL}/api/email`);
    
    const emailResponse = await fetch(`${STRAPI_URL}/api/email`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(emailData),
    });
    
    console.log('📬 Email API response status:', emailResponse.status);
    console.log('📬 Email API response ok:', emailResponse.ok);
    
    if (emailResponse.ok) {
      console.log('✅ Email API returned success - welcome email sent to:', email);
      return true;
    } else {
      const errorText = await emailResponse.text();
      console.error('❌ Email API returned error:', emailResponse.status, errorText);
      return false;
    }
  } catch (error) {
    console.error('❌ Network/fetch error in sendWelcomeEmail:', error.message);
    console.error('❌ Full error:', error);
    return false;
  }
}


export async function POST(request: NextRequest) {
  try {
    const { email } = await request.json();

    if (!email) {
      return NextResponse.json(
        { error: 'Email is required' },
        { status: 400 }
      );
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return NextResponse.json(
        { error: 'Please enter a valid email address' },
        { status: 400 }
      );
    }

    // Load existing subscribers from local file
    const subscribers = await loadSubscribers();
    
    // Check if email already exists and is active
    if (subscribers[email] && subscribers[email].isActive) {
      return NextResponse.json(
        { error: 'This email is already subscribed to our newsletter' },
        { status: 409 }
      );
    }

    // Add or reactivate subscription in local storage
    subscribers[email] = {
      subscribedAt: new Date().toISOString(),
      isActive: true
    };

    // Save updated subscribers
    await saveSubscribers(subscribers);

    // Send welcome email
    console.log('🔄 About to send welcome email...');
    const emailSent = await sendWelcomeEmail(email);
    
    console.log('📧 Newsletter subscription for:', email, emailSent ? '✅ (welcome email sent)' : '❌ (welcome email failed)');

    return NextResponse.json({
      message: 'Successfully subscribed to newsletter!',
      email: email,
      welcomeEmailSent: emailSent
    });

  } catch (error) {
    console.error('Newsletter subscription error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function GET() {
  return NextResponse.json(
    { message: 'Newsletter API endpoint' },
    { status: 200 }
  );
}