import { NextRequest, NextResponse } from 'next/server';
import { promises as fs } from 'fs';
import path from 'path';

const STRAPI_URL = "http://swop.site:1337";
const SUBSCRIBERS_FILE = path.join(process.cwd(), 'data', 'subscribers.json');

interface SubscriberData {
  [email: string]: {
    subscribedAt: string;
    isActive: boolean;
  };
}

async function ensureDataDirectory() {
  const dataDir = path.join(process.cwd(), 'data');
  try {
    await fs.access(dataDir);
  } catch {
    await fs.mkdir(dataDir, { recursive: true });
  }
}

async function loadSubscribers(): Promise<SubscriberData> {
  try {
    await ensureDataDirectory();
    const data = await fs.readFile(SUBSCRIBERS_FILE, 'utf-8');
    return JSON.parse(data);
  } catch {
    return {};
  }
}

async function saveSubscribers(subscribers: SubscriberData): Promise<void> {
  await ensureDataDirectory();
  await fs.writeFile(SUBSCRIBERS_FILE, JSON.stringify(subscribers, null, 2));
}

async function sendWelcomeEmail(email: string): Promise<boolean> {
  try {
    console.log('📧 Attempting to send welcome email to:', email);
    console.log('🌐 Using Strapi URL:', STRAPI_URL);
    
    // Simple email that matches the working format
    const emailData = {
      to: email,
      subject: 'Welcome to ModernBlog Newsletter! 🎉',
      text: 'Welcome to ModernBlog! Thank you for subscribing to our newsletter!',
      html: `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Welcome to ModernBlog Newsletter! 🎉</title>
</head>
<body style="font-family: Arial, sans-serif; background-color: #f8fafc; margin: 0; padding: 20px;">
  <div style="max-width: 600px; margin: 0 auto; background-color: #ffffff; padding: 40px; border-radius: 12px;">
      <h1 style="color: #2563eb; text-align: center; margin-bottom: 10px;">Welcome to ModernBlog! 🎉</h1>
      <p style="color: #6b7280; text-align: center; font-size: 18px; margin-bottom: 30px;">Your gateway to amazing content</p>
      
      <p style="color: #374151; margin-bottom: 20px;">Hi there! 👋</p>
      
      <p style="color: #374151; margin-bottom: 30px;">Thank you for subscribing to our newsletter! You've just joined a community of curious minds who love staying updated with the latest insights, articles, and exclusive content.</p>
      
      <div style="background-color: #f8fafc; padding: 25px; border-radius: 8px; margin-bottom: 30px;">
          <h2 style="color: #1f2937; margin-bottom: 15px;">What you'll get:</h2>
          <ul style="color: #4b5563; line-height: 1.6;">
              <li>Weekly digest of latest articles and insights</li>
              <li>Exclusive content and behind-the-scenes updates</li>
              <li>Early access to new features and announcements</li>
              <li>Curated recommendations just for you</li>
          </ul>
      </div>
      
      <p style="color: #374151; text-align: center; margin-bottom: 30px;">We're excited to have you on board and can't wait to share amazing content with you!</p>
      
      <div style="text-align: center; margin-bottom: 30px;">
          <a href="#" style="background-color: #2563eb; color: #ffffff; padding: 15px 30px; text-decoration: none; border-radius: 8px; font-weight: bold;">Explore ModernBlog</a>
      </div>
      
      <p style="color: #374151; text-align: center; margin-bottom: 30px;">Stay tuned for amazing content! 🚀</p>
      
      <div style="background-color: #2563eb; color: #ffffff; padding: 20px; border-radius: 8px; text-align: center; margin-bottom: 30px;">
          <p style="margin: 0; font-weight: bold;">Best regards,</p>
          <p style="margin: 5px 0 0 0;">The ModernBlog Team</p>
      </div>
      
      <div style="text-align: center; border-top: 1px solid #e5e7eb; padding-top: 20px;">
          <p style="color: #9ca3af; font-size: 12px; margin: 0;">
              You're receiving this because you subscribed to our newsletter.<br>
              You can unsubscribe at any time by replying to this email.
          </p>
      </div>
  </div>
</body>
</html>`
    };
    
    console.log('📤 Email data prepared:', emailData);
    
    const emailResponse = await fetch(`${STRAPI_URL}/api/email`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(emailData),
    });
    
    console.log('📬 Email API response status:', emailResponse.status);
    console.log('📬 Email API response ok:', emailResponse.ok);
    
    if (emailResponse.ok) {
      console.log('✅ Email API returned success - welcome email sent to:', email);
      return true;
    } else {
      const errorText = await emailResponse.text();
      console.error('❌ Email API returned error:', emailResponse.status, errorText);
      return false;
    }
  } catch (error) {
    console.error('❌ Network/fetch error in sendWelcomeEmail:', error.message);
    console.error('❌ Full error:', error);
    return false;
  }
}


export async function POST(request: NextRequest) {
  try {
    const { email } = await request.json();

    if (!email) {
      return NextResponse.json(
        { error: 'Email is required' },
        { status: 400 }
      );
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return NextResponse.json(
        { error: 'Please enter a valid email address' },
        { status: 400 }
      );
    }

    // Load existing subscribers from local file
    const subscribers = await loadSubscribers();
    
    // Check if email already exists and is active
    if (subscribers[email] && subscribers[email].isActive) {
      return NextResponse.json(
        { error: 'This email is already subscribed to our newsletter' },
        { status: 409 }
      );
    }

    // Add or reactivate subscription in local storage
    subscribers[email] = {
      subscribedAt: new Date().toISOString(),
      isActive: true
    };

    // Save updated subscribers
    await saveSubscribers(subscribers);

    // Send welcome email
    console.log('🔄 About to send welcome email...');
    const emailSent = await sendWelcomeEmail(email);
    
    console.log('📧 Newsletter subscription for:', email, emailSent ? '✅ (welcome email sent)' : '❌ (welcome email failed)');

    return NextResponse.json({
      message: 'Successfully subscribed to newsletter!',
      email: email,
      welcomeEmailSent: emailSent
    });

  } catch (error) {
    console.error('Newsletter subscription error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function GET() {
  return NextResponse.json(
    { message: 'Newsletter API endpoint' },
    { status: 200 }
  );
}