# 📸 Media & Slider Implementation Analysis

## 🎯 **Current Implementation Overview**

The blog uses **dynamic content blocks** to render media and sliders on article pages. Here's how it's structured:

### **1. Content Block System**
- Articles have a `blocks` field containing an array of content blocks
- Each block has a `__component` field that determines its type
- Supported components: `shared.quote`, `shared.rich-text`, `shared.media`, `shared.slider`

### **2. Media Component (`shared.media`)**
```typescript
// Expected Strapi structure:
{
  __component: "shared.media",
  id: number,
  file: {
    url: string,
    alternativeText?: string,
    name?: string,
    formats?: {
      large?: { url: string },
      medium?: { url: string },
      small?: { url: string },
      thumbnail?: { url: string }
    }
  }
}
```

**How it renders:**
- Uses Next.js `Image` component for optimization
- Constructs URL: `${strapiUrl}${imageUrl}`
- Prefers `medium` format, falls back to original
- Shows debug info when media fails to load

### **3. Slider Component (`shared.slider`)**
```typescript
// Expected Strapi structure:
{
  __component: "shared.slider",
  id: number,
  files: Array<{
    url: string,
    alternativeText?: string,
    name?: string,
    formats?: {
      large?: { url: string },
      medium?: { url: string },
      small?: { url: string },
      thumbnail?: { url: string }
    }
  }>
}
```

**Features:**
- Navigation arrows (prev/next)
- Slide indicators (dots)
- Auto-sizing to container
- Responsive design

## 🚨 **Common Issues & Failed Load Causes**

### **1. Missing Populate Parameters**
**Problem:** Strapi doesn't return media files by default
```javascript
// ❌ Wrong - doesn't populate media
fetch('/api/articles/my-slug')

// ✅ Correct - populates all relations
fetch('/api/articles/my-slug?populate=*')
// or more specific:
fetch('/api/articles/my-slug?populate[blocks][populate]=*')
```

### **2. Incorrect Content Type Structure in Strapi**
**Required Strapi Components:**

#### **shared.media Component:**
```
Component: shared.media
Fields:
- file (Media - Single, Required)
```

#### **shared.slider Component:**
```
Component: shared.slider  
Fields:
- files (Media - Multiple, Required)
```

### **3. URL Construction Issues**
**Current implementation:**
```typescript
// Media component
const imageUrl = block.file.formats?.medium?.url || block.file.url;
const fullUrl = strapiUrl + imageUrl; // "http://swop.site:1337/uploads/..."

// Slider component  
const imageUrl = currentFile.formats?.medium?.url || currentFile.url;
const fullUrl = strapiUrl + imageUrl;
```

**Potential issues:**
- Missing `/uploads/` prefix
- Incorrect STRAPI_URL configuration
- CORS issues with media domain

### **4. Missing Image Formats**
The code expects Strapi to generate multiple image formats:
- `thumbnail` (150x150)
- `small` (500x500) 
- `medium` (750x750)
- `large` (1000x1000)

## 🔧 **Debugging Information**

### **Debug Features Already Implemented:**
1. **Console logging:** `console.log('MediaComponent block:', block)`
2. **Debug panel:** Shows raw block data when media fails
3. **Fallback UI:** Shows "Media content not available" with block ID

### **What to Check in Strapi:**

#### **1. Article API Response Structure:**
```bash
GET http://swop.site:1337/api/articles/[slug]?populate=*
```

**Expected response:**
```json
{
  "data": {
    "id": 1,
    "attributes": {
      "title": "Article Title",
      "blocks": [
        {
          "__component": "shared.media",
          "id": 1,
          "file": {
            "data": {
              "id": 1,
              "attributes": {
                "url": "/uploads/image.jpg",
                "alternativeText": "Alt text",
                "formats": {
                  "medium": {
                    "url": "/uploads/medium_image.jpg"
                  }
                }
              }
            }
          }
        }
      ]
    }
  }
}
```

#### **2. Media Upload Settings:**
Check in Strapi admin:
- **Settings → Media Library → Settings**
- Ensure image formats are enabled
- Check upload size limits
- Verify file types are allowed

#### **3. Permissions:**
- **Settings → Roles → Public**
- Ensure `Upload` permissions are set:
  - `find` ✅
  - `findOne` ✅

## 🛠️ **Potential Fixes for Your Strapi Contributor**

### **Fix 1: Ensure Proper Population**
```javascript
// In Strapi API response, make sure blocks are populated with media
// This might require custom controller or middleware
```

### **Fix 2: Check Component Structure**
Verify these components exist in Strapi:
1. `shared.media` with `file` field (Media - Single)
2. `shared.slider` with `files` field (Media - Multiple)

### **Fix 3: Media URL Structure**
Ensure Strapi returns URLs in this format:
```json
{
  "file": {
    "data": {
      "attributes": {
        "url": "/uploads/filename.jpg",
        "formats": {
          "medium": {
            "url": "/uploads/medium_filename.jpg"
          }
        }
      }
    }
  }
}
```

### **Fix 4: CORS Configuration**
If media is served from different domain:
```javascript
// In Strapi config/middlewares.js
module.exports = [
  // ...
  {
    name: 'strapi::cors',
    config: {
      origin: ['http://localhost:3000', 'https://your-domain.com'],
      headers: ['Content-Type', 'Authorization', 'Origin', 'Accept'],
    },
  },
];
```

## 🧪 **Testing Steps**

### **1. Test API Response:**
```bash
curl "http://swop.site:1337/api/articles?populate=*" | jq '.data[0].attributes.blocks'
```

### **2. Test Media Access:**
```bash
curl -I "http://swop.site:1337/uploads/[filename]"
# Should return 200 OK
```

### **3. Check Frontend Console:**
Look for these logs in browser console:
- `MediaComponent block: {...}`
- Network errors for image requests
- CORS errors

## 📋 **Questions for Strapi Contributor**

1. **Are the `shared.media` and `shared.slider` components properly configured?**
2. **Is the `populate=*` parameter working for nested media relations?**
3. **Are image formats being generated correctly on upload?**
4. **What's the exact structure of the API response for articles with media blocks?**
5. **Are there any custom middlewares affecting media serving?**
6. **Is the media library properly configured for public access?**

The frontend code is robust and includes proper error handling - the issue is likely in the Strapi configuration or API response structure.