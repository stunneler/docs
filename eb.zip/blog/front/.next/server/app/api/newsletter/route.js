(()=>{var a={};a.id=103,a.ids=[103],a.modules={261:a=>{"use strict";a.exports=require("next/dist/shared/lib/router/utils/app-paths")},3295:a=>{"use strict";a.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:a=>{"use strict";a.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},14342:(a,b,c)=>{"use strict";c.r(b),c.d(b,{handler:()=>L,patchFetch:()=>K,routeModule:()=>G,serverHooks:()=>J,workAsyncStorage:()=>H,workUnitAsyncStorage:()=>I});var d={};c.r(d),c.d(d,{GET:()=>F,POST:()=>E});var e=c(96559),f=c(48088),g=c(37719),h=c(26191),i=c(81289),j=c(261),k=c(92603),l=c(39893),m=c(14823),n=c(47220),o=c(66946),p=c(47912),q=c(99786),r=c(46143),s=c(86439),t=c(43365),u=c(32190),v=c(29021),w=c(33873),x=c.n(w);let y="http://swop.site:1337",z=x().join(process.cwd(),"data","subscribers.json");async function A(){let a=x().join(process.cwd(),"data");try{await v.promises.access(a)}catch{await v.promises.mkdir(a,{recursive:!0})}}async function B(){try{await A();let a=await v.promises.readFile(z,"utf-8");return JSON.parse(a)}catch{return{}}}async function C(a){await A(),await v.promises.writeFile(z,JSON.stringify(a,null,2))}async function D(a){try{console.log("\uD83D\uDCE7 Attempting to send welcome email to:",a),console.log("\uD83C\uDF10 Using Strapi URL:",y);let b={to:a,subject:"Welcome to Blog Newsletter! \uD83C\uDF89",text:"Welcome to Blog! Thank you for subscribing to our newsletter!",html:`
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to Blog Newsletter! 🎉</title>
    <style>
        @media only screen and (max-width: 600px) {
            .container { width: 100% !important; padding: 20px !important; }
            .header-title { font-size: 24px !important; }
            .cta-button { padding: 12px 24px !important; font-size: 14px !important; }
        }
    </style>
</head>
<body style="margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f8fafc; min-height: 100vh;">
    
    <!-- Email Container -->
    <div class="container" style="max-width: 600px; margin: 0 auto; padding: 40px 20px;">
        
        <!-- Main Email Card -->
        <div style="background: #ffffff; border-radius: 20px; box-shadow: 0 20px 40px rgba(0,0,0,0.1); overflow: hidden;">
            
            <!-- Header with Gradient -->
            <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 40px 30px; text-align: center; position: relative;">
                <!-- Decorative Elements -->
                <div style="position: absolute; top: -50px; right: -50px; width: 100px; height: 100px; background: rgba(255,255,255,0.1); border-radius: 50%; opacity: 0.5;"></div>
                <div style="position: absolute; bottom: -30px; left: -30px; width: 60px; height: 60px; background: rgba(255,255,255,0.1); border-radius: 50%; opacity: 0.7;"></div>
                
                <h1 class="header-title" style="color: #ffffff; font-size: 32px; font-weight: 700; margin: 0 0 10px 0; text-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                    Welcome to Blog! 🎉
                </h1>
                <p style="color: rgba(255,255,255,0.9); font-size: 18px; margin: 0; font-weight: 300;">
                    Your gateway to amazing content
                </p>
            </div>
            
            <!-- Content Section -->
            <div style="padding: 40px 30px;">
                
                <!-- Greeting -->
                <div style="margin-bottom: 30px;">
                    <p style="color: #374151; font-size: 18px; margin: 0 0 20px 0; font-weight: 500;">Hi there! 👋</p>
                    <p style="color: #6b7280; font-size: 16px; line-height: 1.6; margin: 0;">
                        Thank you for subscribing to our newsletter! You've just joined a community of curious minds who love staying updated with the latest insights, articles, and exclusive content.
                    </p>
                </div>
                
                <!-- Features Box -->
                <div style="background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%); padding: 30px; border-radius: 16px; margin-bottom: 30px; border-left: 4px solid #667eea; position: relative; overflow: hidden;">
                    <!-- Decorative gradient overlay -->
                    <div style="position: absolute; top: 0; right: 0; width: 100px; height: 100px; background: linear-gradient(135deg, rgba(102, 126, 234, 0.1), rgba(118, 75, 162, 0.1)); border-radius: 0 0 0 100px;"></div>
                    
                    <h2 style="color: #1f2937; font-size: 22px; margin: 0 0 20px 0; font-weight: 600; position: relative;">
                        What you'll get:
                    </h2>
                    <ul style="color: #4b5563; font-size: 16px; line-height: 1.8; margin: 0; padding-left: 0; list-style: none; position: relative;">
                        <li style="margin-bottom: 12px; padding-left: 30px; position: relative;">
                            <span style="position: absolute; left: 0; top: 2px; color: #667eea; font-weight: bold;">📚</span>
                            Weekly digest of latest articles and insights
                        </li>
                        <li style="margin-bottom: 12px; padding-left: 30px; position: relative;">
                            <span style="position: absolute; left: 0; top: 2px; color: #667eea; font-weight: bold;">💡</span>
                            Exclusive content and behind-the-scenes updates
                        </li>
                        <li style="margin-bottom: 12px; padding-left: 30px; position: relative;">
                            <span style="position: absolute; left: 0; top: 2px; color: #667eea; font-weight: bold;">🚀</span>
                            Early access to new features and announcements
                        </li>
                        <li style="margin-bottom: 0; padding-left: 30px; position: relative;">
                            <span style="position: absolute; left: 0; top: 2px; color: #667eea; font-weight: bold;">🎯</span>
                            Curated recommendations just for you
                        </li>
                    </ul>
                </div>
                
                <!-- Excitement Message -->
                <div style="text-align: center; margin-bottom: 35px;">
                    <p style="color: #374151; font-size: 18px; line-height: 1.6; margin: 0; font-weight: 500;">
                        We're excited to have you on board and can't wait to share amazing content with you!
                    </p>
                </div>
                
                <!-- CTA Button -->
                <div style="text-align: center; margin-bottom: 35px;">
                    <a href="http://swop.site:3000" class="cta-button" style="
                        display: inline-block;
                        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                        color: #ffffff;
                        padding: 16px 32px;
                        text-decoration: none;
                        border-radius: 50px;
                        font-weight: 600;
                        font-size: 16px;
                        box-shadow: 0 8px 20px rgba(102, 126, 234, 0.3);
                        transition: all 0.3s ease;
                        text-transform: uppercase;
                        letter-spacing: 0.5px;
                    ">
                        🌟 Explore Blog
                    </a>
                </div>
                
                <!-- Closing Message -->
                <div style="text-align: center; margin-bottom: 35px;">
                    <p style="color: #6b7280; font-size: 16px; margin: 0; font-style: italic;">
                        Stay tuned for amazing content! 🚀
                    </p>
                </div>
                
            </div>
            
            <!-- Footer with Light Mode Optimization -->
            <div style="background: #f8fafc; color: #374151; padding: 30px; text-align: center; position: relative; border-top: 1px solid #e5e7eb;">
                <!-- Decorative Elements -->
                <div style="position: absolute; top: -20px; right: 20px; width: 40px; height: 40px; background: rgba(102, 126, 234, 0.1); border-radius: 50%; opacity: 0.6;"></div>
                
                <p style="margin: 0 0 8px 0; font-weight: 600; font-size: 18px; color: #1f2937;">Best regards,</p>
                <p style="margin: 0 0 20px 0; font-size: 18px; color: #4b5563;">The Blog Team</p>
                
                <!-- Social Links Placeholder -->
                <div style="margin-bottom: 20px;">
                    <span style="color: #6b7280; font-size: 14px;">Follow us for more updates</span>
                </div>
                
                <!-- Unsubscribe -->
                <div style="border-top: 1px solid #e5e7eb; padding-top: 20px;">
                    <p style="color: #9ca3af; font-size: 12px; line-height: 1.5; margin: 0;">
                        You're receiving this because you subscribed to our newsletter.<br>
                        You can unsubscribe at any time by replying to this email with "UNSUBSCRIBE" in the subject line.
                    </p>
                </div>
            </div>
            
        </div>
        
        <!-- Email Footer -->
        <div style="text-align: center; padding: 20px 0;">
            <p style="color: #6b7280; font-size: 12px; margin: 0;">
                \xa9 2025 Blog. All rights reserved.
            </p>
        </div>
        
    </div>
    
</body>
</html>`};console.log("\uD83D\uDCE4 Email data prepared with revamped template"),console.log("\uD83C\uDF10 Calling:",`${y}/api/email`);let c=await fetch(`${y}/api/email`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(b)});if(console.log("\uD83D\uDCEC Email API response status:",c.status),console.log("\uD83D\uDCEC Email API response ok:",c.ok),c.ok)return console.log("✅ Email API returned success - welcome email sent to:",a),!0;{let a=await c.text();return console.error("❌ Email API returned error:",c.status,a),!1}}catch(a){return console.error("❌ Network/fetch error in sendWelcomeEmail:",a.message),console.error("❌ Full error:",a),!1}}async function E(a){try{let{email:b}=await a.json();if(!b)return u.NextResponse.json({error:"Email is required"},{status:400});if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(b))return u.NextResponse.json({error:"Please enter a valid email address"},{status:400});let c=await B();if(c[b]&&c[b].isActive)return u.NextResponse.json({error:"This email is already subscribed to our newsletter"},{status:409});c[b]={subscribedAt:new Date().toISOString(),isActive:!0},await C(c),console.log("\uD83D\uDD04 About to send welcome email...");let d=await D(b);return console.log("\uD83D\uDCE7 Newsletter subscription for:",b,d?"✅ (welcome email sent)":"❌ (welcome email failed)"),u.NextResponse.json({message:"Successfully subscribed to newsletter!",email:b,welcomeEmailSent:d})}catch(a){return console.error("Newsletter subscription error:",a),u.NextResponse.json({error:"Internal server error"},{status:500})}}async function F(){return u.NextResponse.json({message:"Newsletter API endpoint"},{status:200})}let G=new e.AppRouteRouteModule({definition:{kind:f.RouteKind.APP_ROUTE,page:"/api/newsletter/route",pathname:"/api/newsletter",filename:"route",bundlePath:"app/api/newsletter/route"},distDir:".next",projectDir:"",resolvedPagePath:"/home/fireraid8/Development/projects/1/front/src/app/api/newsletter/route.ts",nextConfigOutput:"",userland:d}),{workAsyncStorage:H,workUnitAsyncStorage:I,serverHooks:J}=G;function K(){return(0,g.patchFetch)({workAsyncStorage:H,workUnitAsyncStorage:I})}async function L(a,b,c){var d;let e="/api/newsletter/route";"/index"===e&&(e="/");let g=await G.prepare(a,b,{srcPage:e,multiZoneDraftMode:"false"});if(!g)return b.statusCode=400,b.end("Bad Request"),null==c.waitUntil||c.waitUntil.call(c,Promise.resolve()),null;let{buildId:u,params:v,nextConfig:w,isDraftMode:x,prerenderManifest:y,routerServerContext:z,isOnDemandRevalidate:A,revalidateOnlyGenerated:B,resolvedPathname:C}=g,D=(0,j.normalizeAppPath)(e),E=!!(y.dynamicRoutes[D]||y.routes[C]);if(E&&!x){let a=!!y.routes[C],b=y.dynamicRoutes[D];if(b&&!1===b.fallback&&!a)throw new s.NoFallbackError}let F=null;!E||G.isDev||x||(F="/index"===(F=C)?"/":F);let H=!0===G.isDev||!E,I=E&&!H,J=a.method||"GET",K=(0,i.getTracer)(),L=K.getActiveScopeSpan(),M={params:v,prerenderManifest:y,renderOpts:{experimental:{dynamicIO:!!w.experimental.dynamicIO,authInterrupts:!!w.experimental.authInterrupts},supportsDynamicResponse:H,incrementalCache:(0,h.getRequestMeta)(a,"incrementalCache"),cacheLifeProfiles:null==(d=w.experimental)?void 0:d.cacheLife,isRevalidate:I,waitUntil:c.waitUntil,onClose:a=>{b.on("close",a)},onAfterTaskError:void 0,onInstrumentationRequestError:(b,c,d)=>G.onRequestError(a,b,d,z)},sharedContext:{buildId:u}},N=new k.NodeNextRequest(a),O=new k.NodeNextResponse(b),P=l.NextRequestAdapter.fromNodeNextRequest(N,(0,l.signalFromNodeResponse)(b));try{let d=async c=>G.handle(P,M).finally(()=>{if(!c)return;c.setAttributes({"http.status_code":b.statusCode,"next.rsc":!1});let d=K.getRootSpanAttributes();if(!d)return;if(d.get("next.span_type")!==m.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${d.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let e=d.get("next.route");if(e){let a=`${J} ${e}`;c.setAttributes({"next.route":e,"http.route":e,"next.span_name":a}),c.updateName(a)}else c.updateName(`${J} ${a.url}`)}),g=async g=>{var i,j;let k=async({previousCacheEntry:f})=>{try{if(!(0,h.getRequestMeta)(a,"minimalMode")&&A&&B&&!f)return b.statusCode=404,b.setHeader("x-nextjs-cache","REVALIDATED"),b.end("This page could not be found"),null;let e=await d(g);a.fetchMetrics=M.renderOpts.fetchMetrics;let i=M.renderOpts.pendingWaitUntil;i&&c.waitUntil&&(c.waitUntil(i),i=void 0);let j=M.renderOpts.collectedTags;if(!E)return await (0,o.I)(N,O,e,M.renderOpts.pendingWaitUntil),null;{let a=await e.blob(),b=(0,p.toNodeOutgoingHttpHeaders)(e.headers);j&&(b[r.NEXT_CACHE_TAGS_HEADER]=j),!b["content-type"]&&a.type&&(b["content-type"]=a.type);let c=void 0!==M.renderOpts.collectedRevalidate&&!(M.renderOpts.collectedRevalidate>=r.INFINITE_CACHE)&&M.renderOpts.collectedRevalidate,d=void 0===M.renderOpts.collectedExpire||M.renderOpts.collectedExpire>=r.INFINITE_CACHE?void 0:M.renderOpts.collectedExpire;return{value:{kind:t.CachedRouteKind.APP_ROUTE,status:e.status,body:Buffer.from(await a.arrayBuffer()),headers:b},cacheControl:{revalidate:c,expire:d}}}}catch(b){throw(null==f?void 0:f.isStale)&&await G.onRequestError(a,b,{routerKind:"App Router",routePath:e,routeType:"route",revalidateReason:(0,n.c)({isRevalidate:I,isOnDemandRevalidate:A})},z),b}},l=await G.handleResponse({req:a,nextConfig:w,cacheKey:F,routeKind:f.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:y,isRoutePPREnabled:!1,isOnDemandRevalidate:A,revalidateOnlyGenerated:B,responseGenerator:k,waitUntil:c.waitUntil});if(!E)return null;if((null==l||null==(i=l.value)?void 0:i.kind)!==t.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==l||null==(j=l.value)?void 0:j.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});(0,h.getRequestMeta)(a,"minimalMode")||b.setHeader("x-nextjs-cache",A?"REVALIDATED":l.isMiss?"MISS":l.isStale?"STALE":"HIT"),x&&b.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let m=(0,p.fromNodeOutgoingHttpHeaders)(l.value.headers);return(0,h.getRequestMeta)(a,"minimalMode")&&E||m.delete(r.NEXT_CACHE_TAGS_HEADER),!l.cacheControl||b.getHeader("Cache-Control")||m.get("Cache-Control")||m.set("Cache-Control",(0,q.getCacheControlHeader)(l.cacheControl)),await (0,o.I)(N,O,new Response(l.value.body,{headers:m,status:l.value.status||200})),null};L?await g(L):await K.withPropagatedContext(a.headers,()=>K.trace(m.BaseServerSpan.handleRequest,{spanName:`${J} ${a.url}`,kind:i.SpanKind.SERVER,attributes:{"http.method":J,"http.target":a.url}},g))}catch(b){if(L||await G.onRequestError(a,b,{routerKind:"App Router",routePath:D,routeType:"route",revalidateReason:(0,n.c)({isRevalidate:I,isOnDemandRevalidate:A})}),E)throw b;return await (0,o.I)(N,O,new Response(null,{status:500})),null}}},29021:a=>{"use strict";a.exports=require("fs")},29294:a=>{"use strict";a.exports=require("next/dist/server/app-render/work-async-storage.external.js")},33873:a=>{"use strict";a.exports=require("path")},44870:a=>{"use strict";a.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},63033:a=>{"use strict";a.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},78335:()=>{},86439:a=>{"use strict";a.exports=require("next/dist/shared/lib/no-fallback-error.external")},96487:()=>{}};var b=require("../../../webpack-runtime.js");b.C(a);var c=b.X(0,[985,55],()=>b(b.s=14342));module.exports=c})();