__turbopack_load_page_chunks__("/_error", [
  "static/chunks/node_modules_next_dist_compiled_next-devtools_index_82a36480.js",
  "static/chunks/node_modules_next_dist_compiled_ca41998d._.js",
  "static/chunks/node_modules_next_dist_shared_lib_3cbd5cc2._.js",
  "static/chunks/node_modules_next_dist_client_becf32a6._.js",
  "static/chunks/node_modules_next_dist_7c4b9b2a._.js",
  "static/chunks/node_modules_next_error_8c8bf619.js",
  "static/chunks/[next]_entry_page-loader_ts_8ccf5f86._.js",
  "static/chunks/node_modules_react-dom_82bb97c6._.js",
  "static/chunks/node_modules_f2979c3a._.js",
  "static/chunks/[root-of-the-server]__95ff7225._.js",
  "static/chunks/pages__error_5771e187._.js",
  "static/chunks/pages__error_50fcf3db._.js"
])
