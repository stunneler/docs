# 🔗 Webhook Setup Guide for ModernBlog

## 📋 **Overview**

This guide explains how to configure Strapi webhooks to work with the ModernBlog webhook system.

## 🚀 **Webhook Endpoints**

### **Available Endpoints**
```
POST /api/webhooks/newsletter    - Newsletter-related events
POST /api/webhooks/articles      - Article-related events  
POST /api/webhooks/test          - Test webhook events
```

### **Base URL**
```
https://your-domain.com/api/webhooks/[endpoint]
```

## ⚙️ **Strapi Webhook Configuration**

### **1. Access Webhook Settings**
1. Go to Strapi Admin Panel
2. Navigate to **Settings** → **Webhooks**
3. Click **"Create new webhook"**

### **2. Newsletter Webhook Setup**
```
Name: Newsletter Events
URL: https://your-domain.com/api/webhooks/newsletter
Events:
  ✅ Entry create (newsletter-subscription)
  ✅ Entry update (newsletter-subscription)
  ✅ Entry delete (newsletter-subscription)
Headers:
  Content-Type: application/json
  Authorization: Bearer your-webhook-secret (optional)
```

### **3. Article Webhook Setup**
```
Name: Article Events  
URL: https://your-domain.com/api/webhooks/articles
Events:
  ✅ Entry create (article)
  ✅ Entry update (article)
  ✅ Entry publish (article)
  ✅ Entry unpublish (article)
  ✅ Entry delete (article)
Headers:
  Content-Type: application/json
  Authorization: Bearer your-webhook-secret (optional)
```

## 📝 **Event Payload Structure**

### **Expected Webhook Payload**
```json
{
  "event": "entry.create",
  "created_at": "2024-01-15T10:30:00.000Z",
  "model": "article",
  "entry": {
    "id": 123,
    "documentId": "abc123def456",
    "title": "Sample Article",
    "description": "Article description",
    "slug": "sample-article",
    "publishedAt": "2024-01-15T10:30:00.000Z",
    "author": {
      "name": "John Doe",
      "email": "john@example.com"
    },
    "category": {
      "name": "Technology",
      "slug": "technology"
    }
  }
}
```

## 🔧 **Webhook Event Types**

### **Article Events**
- `entry.create` - New article created
- `entry.update` - Article updated
- `entry.publish` - Article published
- `entry.unpublish` - Article unpublished
- `entry.delete` - Article deleted

### **Newsletter Events**
- `entry.create` - New subscription
- `entry.update` - Subscription updated
- `entry.delete` - Subscription removed

## 🧪 **Testing Webhooks**

### **1. Using the Test Panel**
1. Click the FloatingActionButton (bottom right)
2. Select "Test Webhooks"
3. Choose event type
4. Click "Trigger Webhook"

### **2. Using API Directly**
```bash
curl -X POST https://your-domain.com/api/webhooks/test \
  -H "Content-Type: application/json" \
  -d '{
    "eventType": "article-create",
    "model": "article"
  }'
```

### **3. Monitor Results**
- Check WebhookStatus component (purple lightning icon)
- View real-time event logs
- Monitor success/error status

## 🔍 **Webhook Monitoring**

### **Real-time Monitoring Features**
- ✅ Live event tracking
- ✅ Success/error status indicators
- ✅ Event timestamps and details
- ✅ Event history (last 20 events)
- ✅ Clear events functionality
- ✅ Test event triggering

### **Event Status Types**
- 🟢 **Success** - Webhook processed successfully
- 🔴 **Error** - Webhook processing failed
- 🟡 **Pending** - Webhook processing in progress

## 🛠️ **Automated Workflows**

### **Article Publication Workflow**
1. Article published in Strapi
2. Webhook triggered to Next.js
3. Automated actions:
   - Site regeneration (ISR)
   - Newsletter campaign scheduling
   - Social media posting
   - Search index update
   - Team notifications
   - Analytics tracking

### **Newsletter Subscription Workflow**
1. User subscribes via form
2. Subscription saved to Strapi
3. Webhook triggered
4. Automated actions:
   - Welcome email sent
   - Team notification
   - Analytics update
   - Subscription metrics

## 🔒 **Security Considerations**

### **Webhook Security**
```javascript
// Add webhook signature verification
const verifyWebhookSignature = (payload, signature, secret) => {
  const expectedSignature = crypto
    .createHmac('sha256', secret)
    .update(payload)
    .digest('hex');
  
  return crypto.timingSafeEqual(
    Buffer.from(signature),
    Buffer.from(expectedSignature)
  );
};
```

### **Environment Variables**
```env
WEBHOOK_SECRET=your-secret-key
STRAPI_WEBHOOK_TOKEN=your-strapi-token
```

## 📊 **Monitoring & Debugging**

### **Webhook Logs**
- Check browser console for webhook events
- Monitor Network tab for webhook requests
- Use WebhookStatus component for real-time monitoring

### **Common Issues**
1. **Webhook not triggering**
   - Check Strapi webhook configuration
   - Verify URL is accessible
   - Check event selection

2. **Events not appearing**
   - Check browser localStorage
   - Verify webhook endpoint responses
   - Check network connectivity

3. **Processing errors**
   - Check server logs
   - Verify payload structure
   - Check authentication

## 🚀 **Production Deployment**

### **Pre-deployment Checklist**
- ✅ Configure production webhook URLs
- ✅ Set up webhook secrets
- ✅ Test all webhook endpoints
- ✅ Configure error monitoring
- ✅ Set up logging
- ✅ Test automated workflows

### **Monitoring Setup**
- Configure error tracking (Sentry, etc.)
- Set up webhook failure alerts
- Monitor webhook response times
- Track webhook success rates

---

## 📞 **Support**

For webhook-related issues:
1. Check the WebhookStatus monitor
2. Test using the webhook test panel
3. Verify Strapi webhook configuration
4. Check server logs for errors

The webhook system provides comprehensive automation and monitoring for your ModernBlog platform! 🎉