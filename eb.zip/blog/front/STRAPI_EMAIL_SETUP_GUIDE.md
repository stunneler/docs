# 📧 Strapi Email Configuration Guide

## Overview
This guide explains how to properly configure Strapi's email plugin to work with the newsletter integration.

## 🔧 Required Strapi Configuration

### 1. Create Email API Route in Strapi

Create a custom API route in your Strapi project to handle email sending:

**File: `src/api/email/routes/email.js`**
```javascript
module.exports = {
  routes: [
    {
      method: 'POST',
      path: '/email',
      handler: 'email.send',
      config: {
        policies: [],
        middlewares: [],
      },
    },
  ],
};
```

**File: `src/api/email/controllers/email.js`**
```javascript
'use strict';

module.exports = {
  async send(ctx) {
    try {
      const { to, subject, text, html } = ctx.request.body;

      if (!to || !subject || (!text && !html)) {
        return ctx.badRequest('Missing required fields: to, subject, and either text or html');
      }

      // Use Strapi's email plugin
      await strapi.plugins['email'].services.email.send({
        to,
        subject,
        text,
        html,
      });

      ctx.send({
        message: 'Email sent successfully'
      });
    } catch (error) {
      console.error('Email sending error:', error);
      ctx.internalServerError('Failed to send email');
    }
  },
};
```

### 2. Configure Email Plugin

**File: `config/plugins.js` (or `config/plugins.ts`)**

#### For Development (using Sendmail)
```javascript
module.exports = ({ env }) => ({
  email: {
    config: {
      provider: 'sendmail',
      providerOptions: {
        dkim: {
          privateKey: '',
          keySelector: '',
        },
      },
      settings: {
        defaultFrom: 'noreply@modernblog.com',
        defaultReplyTo: 'support@modernblog.com',
      },
    },
  },
});
```

#### For Production (using SendGrid)
```javascript
module.exports = ({ env }) => ({
  email: {
    config: {
      provider: 'sendgrid',
      providerOptions: {
        apiKey: env('SENDGRID_API_KEY'),
      },
      settings: {
        defaultFrom: env('DEFAULT_FROM_EMAIL', 'noreply@modernblog.com'),
        defaultReplyTo: env('DEFAULT_REPLY_TO_EMAIL', 'support@modernblog.com'),
        testAddress: env('TEST_EMAIL_ADDRESS', 'test@modernblog.com'),
      },
    },
  },
});
```

#### For Production (using Nodemailer with SMTP)
```javascript
module.exports = ({ env }) => ({
  email: {
    config: {
      provider: 'nodemailer',
      providerOptions: {
        host: env('SMTP_HOST', 'smtp.gmail.com'),
        port: env('SMTP_PORT', 587),
        auth: {
          user: env('SMTP_USERNAME'),
          pass: env('SMTP_PASSWORD'),
        },
      },
      settings: {
        defaultFrom: env('DEFAULT_FROM_EMAIL', 'noreply@modernblog.com'),
        defaultReplyTo: env('DEFAULT_REPLY_TO_EMAIL', 'support@modernblog.com'),
      },
    },
  },
});
```

### 3. Environment Variables

Add these to your Strapi `.env` file:

```env
# Email Configuration
DEFAULT_FROM_EMAIL=noreply@modernblog.com
DEFAULT_REPLY_TO_EMAIL=support@modernblog.com
TEST_EMAIL_ADDRESS=test@modernblog.com

# For SendGrid
SENDGRID_API_KEY=your_sendgrid_api_key_here

# For SMTP (Gmail, Outlook, etc.)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USERNAME=your_email@gmail.com
SMTP_PASSWORD=your_app_password_here
```

### 4. Install Email Provider (if needed)

For SendGrid:
```bash
npm install @strapi/provider-email-sendgrid
# or
yarn add @strapi/provider-email-sendgrid
```

For Nodemailer:
```bash
npm install @strapi/provider-email-nodemailer
# or
yarn add @strapi/provider-email-nodemailer
```

### 5. Create Newsletter Subscription Content Type

In Strapi Admin Panel:
1. Go to Content-Type Builder
2. Create new Collection Type: `newsletter-subscription`
3. Add fields:
   - `email` (Text, Required, Unique)
   - `subscribedAt` (DateTime, Required, Default: now)
   - `isActive` (Boolean, Required, Default: true)
   - `unsubscribedAt` (DateTime, Optional)

### 6. Set Permissions

In Strapi Admin Panel:
1. Go to Settings > Users & Permissions Plugin > Roles
2. Edit "Public" role
3. Under "Newsletter-subscription":
   - ✅ create
   - ✅ find
   - ✅ findOne
   - ✅ update (for unsubscribe)
4. Under "Email":
   - ✅ send (for the custom email route)

### 7. Configure Webhooks

In Strapi Admin Panel:
1. Go to Settings > Webhooks
2. Create new webhook:
   - **Name**: Newsletter Webhook
   - **URL**: `https://your-domain.com/api/webhooks/newsletter`
   - **Events**: 
     - ✅ Entry create (newsletter-subscription)
     - ✅ Entry update (newsletter-subscription)
     - ✅ Entry delete (newsletter-subscription)

## 🧪 Testing the Setup

### 1. Test Email Sending
```bash
curl -X POST http://localhost:1337/api/email \
  -H "Content-Type: application/json" \
  -d '{
    "to": "test@example.com",
    "subject": "Test Email",
    "text": "This is a test email",
    "html": "<h1>This is a test email</h1>"
  }'
```

### 2. Test Newsletter Subscription
```bash
curl -X POST http://localhost:3000/api/newsletter \
  -H "Content-Type: application/json" \
  -d '{"email": "test@example.com"}'
```

### 3. Check Strapi Logs
Monitor your Strapi console for email sending logs and any errors.

## 🔍 Troubleshooting

### Common Issues:

1. **"Email plugin not found"**
   - Make sure the email plugin is installed: `npm install @strapi/plugin-email`

2. **"Provider not found"**
   - Install the correct provider package (sendgrid, nodemailer, etc.)
   - Check your `config/plugins.js` configuration

3. **"Authentication failed"**
   - Verify your SMTP credentials or API keys
   - For Gmail, use App Passwords instead of regular passwords

4. **"Permission denied"**
   - Check that the Public role has permissions for the email API
   - Verify webhook URL is accessible

5. **"Webhook not triggering"**
   - Ensure webhook URL is publicly accessible
   - Check webhook configuration in Strapi admin
   - Verify the webhook endpoint is working

## 📝 Next Steps

1. Configure your preferred email provider
2. Set up the custom email API route in Strapi
3. Create the newsletter-subscription content type
4. Configure webhooks
5. Test the complete flow
6. Monitor email delivery and logs

The newsletter integration should now properly send welcome emails when users subscribe!