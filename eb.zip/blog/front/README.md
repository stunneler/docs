# ModernBlog - Next.js & Strapi Integration

A modern, responsive blog platform built with Next.js 15 and Strapi 5, featuring a glassmorphism design aesthetic and comprehensive component architecture.

## 🚀 Features

### Design & UI
- **Glassmorphism Design**: Translucent backgrounds, subtle shadows, and gradient effects
- **Dark/Light Mode**: Smooth theme transitions with system preference detection
- **Responsive Layout**: Mobile-first design with adaptive grid layouts
- **Modern Typography**: Inter font with optimized readability

### Layout Structure
- **Sticky Header**: Navigation with search functionality and theme toggle
- **Three-Column Layout**: Left sidebar (desktop), main content, right sidebar
- **Mobile Hamburger Menu**: Collapsible navigation for mobile devices
- **Floating Action Button**: Multi-action FAB with scroll-to-top functionality

### Components Architecture
- **Modular Components**: Reusable, well-structured React components
- **Custom Hooks**: `useTheme`, `useArticles` for state management
- **TypeScript**: Full type safety throughout the application
- **Modern React Patterns**: Functional components with hooks

### Content Features
- **Article Grid**: Responsive card layout with hover effects
- **Search Functionality**: Real-time article filtering
- **Newsletter Signup**: Integrated subscription form
- **Category Navigation**: Organized content discovery
- **Social Integration**: Social media links and sharing

## 🛠 Tech Stack

- **Frontend**: Next.js 15 with App Router
- **Styling**: Tailwind CSS with custom utilities
- **Backend**: Strapi 5 CMS
- **Language**: TypeScript
- **Fonts**: Inter (Google Fonts)
- **Icons**: Heroicons (SVG)

## 📁 Project Structure

```
src/
├── app/
│   ├── layout.tsx          # Root layout with theme setup
│   ├── page.tsx            # Main homepage
│   └── globals.css         # Global styles and utilities
├── components/
│   ├── Header.tsx          # Navigation header with search
│   ├── ArticleCard.tsx     # Individual article display
│   ├── Sidebar.tsx         # Left and right sidebar components
│   ├── Footer.tsx          # Site footer
│   └── FloatingActionButton.tsx # Multi-action FAB
├── hooks/
│   ├── useTheme.ts         # Theme management hook
│   └── useArticles.ts      # Article fetching and filtering
└── types/
    └── index.ts            # TypeScript type definitions
```

## 🎨 Design Features

### Glassmorphism Elements
- Backdrop blur effects on cards and navigation
- Translucent backgrounds with opacity variations
- Subtle border treatments with low opacity
- Gradient overlays and button effects

### Responsive Breakpoints
- Mobile: Single column layout
- Tablet: Two-column article grid
- Desktop: Three-column layout with sidebars
- Large screens: Optimized spacing and typography

### Interactive Elements
- Hover animations on cards and buttons
- Smooth transitions between theme modes
- Scale transforms on interactive elements
- Loading states with animated spinners

## 🔧 Configuration

### Next.js Configuration
- Image optimization for Strapi uploads
- Cross-origin request handling
- Turbopack for fast development
- TypeScript strict mode

### Strapi Integration
- Article content type with populate queries
- Image handling with proper optimization
- Error handling and loading states
- Real-time search functionality

## 🚀 Getting Started

1. **Start Strapi Backend** (Port 1337):
   ```bash
   cd back
   npm run start
   ```

2. **Start Next.js Frontend** (Port 3000):
   ```bash
   cd front
   npm run dev
   ```

3. **Access the Application**:
   - Frontend: http://localhost:3000
   - Strapi Admin: http://swop.site:1337/admin

## 📱 Mobile Responsiveness

- Collapsible navigation menu
- Single-column article layout
- Touch-optimized interactive elements
- Optimized typography scaling
- Gesture-friendly spacing

## 🎯 Performance Optimizations

- Image lazy loading with Next.js Image component
- Component code splitting
- CSS-in-JS with Tailwind utilities
- Optimized font loading
- Smooth scroll behavior

## 🔮 Future Enhancements

- Article pagination
- Category filtering
- User authentication
- Comment system
- Social sharing
- SEO optimization
- PWA capabilities

---

Built with ❤️ using modern web technologies and best practices.
