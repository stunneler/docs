import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  eslint: {
    ignoreDuringBuilds: true,
  },
  typescript: {
    ignoreBuildErrors: true,
  },
  
  // Allow images from localhost and your domain
  images: {
    remotePatterns: [
      {
        protocol: 'http',
        hostname: 'localhost',
        port: '1337',
        pathname: '/uploads/**',
      },
      {
        protocol: 'http',
        hostname: 'swop.site',
        port: '1337',
        pathname: '/uploads/**',
      },
    ],
  },
  
  // Allow cross-origin requests from your domain
  async headers() {
    return [
      {
        source: '/(.*)',
        headers: [
          {
            key: 'Access-Control-Allow-Origin',
            value: 'http://swop.site:3000',
          },
        ],
      },
    ];
  },
};

export default nextConfig;
