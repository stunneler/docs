module.exports = {
  apps: [
    {
      name: 'blog-backend',
      cwd: './blog/back',
      script: 'npm',
      args: 'run develop',
      env: {
        NODE_ENV: 'development',
        PORT: 1337
      }
    },
    {
      name: 'blog-frontend',
      cwd: './blog/front',
      script: 'npm',
      args: 'run dev',
      env: {
        NODE_ENV: 'development',
        PORT: 3000
      }
    },
    {
      name: 'ecom-store',
      cwd: './ecom/store',
      script: 'npm',
      args: 'run dev',
      env: {
        NODE_ENV: 'development',
        PORT: 3030
      }
    },
    {
      name: 'ecom-shelf',
      cwd: './ecom/shelf',
      script: 'npm',
      args: 'run develop',
      env: {
        NODE_ENV: 'development',
        PORT: 1338,
        HOST: '0.0.0.0',
        STRAPI_ADMIN_ALLOWED_HOSTS: 'localhost,127.0.0.1,swop.site,.swop.site'
      }
    }
  ]
};