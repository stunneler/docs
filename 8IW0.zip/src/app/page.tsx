'use client';
import { useEffect } from 'react';
import { useArticles, useTheme, useMobileMenu } from '@/hooks';
import { 
  Header, 
  Sidebar, 
  Footer, 
  MainLayout, 
  MainContent, 
  DesktopSidebar, 
  RightSidebar 
} from '@/components/Layout';
import { ArticlesList } from '@/components/Articles';
import { FloatingActionButton } from '@/components/UI';

export default function HomePage() {
  const { articles, loading, error } = useArticles();
  const { isDarkMode, toggleDarkMode } = useTheme();
  const { isMobileMenuOpen, toggleMobileMenu, closeMobileMenu } = useMobileMenu();

  // Make sure the dark class is properly applied or removed
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
      document.body.classList.add('dark');
      document.documentElement.style.colorScheme = 'dark';
    } else {
      document.documentElement.classList.remove('dark');
      document.body.classList.remove('dark');
      document.documentElement.style.colorScheme = 'light';
    }
  }, [isDarkMode]);

  return (
    <div className={`min-h-screen ${isDarkMode 
      ? 'bg-slate-900 text-white' 
      : 'bg-slate-50 text-gray-900'}`}>
      <Sidebar isOpen={isMobileMenuOpen} onClose={closeMobileMenu} isDarkMode={isDarkMode} />
      <Header onMenuToggle={toggleMobileMenu} isDarkMode={isDarkMode} onThemeToggle={toggleDarkMode} />
      <MainLayout>
        <DesktopSidebar articlesCount={articles?.length || 0} />
        <MainContent>
          <ArticlesList articles={articles} loading={loading} error={error} />
        </MainContent>
        <RightSidebar />
      </MainLayout>
      <FloatingActionButton />
      <Footer />
    </div>
  );
}