export const CATEGORIES = [
  'Technology',
  'Business',
  'Science',
  'Health',
  'Culture'
];