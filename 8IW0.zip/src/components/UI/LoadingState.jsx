export const LoadingState = () => {
  return (
    <div className="space-y-6">
      {Array.from({ length: 3 }).map((_, index) => (
        <div key={index} className="animate-pulse bg-white/70 dark:bg-slate-800/70 rounded-2xl p-6">
          <div className="h-48 bg-gray-200 dark:bg-slate-700 rounded-xl mb-4"></div>
          <div className="h-4 bg-gray-200 dark:bg-slate-700 rounded w-3/4 mb-2"></div>
          <div className="h-4 bg-gray-200 dark:bg-slate-700 rounded w-1/2"></div>
        </div>
      ))}
    </div>
  );
};