export const SearchInput = ({ placeholder = "Search articles...", onSearch }) => {
  return (
    <div className="hidden sm:flex items-center space-x-2 bg-gray-100 dark:bg-slate-800 rounded-full px-4 py-2">
      <SearchIcon />
      <input 
        type="text" 
        placeholder={placeholder} 
        className="bg-transparent border-none outline-none text-sm w-32 sm:w-48 text-gray-800 dark:text-white placeholder-gray-500 dark:placeholder-gray-400"
        onChange={(e) => onSearch?.(e.target.value)}
      />
    </div>
  );
};

const SearchIcon = () => (
  <svg className="w-4 h-4 text-gray-500 dark:text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
  </svg>
);