import { DesktopCategoriesSection } from './DesktopCategoriesSection';
import { DesktopTrendingSection } from './DesktopTrendingSection';
import { DesktopStatsSection } from './DesktopStatsSection';

export const DesktopSidebarContent = ({ onItemClick, articlesCount, isDarkMode }) => {
  return (
    <div className="space-y-5">
      <DesktopCategoriesSection onItemClick={onItemClick} isDarkMode={isDarkMode} articlesCount={articlesCount} />
      <DesktopTrendingSection onItemClick={onItemClick} isDarkMode={isDarkMode} />
      <DesktopStatsSection articlesCount={articlesCount} isDarkMode={isDarkMode} />
    </div>
  );
};