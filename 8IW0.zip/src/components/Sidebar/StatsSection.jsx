export const StatsSection = ({ articlesCount, isDarkMode }) => {
  return (
    <div className={`rounded-2xl p-6 shadow-xl ${
      isDarkMode 
        ? 'bg-gradient-to-br from-slate-800 to-slate-700 border border-slate-600 text-white' 
        : 'bg-gradient-to-br from-green-50 to-emerald-50 border border-green-100 text-gray-900'
    }`}>
      <h3 className={`text-lg font-semibold mb-4 ${
        isDarkMode ? 'text-white' : 'text-gray-900'
      }`}>Platform Stats</h3>
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <span className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>Total Articles</span>
          <span className={`font-bold ${isDarkMode ? 'text-green-400' : 'text-green-600'}`}>{articlesCount || 0}</span>
        </div>
        <div className="flex justify-between items-center">
          <span className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>Active Readers</span>
          <span className={`font-bold ${isDarkMode ? 'text-green-400' : 'text-green-600'}`}>2.4K</span>
        </div>
        <div className="flex justify-between items-center">
          <span className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>This Month</span>
          <span className={`font-bold ${isDarkMode ? 'text-green-400' : 'text-green-600'}`}>+12%</span>
        </div>
      </div>
    </div>
  );
};