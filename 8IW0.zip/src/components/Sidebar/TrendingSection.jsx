import { useState, useEffect } from 'react';

export const TrendingSection = ({ onItemClick, isDarkMode }) => {
  const trends = ['AI Revolution', 'Climate Tech', 'Web3 Future', 'Space Exploration'];
  const [mounted, setMounted] = useState(false);
  
  // Only run after initial client-side render
  useEffect(() => {
    setMounted(true);
  }, []);
  
  return (
    <div className={`rounded-2xl p-6 shadow-xl ${
      isDarkMode 
        ? 'bg-gradient-to-br from-slate-800 to-slate-700 border border-slate-600 text-white' 
        : 'bg-gradient-to-br from-blue-50 to-purple-50 border border-blue-100 text-gray-900'
    }`}>
      <h3 className={`text-lg font-semibold mb-4 flex items-center ${
        isDarkMode ? 'text-white' : 'text-gray-900'
      }`}>
        <PulsingDot />
        Trending Now
      </h3>
      <div className="space-y-3">
        {trends.map((trend, index) => (
          <TrendingItem 
            key={trend} 
            trend={trend} 
            rank={index + 1} 
            onClick={onItemClick}
            isDarkMode={isDarkMode}
          />
        ))}
      </div>
    </div>
  );
};

const PulsingDot = () => (
  <div className="w-2 h-2 bg-red-500 rounded-full mr-2 animate-pulse"></div>
);

const TrendingItem = ({ trend, rank, onClick, isDarkMode }) => (
  <div 
    className={`flex items-center space-x-3 p-2 rounded-lg transition-colors cursor-pointer ${
      isDarkMode
        ? 'hover:bg-slate-600/50'
        : 'hover:bg-white/50'
    }`}
    onClick={onClick}
  >
    <span className={`text-sm font-bold w-6 ${
      isDarkMode ? 'text-blue-400' : 'text-blue-600'
    }`}>#{rank}</span>
    <span className={`text-sm ${
      isDarkMode ? 'text-gray-300' : 'text-gray-700'
    }`}>{trend}</span>
  </div>
);