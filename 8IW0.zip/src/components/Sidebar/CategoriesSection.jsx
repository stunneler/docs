import { useCategories } from '@/hooks';
import { useState, useEffect } from 'react';

// Helper function to capitalize the first letter of each word
const capitalizeWords = (str) => {
  return str.replace(/\b\w/g, char => char.toUpperCase());
};

export const CategoriesSection = ({ onItemClick, isDarkMode }) => {
  const { categories, loading, error } = useCategories();
  const [mounted, setMounted] = useState(false);
  
  // Only run after initial client-side render
  useEffect(() => {
    setMounted(true);
  }, []);
  
  // Process categories for display
  const displayCategories = categories
    .map(cat => ({
      ...cat,
      // Capitalize the name for display
      name: capitalizeWords(cat.name)
    }))
    // Sort by article count (descending)
    .sort((a, b) => b.articlesCount - a.articlesCount);

  return (
    <div className={`rounded-2xl p-6 shadow-xl ${
      isDarkMode 
        ? 'bg-gradient-to-br from-blue-900 via-blue-800 to-indigo-900 border border-blue-700 text-white' 
        : 'bg-gradient-to-br from-blue-50 to-purple-50 border border-blue-100 text-gray-900'
    }`}>
      <h3 className={`text-lg font-semibold mb-4 flex items-center ${
        isDarkMode ? 'text-white' : 'text-gray-900'
      }`}>
        <CategoryIcon isDarkMode={isDarkMode} />
        Categories
        {loading && <span className="ml-2 inline-block w-2 h-2 bg-blue-600 rounded-full animate-pulse"></span>}
      </h3>
      
      {error && (
        <div className={`text-sm mb-3 ${isDarkMode ? 'text-red-400' : 'text-red-500'}`}>
          Failed to load categories
        </div>
      )}
      
      <div className="space-y-3">
        {displayCategories.length > 0 ? (
          displayCategories.map((category) => (
            <CategoryItem 
              key={category.id || category.name} 
              category={category.name} 
              count={category.articlesCount} 
              slug={category.slug}
              onClick={onItemClick}
              isDarkMode={isDarkMode}
            />
          ))
        ) : (
          !loading && (
            <div className={`text-center py-4 text-sm ${
              isDarkMode 
                ? 'text-blue-300' 
                : 'text-gray-500'
            }`}>
              No categories found
            </div>
          )
        )}
        
        {/* Show message if all categories have 0 articles */}
        {displayCategories.length > 0 && displayCategories.every(cat => cat.articlesCount === 0) && (
          <div className={`mt-4 text-xs rounded-lg p-3 ${
            isDarkMode 
              ? 'text-blue-300 bg-blue-800/30 border border-blue-700' 
              : 'text-gray-500 bg-white/50'
          }`}>
            No articles have been assigned to categories yet
          </div>
        )}
      </div>
    </div>
  );
};

const CategoryIcon = ({ isDarkMode }) => (
  <div className={`w-2 h-2 rounded-full mr-2 ${
    isDarkMode ? 'bg-blue-400' : 'bg-green-500'
  }`}></div>
);

const CategoryItem = ({ category, count, onClick, slug, isDarkMode }) => {
  // Use the provided slug or generate one from the category name
  const categorySlug = slug || category.toLowerCase().replace(/\s+/g, '-');
  const hasArticles = count > 0;
  
  return (
    <div 
      className={`flex items-center justify-between p-2 rounded-lg transition-colors cursor-pointer ${
        isDarkMode
          ? 'hover:bg-blue-800/50'
          : 'hover:bg-white/50'
      } ${!hasArticles ? 'opacity-60' : ''}`}
      onClick={() => {
        if (onClick && hasArticles) onClick();
      }}
    >
      <span className={`text-sm ${
        isDarkMode ? 'text-white' : 'text-gray-700'
      }`}>
        {category}
      </span>
      <span className={`text-xs px-2 py-1 rounded-full font-medium ${
        hasArticles 
          ? isDarkMode
            ? 'bg-blue-700/50 text-blue-200'
            : 'bg-blue-100 text-blue-600'
          : isDarkMode
            ? 'bg-blue-800/30 text-blue-400'
            : 'bg-gray-100 text-gray-400'
      }`}>
        {count || 0}
      </span>
    </div>
  );
};
