import { CategoriesSection } from './CategoriesSection';
import { TrendingSection } from './TrendingSection';
import { StatsSection } from './StatsSection';

export const SidebarContent = ({ onItemClick, articlesCount, isDarkMode }) => {
  return (
    <>
      <CategoriesSection onItemClick={onItemClick} isDarkMode={isDarkMode} />
      <TrendingSection onItemClick={onItemClick} isDarkMode={isDarkMode} />
      <StatsSection articlesCount={articlesCount} isDarkMode={isDarkMode} />
    </>
  );
};