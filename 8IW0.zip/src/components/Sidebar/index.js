export { SidebarContent } from './SidebarContent';
export { CategoriesSection } from './CategoriesSection';
export { TrendingSection } from './TrendingSection';
export { StatsSection } from './StatsSection';