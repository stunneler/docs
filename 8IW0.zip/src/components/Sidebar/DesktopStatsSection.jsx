export const DesktopStatsSection = ({ articlesCount, isDarkMode }) => {
  return (
    <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-2xl p-6 shadow-xl border border-purple-100 dark:border-none text-gray-900 dark:text-white">
      <h3 className="text-lg font-semibold mb-4 text-gray-900 dark:text-white">Platform Stats</h3>
      <p className="text-sm text-gray-600 dark:text-white mb-4">
        Current statistics for the platform
      </p>
      <div className="space-y-3">
        <StatItem label="Total Articles" value={articlesCount || 0} />
        <StatItem label="Active Readers" value="2.4K" />
        <StatItem label="Growth This Month" value="+12%" />
      </div>
    </div>
  );
};

const StatItem = ({ label, value }) => (
  <div className="w-full px-4 py-3 rounded-xl border border-purple-200 dark:border-slate-600/50 bg-white/50 dark:bg-slate-800 backdrop-blur-sm text-gray-800 dark:text-white flex justify-between items-center">
    <span className="text-sm">{label}</span>
    <span className="font-bold text-purple-600 dark:text-purple-400">{value}</span>
  </div>
);