import { CATEGORIES } from '@/constants/categories';
import { SOCIAL_LINKS } from '@/constants/socialLinks';

export const RightSidebar = () => {
  return (
    <aside className="lg:col-span-3 space-y-6">
      <NewsletterSignup />
      <PopularTags />
      <SocialLinks />
    </aside>
  );
};

const NewsletterSignup = () => (
  <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-2xl p-6 shadow-xl border border-purple-100 dark:border-none text-gray-900 dark:text-white">
    <h3 className="text-lg font-semibold mb-4 text-gray-900 dark:text-white">Stay Updated</h3>
    <p className="text-sm text-gray-600 dark:text-white mb-4">
      Get the latest articles delivered to your inbox
    </p>
    <div className="space-y-3">
      <input 
        type="email" 
        placeholder="your@email.com"
        className="w-full px-4 py-3 rounded-xl border border-gray-200 dark:border-slate-600/50 bg-white/50 dark:bg-slate-800 backdrop-blur-sm focus:outline-none focus:ring-2 focus:ring-purple-500 transition-all text-gray-800 dark:text-white placeholder-gray-500 dark:placeholder-white"
      />
      <button className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white py-3 px-4 rounded-xl font-medium transition-all duration-200 transform hover:scale-105">
        Subscribe
      </button>
    </div>
  </div>
);

const PopularTags = () => {
  const popularTags = ['JavaScript', 'React', 'AI/ML', 'Design', 'Startup', 'Tech', 'Innovation', 'Future'];
  
  return (
    <div className="bg-white/70 dark:bg-slate-800/70 backdrop-blur-sm rounded-2xl p-6 shadow-xl border border-white/20 dark:border-none">
      <h3 className="text-lg font-semibold mb-4 text-gray-900 dark:text-white">Popular Tags</h3>
      <div className="flex flex-wrap gap-2">
        {popularTags.map((tag) => (
          <span 
            key={tag}
            className="px-3 py-1.5 bg-gradient-to-r from-gray-100 to-gray-200 dark:from-slate-700 dark:to-slate-600 rounded-full text-sm text-gray-700 dark:text-gray-300 hover:from-blue-100 hover:to-purple-100 dark:hover:from-blue-900/30 dark:hover:to-purple-900/30 cursor-pointer transition-all duration-200 hover:scale-105"
          >
            #{tag}
          </span>
        ))}
      </div>
    </div>
  );
};

const QuickActions = () => (
  <div className="bg-gradient-to-br from-amber-50 to-orange-50 rounded-2xl p-6 shadow-xl border border-amber-100 dark:border-none text-gray-900 dark:text-white">
    <h3 className="text-lg font-semibold mb-4 text-gray-900 dark:text-white">Quick Actions</h3>
    <div className="space-y-3">
      <QuickActionButton 
        icon="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"
        text="Write Article"
      />
      <QuickActionButton 
        icon="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"
        text="Analytics"
      />
      <QuickActionButton 
        icon="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37a1.724 1.724 0 002.572-1.065z M15 12a3 3 0 11-6 0 3 3 0 016 0z"
        text="Settings"
      />
    </div>
  </div>
);

const QuickActionButton = ({ icon, text }) => (
  <button className="w-full flex items-center space-x-3 p-3 bg-white/50 dark:bg-slate-700 rounded-xl hover:bg-white dark:hover:bg-slate-600 transition-all duration-200 group">
    <svg className="w-5 h-5 text-amber-600 dark:text-amber-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={icon} />
    </svg>
    <span className="text-sm font-medium text-gray-700 dark:text-white group-hover:text-amber-600 dark:group-hover:text-amber-400">
      {text}
    </span>
  </button>
);

const SocialLinks = () => (
  <div className="bg-white/70 dark:bg-slate-800/70 backdrop-blur-sm rounded-2xl p-6 shadow-xl border border-white/20 dark:border-none">
    <h3 className="text-lg font-semibold mb-4 text-gray-900 dark:text-white">Connect With Us</h3>
    <div className="flex space-x-3">
      {SOCIAL_LINKS.map((social) => (
        <button 
          key={social.name}
          className={`p-3 ${social.color} hover:bg-gray-100 dark:hover:bg-slate-700 rounded-xl transition-all duration-200 hover:scale-110`}
          title={social.name}
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={social.icon} />
          </svg>
        </button>
      ))}
    </div>
  </div>
);