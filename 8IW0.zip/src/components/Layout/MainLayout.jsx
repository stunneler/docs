export const MainLayout = ({ children }) => {
  return (
    <div className="w-full px-4 sm:px-6 py-8">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {children}
      </div>
    </div>
  );
};
