import { DesktopSidebarContent } from '../Sidebar/DesktopSidebarContent';
import { useTheme } from '@/hooks';

export const DesktopSidebar = ({ articlesCount }) => {
  const { isDarkMode } = useTheme();
  
  return (
    <aside className="hidden lg:block lg:col-span-3 space-y-5">
      <DesktopSidebarContent articlesCount={articlesCount} isDarkMode={isDarkMode} />
    </aside>
  );
};