import { CONFIG } from '@/constants/config';

export const ArticleImage = ({ image, title }) => {
  if (!image?.url) return <ImageDebugInfo image={image} />;
  
  return (
    <div className="relative overflow-hidden">
      <img 
        src={`${CONFIG.API_BASE_URL}${image.formats?.large?.url || image.url}`}
        alt={image.alternativeText || title}
        className="w-full h-48 sm:h-64 object-cover group-hover:scale-105 transition-transform duration-500"
        onLoad={(e) => {
          console.log('Image loaded successfully:', e.currentTarget.src);
        }}
        onError={(e) => {
          console.error('Image failed to load:', e.currentTarget.src);
          e.currentTarget.alt = 'Image failed to load';
        }}
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
      <div className="absolute top-4 left-4">
        <span className="bg-blue-600 text-white px-3 py-1 rounded-full text-xs font-medium">
          Featured
        </span>
      </div>
    </div>
  );
};

const ImageDebugInfo = ({ image }) => {
  if (image && !image.url) {
    return (
      <div className="m-4 bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 text-yellow-700 dark:text-yellow-300 px-4 py-3 rounded-xl">
        <p className="font-medium">Cover image object exists but no URL found</p>
        <pre className="text-xs mt-2 bg-yellow-100 dark:bg-yellow-900/30 p-2 rounded overflow-auto">
          {JSON.stringify(image, null, 2)}
        </pre>
      </div>
    );
  }
  
  return (
    <div className="m-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-300 px-4 py-3 rounded-xl">
      <div className="flex items-center">
        <svg className="w-5 h-5 mr-2 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
        <p className="font-medium">No coverImage field found for this article</p>
      </div>
    </div>
  );
};