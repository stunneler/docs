import { ArticleImage } from './ArticleImage';
import { ArticleContent } from './ArticleContent';

export const ArticleCard = ({ article }) => {
  return (
    <article className="group bg-white/70 dark:bg-slate-800/70 backdrop-blur-sm rounded-2xl overflow-hidden shadow-xl border border-white/20 dark:border-slate-700/20 hover:shadow-2xl hover:scale-[1.02] transition-all duration-300 dark:text-white">
      <ArticleImage image={article.coverImage} title={article.title} />
      <ArticleContent article={article} />
    </article>
  );
};