import { ArticleCard } from './ArticleCard';
import { LoadingState } from '../UI/LoadingState';
import { ErrorState } from '../UI/ErrorState';
import { EmptyState } from '../UI/EmptyState';

export const ArticlesList = ({ articles, loading, error }) => {
  if (loading) return <LoadingState />;
  if (error) return <ErrorState error={error} />;
  if (!articles.length) return <EmptyState />;
  
  return (
    <div className="space-y-6">
      {articles.map((article) => (
        <ArticleCard key={article.id} article={article} />
      ))}
    </div>
  );
};