import { useState, useEffect } from 'react';
import { getCategories } from '@/lib/api';
import { CATEGORIES } from '@/constants/categories';

// Create stable initial state to prevent hydration errors
const fallbackCounts = {
  'Technology': 8,
  'Business': 12,
  'Science': 5,
  'Health': 7,
  'Culture': 3
};

const initialCategories = CATEGORIES.map(name => ({
  id: name.toLowerCase(),
  name,
  slug: name.toLowerCase(),
  articlesCount: fallbackCounts[name] || 0
}));

export const useCategories = () => {
  // Start with initialCategories to prevent hydration errors
  const [categories, setCategories] = useState(initialCategories);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    let isMounted = true;
    
    async function fetchCategories() {
      try {
        setLoading(true);
        const data = await getCategories();
        console.log('Categories received in hook:', data);
        
        // Only update state if component is still mounted
        if (isMounted) {
          setCategories(data);
          setError(null);
        }
      } catch (err) {
        console.error('Error in useCategories hook:', err);
        if (isMounted) {
          setError(err);
          // Keep using initialCategories on error
        }
      } finally {
        if (isMounted) {
          setLoading(false);
        }
      }
    }
    
    // Use setTimeout to ensure client-side execution
    // This helps prevent hydration errors
    const timeoutId = setTimeout(() => {
      fetchCategories();
    }, 100);
    
    return () => {
      isMounted = false;
      clearTimeout(timeoutId);
    };
  }, []);

  return { categories, loading, error };
};