import { useState, useEffect } from 'react';

export const useTheme = () => {
  // Initialize with false (light mode) since we've removed the default dark class
  const [isDarkMode, setIsDarkMode] = useState(false);
  
  // Apply dark mode on initial render
  useEffect(() => {
    // Check if dark class is present on the HTML element
    const isDark = document.documentElement.classList.contains('dark');
    setIsDarkMode(isDark);
  }, []);

  // Theme application is now handled in the page component

  // Toggle function without localStorage
  const toggleDarkMode = () => {
    const newDarkMode = !isDarkMode;
    setIsDarkMode(newDarkMode);
    
    // The applyTheme function is now handled in the page component
    // to ensure consistent application of the theme
  };

  return { isDarkMode, toggleDarkMode };
};