import { useState, useEffect } from 'react';
import { getArticles } from '@/lib/api';

export const useArticles = () => {
  const [articles, setArticles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    async function fetchArticles() {
      try {
        setLoading(true);
        const data = await getArticles();
        console.log('Articles received in hook:', data);
        setArticles(data);
        setError(null);
      } catch (err) {
        console.error('Error in useArticles hook:', err);
        setError(err);
      } finally {
        setLoading(false);
      }
    }
    fetchArticles();
  }, []);

  return { articles, loading, error };
};