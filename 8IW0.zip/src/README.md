# ArticleHub

A modern, responsive React application for displaying articles from a Strapi CMS backend.

## Features

- **Modern React Architecture**: Component-based structure with custom hooks
- **Dynamic Categories**: Fetches categories from Strapi API
- **Responsive Design**: Works on mobile, tablet, and desktop
- **Dark Mode Support**: Automatically detects system preference
- **Loading States**: Provides feedback during data fetching
- **Error Handling**: Gracefully handles API errors

## Project Structure

- **components/**: UI components organized by feature
  - **Articles/**: Article-related components
  - **Layout/**: Layout components (Header, Sidebar, Footer)
  - **Sidebar/**: Sidebar content components
  - **UI/**: Reusable UI components
- **hooks/**: Custom React hooks
- **constants/**: Application constants
- **lib/**: API utilities

## Getting Started

1. Clone the repository
2. Install dependencies: `npm install`
3. Run the development server: `npm run dev`
4. Open [http://localhost:3000](http://localhost:3000) in your browser

## API Integration

The application connects to a Strapi CMS backend at the URL specified in `constants/config.js`. The following endpoints are used:

- `/api/articles`: Fetches articles
- `/api/categories`: Fetches categories

## Milestones

### v1.0.0 - First Milestone
- Refactored monolithic component into smaller, focused components
- Implemented custom hooks for data fetching and state management
- Added dynamic categories from Strapi API
- Fixed hydration issues and improved error handling